namespace Consenter;

/// <summary>
/// スクロールする規約の中にあるチェックを入れてから同意するミニゲームです。スクロールはNoSのスクロールビューで行います。
/// 規約は次のようなかたまりをランダムに並べて作るので、チェックの出方が毎回変わります。
/// ・条文と、その条文に同意するチェック
/// ・チェックの無い条文
/// ・横にずらっと並んだチェック
/// ・条文を挟まずに何行も続くチェック
/// ・チェックしてもしなくてもいい項目(メールマガジンの購読など)。必ず1つ以上入る
/// ・チェックしてはいけない項目(同意しないなど)
/// チェックしてもしなくてもいい項目とチェックしてはいけない項目は太字です。チェックすべき項目も、ときどき太字になります。
/// チェックすべき項目が残っている間に同意するを押しても、同意できません。チェックしてはいけない項目にチェックを入れて同意すると失敗します。
/// チェックしてもしなくてもいい項目にチェックを入れて同意すると、アドバータイズメント(<see cref="Advertisement"/>)の効果を受けます。
/// 同意しないを押すと失敗します。
/// </summary>
public class ScrollCheckGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.4f, 4.7f);
    public override float? IdleTimeout => 20f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int NumOfArticleTexts = 8;
    private const int NumOfExtraLabels = 4;
    private const int NumOfOptionalLabels = 2;
    private const int NumOfForbiddenLabels = 3;
    private const float CheckBoxScale = 0.42f;
    private const float RowHeight = 0.42f;
    private const float TextFontSize = 1.05f;
    //チェックすべき項目を太字にする確率
    private const float BoldRequiredChance = 0.25f;

    private enum Block { ArticleWithCheck, ArticleOnly, HorizontalChecks, StackedChecks, Optional, Forbidden }

    /// <summary>チェックボックスの種類です。</summary>
    private enum CheckKind
    {
        /// <summary>チェックすべき項目</summary>
        Required,
        /// <summary>チェックしてもしなくてもいい項目</summary>
        Optional,
        /// <summary>チェックしてはいけない項目</summary>
        Forbidden,
    }

    private ConsentScrollView view = null!;
    private readonly List<(CheckKind kind, bool isChecked)> checks = [];
    private readonly List<int> unusedOptionalLabels = Enumerable.Range(0, NumOfOptionalLabels).ToList();
    private TextMeshPro warning = null!;
    private float warningTime = 0f;
    private float cursor;
    private int articleNumber = 0;
    private float Left => -view.Width * 0.5f;

    public override void Begin()
    {
        var area = ContentArea;
        var viewRect = Rect.MinMaxRect(area.xMin, area.yMin + 0.75f, area.xMax, area.yMax);
        view = ConsentScrollView.Create(Root, new(viewRect.center.x, viewRect.center.y, -0.1f), viewRect.size, 1f);
        ConsentUI.Box(Root, "ViewportBack", new(view.Viewport.center.x, view.Viewport.center.y, -0.05f), view.Viewport.size, new(0f, 0f, 0f, 0.25f));

        //かたまりを並べる。最初は普通の条文から始める
        cursor = view.Top - 0.1f;
        var blocks = new List<Block>() { Block.ArticleWithCheck };
        (Block block, float weight)[] candidates = [
            (Block.ArticleWithCheck, 3f), (Block.ArticleOnly, 1f), (Block.HorizontalChecks, 2f), (Block.StackedChecks, 2f), (Block.Optional, 1.5f), (Block.Forbidden, 1f)
        ];
        for (int i = 0; i < 8; i++)
        {
            float value = Random01 * candidates.Sum(c => c.weight);
            foreach (var (block, weight) in candidates)
            {
                value -= weight;
                if (value < 0f) { blocks.Add(block); break; }
            }
        }
        //アドバータイズメントを受けるチェック(チェックしてもしなくてもいい項目)は、少なくとも1つは入れる
        if (!blocks.Contains(Block.Optional)) blocks.Insert(RandomInt(1, blocks.Count + 1), Block.Optional);

        foreach (var block in blocks)
        {
            switch (block)
            {
                case Block.ArticleWithCheck:
                    {
                        int number = AddArticle();
                        AddCheckRow(Language.Translate("consenter.minigame.scrollCheck.check").Replace("%NUM%", number.ToString()), CheckKind.Required);
                        break;
                    }
                case Block.ArticleOnly:
                    AddArticle();
                    break;
                case Block.HorizontalChecks:
                    AddHorizontalChecks(RandomInt(4, 7));
                    break;
                case Block.StackedChecks:
                    for (int i = RandomInt(3, 6); i > 0; i--) AddCheckRow(Language.Translate("consenter.minigame.scrollCheck.extra." + RandomInt(NumOfExtraLabels)), CheckKind.Required);
                    break;
                case Block.Optional:
                    {
                        //同じ項目は1回だけ
                        if (unusedOptionalLabels.Count == 0) break;
                        int label = unusedOptionalLabels[RandomInt(unusedOptionalLabels.Count)];
                        unusedOptionalLabels.Remove(label);
                        AddCheckRow(Language.Translate("consenter.minigame.scrollCheck.optional." + label), CheckKind.Optional);
                        break;
                    }
                case Block.Forbidden:
                    AddCheckRow(Language.Translate("consenter.minigame.scrollCheck.forbidden." + RandomInt(NumOfForbiddenLabels)), CheckKind.Forbidden);
                    break;
            }
            cursor -= 0.12f;
        }
        view.SetContentHeight(view.Top - cursor + 0.1f);
        view.ApplyMask();

        float buttonY = area.yMin + 0.32f;
        bool agreeOnLeft = Random01 < 0.5f;
        ConsentTitleButton? agree = null;
        agree = AddAgreeButton(new(agreeOnLeft ? -1.4f : 1.4f, buttonY), 2.2f, () =>
        {
            //チェックしてはいけない項目にチェックがあれば、同意しなかったことになる
            if (checks.Any(c => c.kind == CheckKind.Forbidden && c.isChecked))
            {
                Fail();
                return;
            }
            if (checks.Any(c => c.kind == CheckKind.Required && !c.isChecked))
            {
                Shake(agree!.Transform);
                warningTime = 2f;
                return;
            }
            if (checks.Any(c => c.kind == CheckKind.Optional && c.isChecked)) Advertisement.Apply(Consenter.TaskAdvertisementDurationOption.GetValue());
            Succeed();
        });
        AddDisagreeButton(new(agreeOnLeft ? 1.4f : -1.4f, buttonY), 2.2f);

        warning = AddText(new(0f, viewRect.yMin - 0.12f, -0.5f), new(DialogSize.x, 0.3f), 1.1f, Language.Translate("consenter.minigame.scrollCheck.warning"), new(1f, 0.6f, 0.5f));
        warning.gameObject.SetActive(false);
    }

    private string NextArticleText(out int number)
    {
        number = ++articleNumber;
        return Language.Translate("consenter.minigame.article." + ((number - 1) % NumOfArticleTexts)).Replace("%NUM%", number.ToString());
    }

    /// <summary>
    /// 条文を置き、その高さだけ下へ進みます。
    /// </summary>
    private int AddArticle()
    {
        string text = NextArticleText(out int number);
        float width = view.Width - 0.2f;
        var tmp = ConsentUI.Text(view.Content, Vector3.zero, new(width, 1f), TextFontSize, new(0.9f, 0.9f, 0.9f), TextAlignmentOptions.TopLeft, text);
        float height = tmp.GetPreferredValues(text, width, 0f).y;
        tmp.rectTransform.sizeDelta = new(width, height);
        tmp.transform.localPosition = new(0f, cursor - height * 0.5f, -0.01f);
        cursor -= height + 0.05f;
        return number;
    }

    /// <summary>
    /// チェックボックスを置き、クリックで切り替わるようにします。
    /// </summary>
    private void AddCheckBox(Vector3 localPos, CheckKind kind)
    {
        int index = checks.Count;
        checks.Add((kind, false));
        var box = ConsentUI.Sprite(view.Content, "CheckBox", localPos, ConsentAssets.CheckBox.GetSprite(), null, CheckBoxScale);
        var mark = ConsentUI.Sprite(box.transform, "CheckMark", new(0f, 0f, -0.01f), ConsentAssets.CheckMark.GetSprite());
        mark.gameObject.SetActive(false);
        var clickable = Clicks.Add(box.transform, new Vector2(0.64f, 0.64f), () =>
        {
            var (k, isChecked) = checks[index];
            checks[index] = (k, !isChecked);
            mark.gameObject.SetActive(!isChecked);
        });
        clickable.Predicate = () => view.Contains(Clicks.MouseLocal(Root));
    }

    /// <summary>
    /// チェックすべきでない項目は必ず太字、チェックすべき項目はときどき太字にします。
    /// </summary>
    private string Decorate(string label, CheckKind kind) => kind != CheckKind.Required || Random01 < BoldRequiredChance ? $"<b>{label}</b>" : label;

    /// <summary>
    /// 左端にチェックボックス、その右に文言を置いた1行です。
    /// </summary>
    private void AddCheckRow(string label, CheckKind kind)
    {
        float y = cursor - RowHeight * 0.5f;
        AddCheckBox(new(Left + 0.3f, y, -0.01f), kind);
        ConsentUI.Text(view.Content, new(Left + 0.55f + 1.8f, y, -0.01f), new(3.6f, 0.3f), 1.1f, Color.white, TextAlignmentOptions.Left, Decorate(label, kind));
        cursor -= RowHeight;
    }

    /// <summary>
    /// 横にずらっと並んだ、チェックすべきチェックです。
    /// </summary>
    private void AddHorizontalChecks(int count)
    {
        float y = cursor - RowHeight * 0.5f;
        float pitch = (view.Width - 0.4f) / count;
        string label = Language.Translate("consenter.minigame.ball.agree");
        for (int i = 0; i < count; i++)
        {
            float x = Left + 0.2f + pitch * (i + 0.5f);
            AddCheckBox(new(x - 0.25f, y, -0.01f), CheckKind.Required);
            ConsentUI.Text(view.Content, new(x + 0.2f, y, -0.01f), new(0.6f, 0.3f), 1.1f, Color.white, TextAlignmentOptions.Left, Decorate(label, CheckKind.Required));
        }
        cursor -= RowHeight;
    }

    public override void Update()
    {
        warningTime -= Time.deltaTime;
        warning.gameObject.SetActive(warningTime > 0f);
    }
}
