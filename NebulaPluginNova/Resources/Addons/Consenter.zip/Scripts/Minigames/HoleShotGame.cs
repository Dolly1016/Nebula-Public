namespace Consenter;

/// <summary>
/// 向きと強さを決めて砲台から同意の玉(色だけの緑の玉)を撃ち出し、壁の穴に通すミニゲームです。
/// 向きは発射台からカーソルへの方向で決まります。長押しすると強さのメーター(Airshipのシャワーを直すタスクのもの)が上下し、離した時の強さで撃ちます。
/// 穴を抜けた玉は同意するボタンになり、押すと同意できます。4発以内に通せないと失敗します。
/// </summary>
public class HoleShotGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.4f, 4.6f);
    public override float? IdleTimeout => 20f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int MaxShots = 4;
    private const float BallRadius = 0.14f;
    private const float MinShotSpeed = 2.5f;
    private const float MaxShotSpeed = 7.5f;
    private const float WallThickness = 0.12f;
    private const float HoleSize = 0.48f;

    private readonly ConsentPhysics physics = new() { Gravity = new(0f, -4.5f), Restitution = 0.45f, Damping = 0.3f };
    private Rect field;
    private Vector2 launcher;
    private float wallX;
    private SpriteRenderer aim = null!;
    private ConsentCannon cannon = null!;
    private PhysicsBall? ball = null;
    private SpriteRenderer? ballRenderer = null;
    private float shotTime = 0f;
    private int shots = 0;
    private TextMeshPro counter = null!;
    private bool passed = false;
    private ConsentPowerBar powerBar = null!;

    public override void Begin()
    {
        var area = ContentArea;
        field = Rect.MinMaxRect(area.xMin, area.yMin + 0.35f, area.xMax, area.yMax);
        var fieldBox = ConsentUI.Box(Root, "Field", new(field.center.x, field.center.y, -0.05f), field.size, new(0f, 0f, 0f, 0.3f));
        //長押しの始まりはPassiveButtonで受ける。離したかどうかは、溜めている間マウスを見て調べる
        Clicks.AddPress(fieldBox.transform, new Vector2(0.16f, 0.16f), () =>
        {
            if (ball == null && shots < MaxShots && !powerBar.IsCharging) powerBar.BeginCharge();
        });
        physics.AddBoxWalls(field);

        //穴の開いた壁
        wallX = field.xMax - 1.4f;
        float holeY = RandomRange(field.yMin + 0.5f, field.yMax - 0.5f);
        var wallColor = new Color(0.75f, 0.75f, 0.8f);
        void AddWall(float y0, float y1)
        {
            if (y1 - y0 < 0.01f) return;
            physics.AddBoxWalls(Rect.MinMaxRect(wallX - WallThickness * 0.5f, y0, wallX + WallThickness * 0.5f, y1));
            ConsentUI.Box(Root, "Wall", new(wallX, (y0 + y1) * 0.5f, -0.15f), new(WallThickness, y1 - y0), wallColor);
        }
        AddWall(field.yMin, holeY - HoleSize * 0.5f);
        AddWall(holeY + HoleSize * 0.5f, field.yMax);

        launcher = new(field.xMin + 0.4f, field.yMin + 0.3f);
        cannon = new ConsentCannon(Root, new(launcher.x, launcher.y, -0.2f), 0.45f);
        aim = ConsentUI.Box(Root, "Aim", new(launcher.x, launcher.y, -0.18f), new(1f, 0.06f), new(1f, 1f, 1f, 0.6f));
        powerBar = new ConsentPowerBar(Root, new(field.xMin + 1.4f, field.yMax - 0.25f, -0.4f), 2.2f);

        counter = AddText(new(0f, area.yMin + 0.15f, -0.5f), new(area.width, 0.3f), 1.2f, "", new(1f, 0.95f, 0.6f));
        RefreshCounter();
    }

    private void RefreshCounter() => counter.text = Language.Translate("consenter.minigame.holeShot.remaining").Replace("%NUM%", (MaxShots - shots).ToString());

    private float AimAngle
    {
        get
        {
            var dir = Clicks.MouseLocal(Root) - launcher;
            return Mathf.Clamp(Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg, 3f, 87f);
        }
    }


    public override void Update()
    {
        if (passed) return;

        float angle = AimAngle;
        var dir = new Vector2(Mathf.Cos(angle * Mathf.Deg2Rad), Mathf.Sin(angle * Mathf.Deg2Rad));
        //照準は向きだけを示す。溜めている間は強さに合わせて伸びる
        float aimLength = 0.6f + (powerBar.IsCharging ? powerBar.Power * 0.9f : 0f);
        cannon.Angle = angle;
        //照準は砲口の先に出す
        var aimCenter = launcher + dir * (cannon.MuzzleLength + 0.05f + aimLength * 0.5f);
        aim.transform.localPosition = new(aimCenter.x, aimCenter.y, -0.18f);
        aim.transform.localEulerAngles = new(0f, 0f, angle);
        aim.transform.localScale = new(aimLength / 0.16f, 0.06f / 0.16f, 1f);

        if (ball == null)
        {
            //長押しで溜め、離したら撃つ
            if (powerBar.IsCharging) powerBar.UpdateCharge(Time.deltaTime);
            if (powerBar.IsCharging && !Clicks.MouseHeld)
            {
                float power = powerBar.Release();
                shots++;
                RefreshCounter();
                //玉は砲口から出す。文字は描かず、色だけの玉にする
                ball = physics.AddBall(cannon.Muzzle, BallRadius);
                ball.Velocity = dir * Mathf.Lerp(MinShotSpeed, MaxShotSpeed, power);
                ballRenderer = ConsentUI.Circle(Root, "Ball", new(ball.Position.x, ball.Position.y, -0.3f), BallRadius, ConsentAssets.AgreeColor);
                shotTime = 0f;
            }
            return;
        }

        physics.Step(Time.deltaTime);
        ballRenderer!.transform.localPosition = new(ball.Position.x, ball.Position.y, -0.3f);
        shotTime += Time.deltaTime;

        if (ball.Position.x > wallX + WallThickness * 0.5f + BallRadius)
        {
            //穴を抜けたら同意するボタンになる
            passed = true;
            var area = ContentArea;
            var pos = new Vector2(Mathf.Clamp(ball.Position.x, area.xMax - 1f, area.xMax - 1f), Mathf.Clamp(ball.Position.y, field.yMin + 0.3f, field.yMax - 0.3f));
            GameObject.Destroy(ballRenderer.gameObject);
            var agree = AddAgreeButton(pos, 1.7f);
            agree.Transform.localPosition = new(pos.x, pos.y, -0.6f);
            PopIn(agree.Transform);
            return;
        }

        //止まるか時間が経ったら次の玉
        if (shotTime > 4f || (shotTime > 0.5f && ball.Velocity.magnitude < 0.05f))
        {
            physics.Balls.Remove(ball);
            GameObject.Destroy(ballRenderer.gameObject);
            ball = null;
            ballRenderer = null;
            if (shots >= MaxShots) Fail();
        }
    }
}
