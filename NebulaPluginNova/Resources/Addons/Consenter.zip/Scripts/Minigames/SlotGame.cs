namespace Consenter;

/// <summary>
/// スロットのミニゲームです。3つのリールの目は、どれも小さなボタンの見た目の「同意する」(緑)か「同意しない」(赤)です。リールはそれぞれの下のSTOPボタンで止めます。
/// リールの区切りは黄色の縦線、真ん中の段は赤い横線で示します。
/// 止めるとリールは次の目まで進んで止まります。真ん中の段に同意するが横一列に揃えば同意でき、同意しないが揃うと同意しなかったことになります。
/// どちらも揃わなかったときは少しして回り直し、回す回数に制限はありません(しばらく操作が無いと時間切れで同意しなかったことになります)。
/// 同意しないを押しても失敗します。
/// </summary>
public class SlotGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.2f, 4.4f);
    public override string? InstructionKey => GeneralInstructionKey;
    public override float? IdleTimeout => 20f;

    private const int NumOfReels = 3;
    //リール1本あたりの目の数。同意すると同意しないを同じ数ずつ並べる
    private const int SymbolsPerReel = 6;
    private const float SymbolPitch = 0.62f;
    private const float ReelWidth = 1.6f;
    private const float ReelGap = 0.14f;
    private const float RespinDelay = 0.8f;

    private class Reel
    {
        //目が同意するならtrue
        public bool[] Symbols = null!;
        public Transform[] Items = null!;
        public float Position;
        public float Speed;
        public bool Spinning = true;
        public float? StopTarget;

        public bool CenterIsAgree
        {
            get
            {
                int count = Symbols.Length;
                int center = ((int)Mathf.Round(Position) % count + count) % count;
                return Symbols[center];
            }
        }
    }

    private readonly List<Reel> reels = [];
    private float reelY;
    private float respinTimer = -1f;

    public override void Begin()
    {
        var area = ContentArea;
        reelY = area.center.y + 0.45f;
        float pitchX = ReelWidth + ReelGap;
        float totalWidth = pitchX * NumOfReels - ReelGap;
        var windowHeight = SymbolPitch * 2.2f;

        ConsentUI.Mask(Root, new(0f, reelY, 0f), new(totalWidth, windowHeight));
        //リールの区切りの黄色の縦線と、真ん中の段の赤い横線だけを描く
        for (int i = 0; i <= NumOfReels; i++)
        {
            float lineX = -totalWidth * 0.5f - ReelGap * 0.5f + pitchX * i;
            ConsentUI.Box(Root, "ReelLine", new(lineX, reelY, -0.2f), new(0.05f, windowHeight), new(0.95f, 0.8f, 0.3f));
        }
        ConsentUI.Box(Root, "CenterLine", new(0f, reelY, -0.25f), new(totalWidth + 0.3f, 0.04f), new(1f, 0.3f, 0.3f, 0.6f));

        var holder = ConsentUI.Object(Root, "Reels", new(0f, 0f, -0.1f)).transform;
        for (int i = 0; i < NumOfReels; i++)
        {
            float x = -totalWidth * 0.5f + ReelWidth * 0.5f + pitchX * i;

            //同意すると同意しないを同じ数ずつ、ばらばらに並べた帯
            var symbols = Enumerable.Range(0, SymbolsPerReel).Select(k => k % 2 == 0).ToArray();
            Shuffle(symbols);
            var reel = new Reel()
            {
                Symbols = symbols,
                Position = RandomRange(0f, symbols.Length),
                Speed = RandomRange(7f, 9.5f),
            };
            //目は小さなボタンの見た目にする(同意するは緑、同意しないは赤)
            reel.Items = symbols.Select(isAgree => ConsentUI.SimpleButton(holder, "Symbol", new(x, reelY, -0.01f), new(ReelWidth * 0.85f, SymbolPitch * 0.72f),
                isAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText, isAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree, 1.1f).Transform).ToArray();
            reels.Add(reel);

            var index = i;
            AddSimpleButton(Root, new(x, reelY - windowHeight * 0.5f - 0.35f, -0.2f), new(ReelWidth * 0.7f, 0.34f), "STOP", ConsentButtonStyle.Neutral, () => Stop(index), 1f);
        }
        ConsentUI.SetMasked(holder.gameObject);

        AddDisagreeButton(new(0f, area.yMin + 0.32f), 2.1f);
    }

    private void Stop(int index)
    {
        var reel = reels[index];
        if (!reel.Spinning || reel.StopTarget.HasValue) return;
        //すぐには止まらず、次の目まで進んでから止まる
        reel.StopTarget = Mathf.Floor(reel.Position) + 1f;
    }

    private void Respin()
    {
        foreach (var reel in reels)
        {
            reel.Spinning = true;
            reel.StopTarget = null;
            reel.Speed = RandomRange(7f, 9.5f);
        }
    }

    public override void Update()
    {
        foreach (var reel in reels)
        {
            if (reel.Spinning)
            {
                if (reel.StopTarget is float stopAt)
                {
                    //止める位置へ減速しながら近づく
                    reel.Position = Mathf.MoveTowards(reel.Position, stopAt, Math.Max(1.5f, (stopAt - reel.Position) * 12f) * Time.deltaTime);
                    if (Mathf.Abs(reel.Position - stopAt) < 0.001f)
                    {
                        reel.Position = stopAt;
                        reel.Spinning = false;
                    }
                }
                else reel.Position += reel.Speed * Time.deltaTime;
            }

            int count = reel.Items.Length;
            for (int k = 0; k < count; k++)
            {
                //帯をぐるりと回す。位置が増えるほど目は下へ流れる
                float offset = ((k - reel.Position) % count + count) % count;
                if (offset > count * 0.5f) offset -= count;
                var pos = reel.Items[k].localPosition;
                reel.Items[k].localPosition = new(pos.x, reelY + offset * SymbolPitch, pos.z);
            }
        }

        if (respinTimer >= 0f)
        {
            respinTimer -= Time.deltaTime;
            if (respinTimer < 0f) Respin();
            return;
        }

        //すべて止まったら、真ん中の段を確かめる。結果を見せている間は確かめ直さない
        if (!IsFinishing && reels.All(r => !r.Spinning))
        {
            //同意するが揃えば同意、同意しないが揃えば同意しなかったことになる
            if (reels.All(r => r.CenterIsAgree)) FinishAfter(true);
            else if (reels.All(r => !r.CenterIsAgree)) FinishAfter(false);
            //どちらも揃わなければ、回数の制限なく回り直す
            else respinTimer = RespinDelay;
        }
    }
}
