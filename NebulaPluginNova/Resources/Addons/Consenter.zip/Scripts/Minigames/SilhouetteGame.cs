namespace Consenter;

/// <summary>
/// 人間であることの確認(画像の選択)を模したミニゲームです。
/// キル演出の画像から作った白黒のクルーメイト(倒されかけのものも含む)とインポスターの影絵が並ぶので、指示された方をすべて塗りつぶしてから同意します。
/// ウマを選ぶ問題のときだけ、ウマの影絵も並びます。インポスターやクルーメイトを選ぶ問題では、ウマは並びません。
/// 指示は画像認証の画面のように、タイルの上の青い帯に出します。選び方が違うと失敗します。
/// </summary>
public class SilhouetteGame : ConsentGame
{
    public override Vector2 DialogSize => new(5.8f, 5.3f);
    //最初はStandardと同じ画面を見せ、同意するを押すと窓が広がって始まる
    public override bool UsesStandardIntro => true;
    public override float? IdleTimeout => 15f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int Columns = 4;
    private const int Rows = 3;
    private const float TileSize = 0.92f;
    private const float Pitch = 1f;

    private enum Kind { Crewmate, Impostor, Horse }
    //ウマを選ぶ問題になる確率
    private const float HorseChance = 0.2f;

    private readonly Kind target = UnityEngine.Random.value < HorseChance ? Kind.Horse : UnityEngine.Random.value < 0.5f ? Kind.Impostor : Kind.Crewmate;
    private readonly Kind[] kinds = new Kind[Columns * Rows];
    private readonly bool[] selected = new bool[Columns * Rows];

    public override void Begin()
    {
        var area = ContentArea;
        int tiles = Columns * Rows;

        //指示された方が2～8枚になるようにする
        int numOfTargets = RandomInt(2, 9);
        var order = Enumerable.Range(0, tiles).ToArray();
        Shuffle(order);
        for (int i = 0; i < tiles; i++)
        {
            if (i < numOfTargets) kinds[order[i]] = target;
            //ウマを選ぶ問題では、それ以外はクルーメイトとインポスターを混ぜる
            else if (target == Kind.Horse) kinds[order[i]] = Random01 < 0.5f ? Kind.Crewmate : Kind.Impostor;
            else kinds[order[i]] = target == Kind.Impostor ? Kind.Crewmate : Kind.Impostor;
        }

        //画像認証の画面のように、タイルの上の青い帯に指示を出す
        const float headerHeight = 0.5f;
        float headerY = area.yMax - headerHeight * 0.5f;
        ConsentUI.Box(Root, "Header", new(0f, headerY, -0.2f), new(Columns * Pitch, headerHeight), new(0.26f, 0.52f, 0.96f));
        ConsentUI.Text(Root, new(0f, headerY, -0.25f), new(Columns * Pitch - 0.2f, headerHeight), 1.3f, Color.white, TextAlignmentOptions.Center,
            Language.Translate(target switch
            {
                Kind.Impostor => "consenter.minigame.silhouette.impostor",
                Kind.Horse => "consenter.minigame.silhouette.horse",
                _ => "consenter.minigame.silhouette.crewmate",
            }));

        var center = new Vector2(0f, area.yMin + 0.75f + (area.height - 0.75f - headerHeight - 0.08f) * 0.5f);
        for (int i = 0; i < tiles; i++)
        {
            int index = i;
            int x = i % Columns, y = i / Columns;
            var pos = new Vector3(center.x + (x - (Columns - 1) * 0.5f) * Pitch, center.y - (y - (Rows - 1) * 0.5f) * Pitch, -0.2f);
            var tile = ConsentUI.Box(Root, "Tile", pos, new(TileSize, TileSize), new(0.93f, 0.93f, 0.93f));
            var images = kinds[i] switch
            {
                Kind.Impostor => ConsentAssets.Impostors,
                Kind.Horse => ConsentAssets.Horses,
                _ => ConsentAssets.Crewmates,
            };
            //画像の大きさはまちまちなので、タイルに収まるように縮める。向きもばらばらにする
            var sprite = images[RandomInt(images.Length)].GetSprite();
            var silhouette = ConsentUI.Sprite(Root, "Silhouette", pos + new Vector3(0f, 0f, -0.01f), sprite, null, TileSize * 0.95f / Math.Max(sprite.bounds.size.x, sprite.bounds.size.y));
            silhouette.flipX = Random01 < 0.5f;

            //選んだタイルは塗りつぶす
            var fill = ConsentUI.Box(Root, "Fill", pos + new Vector3(0f, 0f, -0.02f), new(TileSize, TileSize), new(0.25f, 0.55f, 1f, 0.6f));
            var mark = ConsentUI.Sprite(Root, "Mark", pos + new Vector3(TileSize * 0.3f, TileSize * 0.3f, -0.03f), ConsentAssets.CheckMark.GetSprite(), null, 0.4f);
            fill.gameObject.SetActive(false);
            mark.gameObject.SetActive(false);

            Clicks.Add(tile.transform, new Vector2(0.16f, 0.16f), () =>
            {
                selected[index] = !selected[index];
                fill.gameObject.SetActive(selected[index]);
                mark.gameObject.SetActive(selected[index]);
            });
        }

        float buttonY = area.yMin + 0.32f;
        bool agreeOnLeft = Random01 < 0.5f;
        AddAgreeButton(new(agreeOnLeft ? -1.3f : 1.3f, buttonY), 2.1f, () =>
        {
            for (int i = 0; i < tiles; i++)
            {
                if (selected[i] != (kinds[i] == target))
                {
                    Fail();
                    return;
                }
            }
            Succeed();
        });
        AddDisagreeButton(new(agreeOnLeft ? 1.3f : -1.3f, buttonY), 2.1f);
    }
}
