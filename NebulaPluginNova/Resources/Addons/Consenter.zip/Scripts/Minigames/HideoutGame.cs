using Nebula.Behavior;
using Nebula.Game;
using Virial;
using GamePlayer = Virial.Game.Player;

namespace Consenter;

/// <summary>
/// 同意ボタンがマップのどこかの端末に逃げ込むミニゲームです。最初はStandardと全く同じ見た目です。
/// 同意するを押すと「同意ボタンがどこかに逃げ込んだ！」と出て、窓を閉じると、マップの端末16個(元の端末を除く)が使えるようになります。
/// 逃げ込んだ端末と端末の探し方は<see cref="HideoutConsent"/>が扱います。
/// </summary>
public class HideoutGame : ConsentGame
{
    public override Vector2 DialogSize => StandardDialogSize;
    public override float DialogScale => 1f;
    public override float? IdleTimeout => null;

    private bool escaped = false;
    private float escapedTime = 0f;

    public override void Begin()
    {
        TextMeshPro body = null!;
        ConsentTitleButton agree = null!, disagree = null!;
        (body, agree, disagree) = CreateStandardScreen(() =>
        {
            if (escaped) return;
            escaped = true;
            escapedTime = Elapsed;

            //同意ボタンが逃げ出す
            Clicks.Disable(agree.Transform);
            Clicks.Disable(disagree.Transform);
            agree.GameObject.SetActive(false);
            disagree.GameObject.SetActive(false);
            body.alignment = TextAlignmentOptions.Center;
            body.fontSize = 2.4f;
            body.color = new(1f, 0.9f, 0.4f);
            body.text = Language.Translate("consenter.minigame.hideout");
            AddTitleButton(new(0f, StandardButtonY), 1.8f, "OK", ConsentButtonStyle.Neutral, Host.ReleaseHideout);
        });
    }

    public override void Update()
    {
        //しばらくしたら勝手に閉じる
        if (escaped && Elapsed - escapedTime > 4f) Host.ReleaseHideout();
    }
}

/// <summary>
/// はずれの端末を開けたときに出る窓です。正解の端末がどちらにあるかを伝えます。
/// 最後の1回を使い切ったときは、ヒントの代わりに同意しないボタンを出し、押すか、閉じるか、開いてから5秒経つと失敗になります。
/// 残りの回数(「4/5」など)は、この窓を閉じたときに見せます。
/// </summary>
public class HideoutHintGame : ConsentGame
{
    private readonly HideoutConsent hideout;
    private readonly string? hintKey;
    private const float LastTimeLimit = 5f;

    /// <param name="hintKey">ヒントの文言の翻訳キーです。nullなら最後の1回を使い切ったときの窓になります。</param>
    public HideoutHintGame(HideoutConsent hideout, string? hintKey)
    {
        this.hideout = hideout;
        this.hintKey = hintKey;
    }

    public override Vector2 DialogSize => StandardDialogSize;
    public override float DialogScale => 1f;
    public override float? IdleTimeout => null;
    private bool IsLast => hintKey == null;

    public override void Begin()
    {
        if (IsLast)
        {
            //ヒントの代わりに同意しないボタンだけを出す
            AddDisagreeButton(new(0f, 0f), StandardButtonWidth, Host.Close);
        }
        else
        {
            AddText(new(0f, 0.2f, -0.5f), new(DialogSize.x - 0.4f, 0.9f), 2.4f, Language.Translate(hintKey!), new(1f, 0.9f, 0.4f));
            AddTitleButton(new(0f, StandardButtonY), 1.8f, "OK", ConsentButtonStyle.Neutral, Host.Close);
        }
    }

    public override void Update()
    {
        if (IsLast && Elapsed > LastTimeLimit) Host.Close();
    }

    public override void OnClose()
    {
        if (IsLast) hideout.Fail();
        else hideout.ShowRemaining();
    }
}

/// <summary>
/// 正解の端末を開けたときに出る窓です。Standardと同じ画面(規約の本文と、同意する・同意しないのボタン)をもう一度見せます。
/// 同意するを押すと同意でき、同意しないを押すと失敗します。押さずに閉じても、正解の端末をもう一度開けば、また同じ窓が出ます。
/// </summary>
public class HideoutFoundGame : ConsentGame
{
    private readonly HideoutConsent hideout;
    public HideoutFoundGame(HideoutConsent hideout) { this.hideout = hideout; }

    public override Vector2 DialogSize => StandardDialogSize;
    public override float DialogScale => 1f;
    public override float? IdleTimeout => null;

    public override void Begin()
    {
        CreateStandardScreen(
            () =>
            {
                hideout.Agree();
                Host.Close();
            },
            () =>
            {
                hideout.Fail();
                Host.Close();
            });
    }
}

/// <summary>
/// 同意ボタンが逃げ込んだ端末を探すものです。マップの端末16個(元の端末を除く)が使えるようになり、そのうち1つにだけ同意ボタンがあります。
/// はずれの端末を開けると回数を1つ使い、正解の端末がそこより上・下・左・右のどちらにあるかが窓で出ます。ミニマップにも、開けた端末の位置に太い矢印で出ます。
/// 正解の端末を開けると、Standardと同じ画面がもう一度出ます。それ以降はほかの端末は使えなくなり、正解の端末だけが何度でも開けます。同意するを押すと同意できます。
/// 5回使い切ると失敗します。残りの回数は、画面の中央に「5/5」のように出ます(最初は逃げ込んだ知らせの窓を、その後はヒントの窓を閉じたとき)。
/// </summary>
public class HideoutConsent
{
    public const int NumOfConsoles = 16;
    public const int MaxAttempts = 5;
    static private readonly Color ArrowColor = new(1f, 0.9f, 0.35f);
    private const float MapArrowSize = 0.38f;

    private class Entry
    {
        public Console Console = null!;
        public GameObject? Point;
        public bool Opened;
        //正解の方向(右を0とした度数)
        public float HintAngle;
        public PooledMapIcon? MapIcon;
        public SpriteRenderer? MapArrow;
    }

    private readonly Consenter.Instance? owner;
    private readonly GameObject holder;
    private readonly List<Entry> entries = [];
    private readonly int correct;
    private bool mapWasOpen = false;
    //正解の端末を見つけたか。見つけた後は、ほかの端末は使えない
    private bool found = false;

    /// <summary>あと何回端末を開けられるかです。</summary>
    public int Remaining { get; private set; } = MaxAttempts;
    public bool IsAlive => holder;

    private HideoutConsent(Consenter.Instance? owner, Console? exclude)
    {
        this.owner = owner;
        var behaviour = UnityHelper.CreateObject<ScriptBehaviour>("HideoutConsent", null, Vector3.zero);
        holder = behaviour.gameObject;
        behaviour.UpdateHandler += Update;

        //元の端末を除いて、ランダムに16個選ぶ
        var candidates = Consenter.GetConsentConsoles().Where(c => !exclude || c.GetInstanceID() != exclude!.GetInstanceID()).ToArray();
        for (int i = candidates.Length - 1; i > 0; i--)
        {
            int j = UnityEngine.Random.Range(0, i + 1);
            (candidates[i], candidates[j]) = (candidates[j], candidates[i]);
        }
        foreach (var console in candidates.Take(NumOfConsoles)) entries.Add(CreateEntry(console));
        correct = entries.Count > 0 ? UnityEngine.Random.Range(0, entries.Count) : -1;

        ShowRemaining();
    }

    /// <summary>
    /// 同意ボタンを逃げ込ませます。ownerがnullの場合は、デバッグ用に結果を画面の色で示すだけにします。
    /// </summary>
    static public HideoutConsent Start(Consenter.Instance? owner, Console? exclude) => new(owner, exclude);

    private Entry CreateEntry(Console console)
    {
        var entry = new Entry() { Console = console };
        var image = console.Image;
        entry.Point = UnityHelper.CreateObject("HideoutPoint", image.transform, Vector3.zero);
        var custom = entry.Point.AddComponent<CustomConsole>();
        custom.Renderer = image;
        custom.Property = new()
        {
            CanUse = _ => !entry.Opened && (!found || IsCorrect(entry)) && IsAlive && PlayerControl.LocalPlayer && (GamePlayer.LocalPlayer?.CanMove ?? false),
            Use = _ => Open(entry),
            OutlineColor = Consenter.MyRole.UnityColor,
            UsableDistance = Math.Max(console.usableDistance, 0.8f),
        };
        return entry;
    }

    /// <summary>
    /// 画面の中央に残りの回数を「5/5」のように出します。
    /// </summary>
    public void ShowRemaining()
    {
        if (!IsAlive) return;
        NebulaAPI.CurrentGame?.GetModule<TitleShower>()?.SetText($"{Remaining}/{MaxAttempts}", Consenter.MyRole.RoleColor, 3f);
    }

    private bool IsCorrect(Entry entry) => entries.IndexOf(entry) == correct;

    private void Open(Entry entry)
    {
        if (!IsAlive || entry.Opened) return;

        if (IsCorrect(entry))
        {
            //見つけたら、ほかの端末は使えなくする。正解の端末はそのまま残し、同意するを押し損ねても開き直せるようにする
            if (!found)
            {
                found = true;
                foreach (var other in entries) if (!IsCorrect(other)) RemovePoint(other);
                if (MapBehaviour.Instance && MapBehaviour.Instance.IsOpen) UpdateMapIcons();
            }
            ConsentMinigame.Open(minigame => minigame.SetUpCustom(new HideoutFoundGame(this)));
            return;
        }

        entry.Opened = true;
        RemovePoint(entry);

        //回数を使う
        Remaining--;

        //正解の端末が、上下左右のどちらにあるか(大きくずれている方)を求める
        Vector2 diff = (Vector2)entries[correct].Console.transform.position - (Vector2)entry.Console.transform.position;
        string hintKey;
        if (Mathf.Abs(diff.x) > Mathf.Abs(diff.y))
        {
            entry.HintAngle = diff.x > 0f ? 0f : 180f;
            hintKey = diff.x > 0f ? "consenter.hideout.hint.right" : "consenter.hideout.hint.left";
        }
        else
        {
            entry.HintAngle = diff.y > 0f ? 90f : 270f;
            hintKey = diff.y > 0f ? "consenter.hideout.hint.up" : "consenter.hideout.hint.down";
        }
        if (MapBehaviour.Instance && MapBehaviour.Instance.IsOpen) UpdateMapIcons();

        //ヒントの窓を開く。最後の1回を使い切ったら、ヒントの代わりに同意しないボタンを出す
        ConsentMinigame.Open(minigame => minigame.SetUpCustom(new HideoutHintGame(this, Remaining > 0 ? hintKey : null)));
    }

    /// <summary>
    /// 見つけた同意するボタンを押したときに、同意させます。
    /// </summary>
    public void Agree()
    {
        if (IsAlive) Resolve(true);
    }

    /// <summary>
    /// 回数を使い切ったときに、同意に失敗させます。
    /// </summary>
    public void Fail()
    {
        if (IsAlive) Resolve(false);
    }

    private void RemovePoint(Entry entry)
    {
        if (entry.Point) GameObject.Destroy(entry.Point);
        entry.Point = null;
        if (entry.Console && entry.Console.Image) entry.Console.Image.material.SetFloat("_Outline", 0f);
    }

    private void Resolve(bool agreed)
    {
        Dispose();
        if (owner != null) owner.OnHideoutResolved(agreed);
        else ConsentNotice.ShowResult(agreed);
    }

    public void Dispose()
    {
        foreach (var entry in entries)
        {
            RemovePoint(entry);
            if (entry.MapIcon) GameObject.Destroy(entry.MapIcon!.gameObject);
            if (entry.MapArrow) GameObject.Destroy(entry.MapArrow!.gameObject);
        }
        if (holder) GameObject.Destroy(holder);
    }

    private void Update()
    {
        //デバッグ用のものは会議が始まったら片付ける。同意者のものは同意者が片付ける
        if (owner == null && (MeetingHud.Instance || ExileController.Instance))
        {
            Dispose();
            return;
        }

        //ミニマップを開いたときに、マークを付け直す
        bool mapOpen = MapBehaviour.Instance && MapBehaviour.Instance.IsOpen;
        if (mapOpen && !mapWasOpen) UpdateMapIcons();
        mapWasOpen = mapOpen;
    }

    /// <summary>
    /// ミニマップに、まだ開けていない端末をタスクと同じ黄色いマークで、開けた端末を正解の方向を向いた太い矢印で示します。
    /// マークはタスクの表示(MapTaskOverlay)の下に置くので、アドミンでは表示されません。
    /// </summary>
    public void UpdateMapIcons()
    {
        if (!MapBehaviour.Instance || !ShipStatus.Instance || !IsAlive) return;
        var overlay = MapBehaviour.Instance.taskOverlay;
        foreach (var entry in entries)
        {
            Vector3 localPos = (Vector2)entry.Console.transform.position / ShipStatus.Instance.MapScale;
            localPos.z = -1f;
            if (!entry.Opened)
            {
                if (found && !IsCorrect(entry))
                {
                    if (entry.MapIcon) entry.MapIcon!.gameObject.SetActive(false);
                    continue;
                }
                if (!entry.MapIcon)
                {
                    entry.MapIcon = GameObject.Instantiate(overlay.icons.Prefab.GetComponent<PooledMapIcon>(), overlay.transform);
                    entry.MapIcon.name = "HideoutConsole";
                    entry.MapIcon.rend.color = Color.yellow;
                    entry.MapIcon.transform.localScale = new(entry.MapIcon.NormalSize, entry.MapIcon.NormalSize, entry.MapIcon.NormalSize);
                }
                entry.MapIcon!.transform.localPosition = localPos;
                entry.MapIcon.gameObject.SetActive(true);
            }
            else
            {
                if (entry.MapIcon) entry.MapIcon!.gameObject.SetActive(false);
                if (!entry.MapArrow)
                {
                    var sprite = ConsentAssets.HideoutArrow.GetSprite();
                    entry.MapArrow = ConsentUI.Sprite(overlay.transform, "HideoutArrow", localPos, sprite, ArrowColor, MapArrowSize / sprite.bounds.size.x);
                    entry.MapArrow.transform.localEulerAngles = new(0f, 0f, entry.HintAngle);
                }
                entry.MapArrow!.transform.localPosition = localPos;
            }
        }
    }
}
