namespace Consenter;

/// <summary>
/// 偽物のカバーを被ったボタンのミニゲームです。最初はStandardと全く同じ見た目です。
/// 2つのボタンにはそれぞれ、本当の文字とは逆のカバーの文字が書かれていて、色もカバーの文字に合わせてあります。
/// つまり、同意するに見えるボタンが本当は同意しないで、同意しないに見えるボタンが本当は同意するです。
/// カーソルを合わせると、カバーの文字がすっと透明になって、本当の文字がすっと現れます。カーソルを離すと、またカバーの文字に戻ります。
/// 押したときの結果は本当の文字のとおりで、本当の同意するを押すと同意でき、本当の同意しないを押すと失敗します。
/// </summary>
public class FakeCoverGame : ConsentGame
{
    public override Vector2 DialogSize => StandardDialogSize;
    public override float DialogScale => 1f;

    //文字が消えてから現れるまでの、片道の時間
    private const float FadeDuration = 0.12f;

    private class CoveredButton
    {
        public ConsentTitleButton Button = null!;
        public string CoverLabel = "";
        public string TrueLabel = "";
        public bool ShowingTrue = false;
        public float Alpha = 1f;
    }

    private readonly List<CoveredButton> buttons = [];

    public override void Begin()
    {
        var (_, agree, disagree) = CreateStandardScreen(Succeed, Fail);

        //カバーの文字は必ず本当の文字の逆にし、カバーが取れたら必ず文字が入れ替わるようにする。色もカバーの文字に合わせる
        foreach (var (button, trueLabel, isAgree) in new[] { (agree, ConsentUI.AgreeText, true), (disagree, ConsentUI.DisagreeText, false) })
        {
            bool coverIsAgree = !isAgree;
            var covered = new CoveredButton()
            {
                Button = button,
                CoverLabel = coverIsAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText,
                TrueLabel = trueLabel,
            };
            button.SetStyle(coverIsAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree);
            button.SetLabel(covered.CoverLabel);
            buttons.Add(covered);
        }
    }

    public override void Update()
    {
        var hovered = Clicks.Hovered?.Transform;
        foreach (var covered in buttons)
        {
            bool wantTrue = hovered == covered.Button.Transform;
            if (covered.ShowingTrue != wantTrue)
            {
                //今の文字を透明にしていき、消えきったら文字を差し替える
                covered.Alpha -= Time.deltaTime / FadeDuration;
                if (covered.Alpha <= 0f)
                {
                    covered.Alpha = 0f;
                    covered.ShowingTrue = wantTrue;
                    covered.Button.SetLabel(wantTrue ? covered.TrueLabel : covered.CoverLabel);
                }
            }
            else covered.Alpha = Math.Min(1f, covered.Alpha + Time.deltaTime / FadeDuration);

            if (covered.Button.Text) covered.Button.Text!.alpha = covered.Alpha;
        }
    }
}
