namespace Consenter;

/// <summary>
/// 枠の中を飛び回る同意する・同意しないのボタンに、弾を撃って当てるミニゲームです。
/// 砲台は左右に首を振っていて、発射ボタンで今向いている方へ弾を撃ちます。弾は飛ぶのに時間がかかるので、動きを読んで撃つ必要があります。
/// 弾が同意するに当たれば同意でき、同意しないに当たるか、3発を撃ち切って外すと失敗します。
/// </summary>
public class RaycastGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.4f, 4.8f);
    //最初はStandardと同じ画面を見せ、同意するを押すと窓が広がって始まる
    public override bool UsesStandardIntro => true;
    public override float? IdleTimeout => 15f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int MaxShots = 3;
    private const int NumOfDisagree = 2;
    private const float BulletSpeed = 2.6f;
    private const float BulletRadius = 0.07f;
    private static readonly Vector2 TargetSize = new(1.1f, 0.36f);

    private class Target
    {
        public ConsentSimpleButton Button = null!;
        public Vector2 Position;
        public Vector2 Velocity;
        public bool IsAgree;
    }

    private class Bullet
    {
        public SpriteRenderer Renderer = null!;
        public Vector2 Position;
        public Vector2 Velocity;
    }

    private Rect field;
    private Rect flyArea;
    private Vector2 cannonPos;
    private ConsentCannon cannon = null!;
    private float cannonAngle;
    private float sweepPhase;
    private readonly List<Target> targets = [];
    private readonly List<Bullet> bullets = [];
    private int shots = 0;
    private TextMeshPro counter = null!;

    public override void Begin()
    {
        var area = ContentArea;
        field = Rect.MinMaxRect(area.xMin, area.yMin + 0.75f, area.xMax, area.yMax);
        ConsentUI.Box(Root, "Field", new(field.center.x, field.center.y, -0.05f), field.size, new(0f, 0f, 0f, 0.3f));
        //ボタンが飛び回るのは枠の上の方
        flyArea = Rect.MinMaxRect(field.xMin + TargetSize.x * 0.5f, field.yMin + 1.1f, field.xMax - TargetSize.x * 0.5f, field.yMax - TargetSize.y * 0.5f);

        for (int i = 0; i < NumOfDisagree + 1; i++)
        {
            bool isAgree = i == 0;
            var style = isAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree;
            var target = new Target()
            {
                IsAgree = isAgree,
                Position = new(RandomRange(flyArea.xMin, flyArea.xMax), RandomRange(flyArea.yMin, flyArea.yMax)),
                Velocity = UnityEngine.Random.insideUnitCircle.normalized * RandomRange(1.1f, 1.7f),
            };
            target.Button = ConsentUI.SimpleButton(Root, "Target", new(target.Position.x, target.Position.y, -0.2f - i * 0.05f), TargetSize, isAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText, style, 0.9f);
            targets.Add(target);
        }

        cannonPos = new(field.center.x, field.yMin + 0.25f);
        cannon = new ConsentCannon(Root, new(cannonPos.x, cannonPos.y, -0.25f), 0.5f);
        sweepPhase = RandomRange(0f, Mathf.PI * 2f);

        AddTitleButton(new(0f, area.yMin + 0.32f), 2.2f, Language.Translate("consenter.minigame.raycast.fire"), ConsentButtonStyle.Neutral, Fire);
        counter = AddText(new(field.xMax - 0.8f, area.yMin + 0.32f, -0.5f), new(1.5f, 0.3f), 1.2f, "", new(1f, 0.95f, 0.6f));
        RefreshCounter();
    }

    private void RefreshCounter() => counter.text = Language.Translate("consenter.minigame.raycast.remaining").Replace("%NUM%", (MaxShots - shots).ToString());

    private Vector2 CannonDirection => new(Mathf.Cos(cannonAngle * Mathf.Deg2Rad), Mathf.Sin(cannonAngle * Mathf.Deg2Rad));

    private void Fire()
    {
        if (shots >= MaxShots) return;
        shots++;
        RefreshCounter();
        var pos = cannon.Muzzle;
        bullets.Add(new Bullet()
        {
            Position = pos,
            Velocity = CannonDirection * BulletSpeed,
            Renderer = ConsentUI.Circle(Root, "Bullet", new(pos.x, pos.y, -0.35f), BulletRadius, new(1f, 0.9f, 0.4f)),
        });
    }

    public override void Update()
    {
        //砲台は左右に首を振る
        sweepPhase += Time.deltaTime * 1.4f;
        cannonAngle = 90f + Mathf.Sin(sweepPhase) * 60f;
        cannon.Angle = cannonAngle;

        //ボタンは枠の中で跳ね返りながら飛び回る
        foreach (var target in targets)
        {
            target.Position += target.Velocity * Time.deltaTime;
            if (target.Position.x < flyArea.xMin || target.Position.x > flyArea.xMax) target.Velocity.x = -target.Velocity.x;
            if (target.Position.y < flyArea.yMin || target.Position.y > flyArea.yMax) target.Velocity.y = -target.Velocity.y;
            target.Position = new(Mathf.Clamp(target.Position.x, flyArea.xMin, flyArea.xMax), Mathf.Clamp(target.Position.y, flyArea.yMin, flyArea.yMax));
            var z = target.Button.Transform.localPosition.z;
            target.Button.Transform.localPosition = new(target.Position.x, target.Position.y, z);
        }

        for (int i = bullets.Count - 1; i >= 0; i--)
        {
            var bullet = bullets[i];
            bullet.Position += bullet.Velocity * Time.deltaTime;
            bullet.Renderer.transform.localPosition = new(bullet.Position.x, bullet.Position.y, -0.35f);

            foreach (var target in targets)
            {
                var diff = bullet.Position - target.Position;
                if (Mathf.Abs(diff.x) < TargetSize.x * 0.5f + BulletRadius && Mathf.Abs(diff.y) < TargetSize.y * 0.5f + BulletRadius)
                {
                    if (target.IsAgree) Succeed();
                    else Fail();
                    return;
                }
            }

            if (!field.Contains(bullet.Position))
            {
                GameObject.Destroy(bullet.Renderer.gameObject);
                bullets.RemoveAt(i);
            }
        }

        //撃ち切って、飛んでいる弾もなくなったら失敗
        if (shots >= MaxShots && bullets.Count == 0) Fail();
    }
}
