namespace Consenter;

/// <summary>
/// ピンに引っかかりながら落ちてくる玉を、マウスに付いて動く空のボタンで受け止めるミニゲームです。
/// 空のボタンは文字の無い灰色の枠で、緑の玉を受け止めるたびに中のメーターが溜まります(濃い灰色の領域が、薄い灰色で埋まっていく)。
/// メーターが満ちるとボタンは同意するに変わり、押すと同意できます。赤い玉を受け止めると失敗します。玉は文字の無い、色だけの玉です。
/// 制限時間があり、時間内にメーターを満たせないと失敗します。残り時間は一番上の細いゲージで分かります。玉はその下から、大きさ0からにゅっと現れます。
/// 途中で閉じても、集めた数と残り時間は覚えておき、開き直すと続きから始まります。
/// 一部の玉は、2段目のピンまで来たときに0.2秒かけて緑と赤の見た目が入れ替わります。入れ替わった後の見た目が正しい色です。
/// ピンに引っかかった玉は、しばらくすると揺れて落ちます。クリックして弾くこともできます。
/// </summary>
public class FallingPinsGame : ConsentGame
{
    //残り時間のゲージと玉の出てくる場所を分けるため、少し縦に長くする
    public override Vector2 DialogSize => new(6.4f, 5.1f);
    //最初はStandardと同じ画面を見せ、同意するを押すと窓が広がって始まる。途中から再開するときは見せない
    public override bool UsesStandardIntro => !restored;
    private bool restored = false;
    //自前の制限時間があるので、放置の時間切れは無し
    public override float? IdleTimeout => null;

    /// <summary>
    /// 途中で閉じたときに覚えておく状態です。
    /// </summary>
    private class State
    {
        public int Collected;
        public float TimeUsed;
    }

    //制限時間のうち使った時間
    private float timeUsed = 0f;

    public override object? SaveState() => new State() { Collected = collected, TimeUsed = timeUsed };

    public override void RestoreState(object saved)
    {
        if (saved is not State state) return;
        restored = true;
        collected = state.Collected;
        timeUsed = state.TimeUsed;
        meterRate = (float)collected / Required;
    }

    //残り時間のゲージの高さ(場の上端から)
    private const float TimeGaugeOffset = 0.1f;
    //玉の出てくる場所は、ゲージより下にする
    private const float BoardTopMargin = 0.35f;
    public override string? InstructionKey => GeneralInstructionKey;

    private class Chip
    {
        public PhysicsBall Ball = null!;
        public SpriteRenderer Renderer = null!;
        public bool IsGood;
        public float StuckTime;
        //2段目のピンまで来たら見た目の色が入れ替わる玉
        public bool WillSwitch;
        //色が入れ替わり始めてからの時間。入れ替わっていなければ負
        public float SwitchTime = -1f;
    }

    private const int Required = 8;
    private const float TimeLimit = 30f;
    private const float ChipRadius = 0.17f * 0.8f;
    private const float SwitchDuration = 0.2f;
    static private readonly Vector2 CatcherSize = new(1.3f, 0.42f);
    static private readonly Color MeterEmptyColor = new(0.32f, 0.32f, 0.34f);
    static private readonly Color MeterFilledColor = new(0.72f, 0.72f, 0.75f);

    private readonly ConsentPhysics physics = new() { Gravity = new(0f, -4.5f), Restitution = 0.45f };
    private readonly List<Chip> chips = [];
    private int collected = 0;
    private float spawnTimer = 0f;
    private float catcherY;
    private Rect board;
    private float secondRowY;

    private Transform catcher = null!;
    private SpriteRenderer frame = null!;
    private SpriteRenderer meter = null!;
    private TextMeshPro agreeText = null!;
    private float meterRate = 0f;

    private bool Completed => collected >= Required;
    private SpriteRenderer timeGauge = null!;
    private float timeGaugeWidth;

    public override void Begin()
    {
        var area = ContentArea;
        catcherY = area.yMin + 0.28f;
        board = Rect.MinMaxRect(area.xMin, catcherY + 0.4f, area.xMax, area.yMax - BoardTopMargin);

        physics.AddSegment(new(board.xMin, area.yMin - 1f), new(board.xMin, board.yMax + 1f));
        physics.AddSegment(new(board.xMax, area.yMin - 1f), new(board.xMax, board.yMax + 1f));

        //ピンを互い違いに並べる
        int rows = 5;
        float rowPitch = (board.height - 0.5f) / rows;
        for (int r = 0; r < rows; r++)
        {
            float y = board.yMax - 0.45f - r * rowPitch;
            if (r == 1) secondRowY = y;
            float offset = r % 2 == 0 ? 0f : 0.3f;
            for (float x = board.xMin + 0.3f + offset; x < board.xMax - 0.15f; x += 0.6f)
            {
                physics.AddPeg(new(x, y), 0.06f);
                ConsentUI.Circle(Root, "Pin", new(x, y, -0.2f), 0.06f, new(0.8f, 0.8f, 0.85f));
            }
        }

        //空のボタン。灰色の枠の中に、溜まっていくメーターがある
        catcher = ConsentUI.Object(Root, "Catcher", new(0f, catcherY, -0.4f)).transform;
        frame = ConsentUI.Sliced(catcher, "Frame", Vector3.zero, ConsentAssets.RoundRect, CatcherSize, new(0.55f, 0.55f, 0.58f));
        var inner = CatcherSize - new Vector2(0.12f, 0.12f);
        ConsentUI.Box(catcher, "MeterBack", new(0f, 0f, -0.01f), inner, MeterEmptyColor);
        meter = ConsentUI.Box(catcher, "Meter", new(-inner.x * 0.5f, 0f, -0.02f), new(0.001f, inner.y), MeterFilledColor);
        agreeText = ConsentUI.Text(catcher, new(0f, 0f, -0.03f), CatcherSize, 1.4f * ConsentUI.SimpleButtonFontScale, ConsentAssets.AgreeTextColor, TextAlignmentOptions.Center, ConsentUI.AgreeText);
        agreeText.gameObject.SetActive(false);

        //残り時間のゲージ
        timeGaugeWidth = area.width;
        ConsentUI.Box(Root, "TimeBack", new(area.center.x, area.yMax - TimeGaugeOffset, -0.1f), new(timeGaugeWidth, 0.08f), new(0.2f, 0.2f, 0.2f));
        timeGauge = ConsentUI.Box(Root, "Time", new(area.center.x, area.yMax - TimeGaugeOffset, -0.11f), new(timeGaugeWidth, 0.08f), new(1f, 0.85f, 0.4f));

        Clicks.Add(catcher, CatcherSize, () =>
        {
            if (Completed) Succeed();
            else Shake(catcher);
        });
    }

    private void UpdateMeter()
    {
        //メーターはなめらかに伸ばす
        meterRate = Mathf.MoveTowards(meterRate, (float)collected / Required, Time.deltaTime * 2f);
        var inner = CatcherSize - new Vector2(0.12f, 0.12f);
        float width = Math.Max(0.001f, inner.x * meterRate);
        meter.transform.localScale = new(width / 0.16f, inner.y / 0.16f, 1f);
        meter.transform.localPosition = new(-inner.x * 0.5f + width * 0.5f, 0f, -0.02f);

        //満ちたら同意するボタンになる
        if (Completed && meterRate >= 1f && !agreeText.gameObject.activeSelf)
        {
            agreeText.gameObject.SetActive(true);
            frame.color = ConsentAssets.AgreeColor;
            meter.gameObject.SetActive(false);
            catcher.Find("MeterBack")?.gameObject.SetActive(false);
        }
    }

    private void SpawnChip()
    {
        bool good = Random01 < 0.62f;
        var pos = new Vector2(RandomRange(board.xMin + 0.25f, board.xMax - 0.25f), board.yMax + 0.1f);
        var chip = new Chip() { Ball = physics.AddBall(pos, ChipRadius), IsGood = good, WillSwitch = Random01 < 0.3f };
        chip.Ball.Velocity = new(RandomRange(-0.5f, 0.5f), 0f);
        //入れ替わる玉は、最初は逆の色で見せる
        bool looksGood = chip.WillSwitch ? !good : good;
        chip.Renderer = ConsentUI.Circle(Root, "Chip", new(pos.x, pos.y, -0.3f), ChipRadius, looksGood ? ConsentAssets.AgreeColor : ConsentAssets.DisagreeColor);
        //いきなり出さず、大きさ0からにゅっと出す
        PopIn(chip.Renderer.transform);
        //ピンに引っかかったときはクリックで弾ける
        Clicks.Add(chip.Renderer.transform, new Vector2(1.28f, 1.28f), () =>
        {
            chip.Ball.Velocity += new Vector2(RandomRange(-1.2f, 1.2f), 1.2f);
        });
        chips.Add(chip);
    }

    private void RemoveChip(Chip chip)
    {
        physics.Balls.Remove(chip.Ball);
        if (chip.Renderer) GameObject.Destroy(chip.Renderer.gameObject);
        chips.Remove(chip);
    }

    public override void Update()
    {
        //空のボタンはマウスの左右に合わせて動く
        float halfWidth = CatcherSize.x * 0.5f;
        float mouseX = Mathf.Clamp(Clicks.MouseLocal(Root).x, board.xMin + halfWidth, board.xMax - halfWidth);
        var catcherPos = catcher.localPosition;
        catcher.localPosition = new(Mathf.Lerp(catcherPos.x, mouseX, Time.deltaTime * 12f), catcherY, catcherPos.z);
        UpdateMeter();

        //制限時間。満たした後は止める
        if (!Completed)
        {
            timeUsed += Time.deltaTime;
            float rate = Mathf.Clamp01(1f - timeUsed / TimeLimit);
            float width = Math.Max(0.001f, timeGaugeWidth * rate);
            timeGauge.transform.localScale = new(width / 0.16f, 0.08f / 0.16f, 1f);
            timeGauge.transform.localPosition = new(ContentArea.xMin + width * 0.5f, ContentArea.yMax - TimeGaugeOffset, -0.11f);
            if (rate <= 0f)
            {
                Fail();
                return;
            }
        }

        if (!Completed)
        {
            spawnTimer -= Time.deltaTime;
            if (spawnTimer < 0f && chips.Count < 14)
            {
                SpawnChip();
                spawnTimer = RandomRange(0.5f, 0.9f);
            }
        }

        physics.Step(Time.deltaTime);

        float catcherX = catcher.localPosition.x;
        foreach (var chip in chips.ToArray())
        {
            var ball = chip.Ball;

            //ピンの上で止まってしまったら揺らして落とす
            if (ball.TouchingPeg != null && ball.Velocity.sqrMagnitude < 0.04f)
            {
                chip.StuckTime += Time.deltaTime;
                if (chip.StuckTime > 0.8f)
                {
                    ball.Velocity += new Vector2(Random01 < 0.5f ? -0.8f : 0.8f, 0.4f);
                    chip.StuckTime = 0f;
                }
            }
            else chip.StuckTime = 0f;

            chip.Renderer.transform.localPosition = new(ball.Position.x, ball.Position.y, -0.3f);

            //2段目のピンまで来たら、なめらかに正しい色になる
            if (chip.WillSwitch && ball.Position.y < secondRowY)
            {
                chip.WillSwitch = false;
                chip.SwitchTime = 0f;
            }
            if (chip.SwitchTime >= 0f && chip.SwitchTime < SwitchDuration)
            {
                chip.SwitchTime += Time.deltaTime;
                var from = chip.IsGood ? ConsentAssets.DisagreeColor : ConsentAssets.AgreeColor;
                var to = chip.IsGood ? ConsentAssets.AgreeColor : ConsentAssets.DisagreeColor;
                chip.Renderer.color = Color.Lerp(from, to, Mathf.Clamp01(chip.SwitchTime / SwitchDuration));
            }

            //空のボタンで受け止める
            if (!Completed && ball.Velocity.y < 0f && Mathf.Abs(ball.Position.y - (catcherY + CatcherSize.y * 0.5f)) < 0.12f && Mathf.Abs(ball.Position.x - catcherX) < halfWidth)
            {
                if (!chip.IsGood)
                {
                    Fail();
                    return;
                }
                collected++;
                RemoveChip(chip);
                continue;
            }

            if (ball.Position.y < ContentArea.yMin - 0.4f) RemoveChip(chip);
        }

        //満ちたら残りの玉は片付ける
        if (Completed && chips.Count > 0) foreach (var chip in chips.ToArray()) RemoveChip(chip);
    }
}
