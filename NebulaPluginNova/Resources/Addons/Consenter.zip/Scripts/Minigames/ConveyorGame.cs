namespace Consenter;

/// <summary>
/// 横向きにループしながら流れるボタンの中から、同意するを押すミニゲームです。段ごとに向きと速さが違い、時間とともに速くなります。
/// 最初はStandardと同じ画面で、同意するを押すと、同意する・同意しないのボタンが真ん中の段へ動いて流れ始め、続いてコンベアのボタンが次々に出てきます。
/// 流れ始めてから3秒経つまでは、すべてのボタンが同意しないです。3秒経った後、そのうちの1つが見える範囲の外に初めて出たときに同意するに変わります。
/// 同意しないを押すと失敗します。
/// </summary>
public class ConveyorGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.6f, 4.6f);
    public override bool UsesStandardIntro => true;
    //コンベアのボタンは自前で次々に出す
    protected override float IntroPopInStagger => -1f;
    public override float? IdleTimeout => 15f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int NumOfRows = 5;
    private const int MiddleRow = NumOfRows / 2;
    //同意するに変われるようになるまでの時間
    private const float AgreeAppearTime = 3f;
    private const int ButtonsPerRow = 6;
    private const float Spacing = 1.55f;
    private static readonly Vector2 ButtonSize = new(1.3f, 0.4f);
    //導入のボタンが流れながら消えるまでの時間
    private const float CarryFadeDuration = 0.6f;

    private Rect viewport;
    private readonly List<(Transform transform, int row, int index)> buttons = [];
    private readonly float[] speeds = new float[NumOfRows];
    private readonly float[] offsets = new float[NumOfRows];
    private float rowLength;
    private ConsentSimpleButton agreeButton = null!;
    private ConsentClickable agreeClickable = null!;
    private bool agreeAppeared = false;
    private float startTime = 0f;

    //導入の同意する・同意しないのボタン。真ん中の段へ動き、流れながら消えていく
    private readonly List<ConsentTitleButton> carried = [];
    private readonly List<(Vector3 pos, Vector3 scale)> carryFrom = [];
    private float carryTime = 0f;

    private Rect MainViewport
    {
        get
        {
            var area = MainContentArea;
            return Rect.MinMaxRect(area.xMin, area.yMin + 0.1f, area.xMax, area.yMax - 0.05f);
        }
    }

    private float RowY(Rect view, int row) => view.yMax - view.height * (row + 0.5f) / NumOfRows;

    protected override void IntroGrow(float t, ConsentTitleButton agree, ConsentTitleButton disagree, TextMeshPro body)
    {
        if (body) body.alpha = 1f - t;
        if (carryFrom.Count == 0)
        {
            //窓の縮尺は1から始まるので、今の位置と大きさがそのまま縮尺1での値になる
            carryFrom.Add((agree.Transform.localPosition, agree.Transform.localScale));
            carryFrom.Add((disagree.Transform.localPosition, disagree.Transform.localScale));
        }

        //2つのボタンを、本番の真ん中の段の左右へ、コンベアのボタンの大きさまで縮めながら動かす
        float y = RowY(MainViewport, MiddleRow);
        var pair = new[] { agree, disagree };
        for (int i = 0; i < 2; i++)
        {
            var button = pair[i];
            var (fromPos, fromScale) = carryFrom[i];
            float x = fromPos.x < 0f ? -0.9f : 0.9f;
            var toPos = new Vector3(x, y, -0.3f) * DialogScale;
            var toScale = fromScale * (ButtonSize.x / button.Size.x) * DialogScale;
            PlaceInScaledRoot(button.Transform, fromPos, toPos, fromScale, toScale, t);
        }
    }

    protected override void IntroFinish(ConsentTitleButton agree, ConsentTitleButton disagree, TextMeshPro body)
    {
        if (body) GameObject.Destroy(body.gameObject);
        //2つのボタンは消さず、流れながら消えていくようにする
        carried.Add(agree);
        carried.Add(disagree);
    }

    public override void Begin()
    {
        startTime = Elapsed;
        var area = ContentArea;
        viewport = Rect.MinMaxRect(area.xMin, area.yMin + 0.1f, area.xMax, area.yMax - 0.05f);
        ConsentUI.Box(Root, "ViewportBack", new(viewport.center.x, viewport.center.y, -0.05f), viewport.size, new(0f, 0f, 0f, 0.25f));
        ConsentUI.Mask(Root, new(viewport.center.x, viewport.center.y, 0f), viewport.size);

        rowLength = ButtonsPerRow * Spacing;
        int agreeRow = RandomInt(NumOfRows);
        int agreeIndex = RandomInt(ButtonsPerRow);
        var holder = ConsentUI.Object(Root, "Buttons", new(0f, 0f, -0.2f)).transform;

        for (int row = 0; row < NumOfRows; row++)
        {
            speeds[row] = RandomRange(1.8f, 3.2f) * (row % 2 == 0 ? 1f : -1f);
            offsets[row] = RandomRange(0f, rowLength);
            float y = RowY(viewport, row);
            for (int i = 0; i < ButtonsPerRow; i++)
            {
                //最初はすべて同意しない。同意するになるものも、現れるまでは同意しないとして振る舞う
                var button = ConsentUI.SimpleButton(holder, "Button", new(0f, y, 0f), ButtonSize, ConsentUI.DisagreeText, ConsentButtonStyle.Disagree, 1.3f);
                var clickable = Clicks.Add(button.Transform, button.LocalRect, Fail);
                clickable.Predicate = () => viewport.Contains(Clicks.MouseLocal(Root));
                buttons.Add((button.Transform, row, i));
                if (row == agreeRow && i == agreeIndex)
                {
                    agreeButton = button;
                    agreeClickable = clickable;
                }
            }
        }
        ConsentUI.SetMasked(holder.gameObject);
        Arrange();

        //導入の後は、コンベアのボタンをばらばらの順に次々と出す
        if (PlayedIntro)
        {
            var order = buttons.Select(b => b.transform).ToArray();
            Shuffle(order);
            for (int i = 0; i < order.Length; i++) PopIn(order[i], 0.12f, 0.15f + i * 0.035f);
        }
    }

    private void Arrange()
    {
        foreach (var (transform, row, index) in buttons)
        {
            float x = ((index * Spacing + offsets[row]) % rowLength + rowLength) % rowLength - rowLength * 0.5f;
            var pos = transform.localPosition;
            transform.localPosition = new(x, pos.y, pos.z);
        }
    }

    public override void Update()
    {
        float time = Elapsed - startTime;

        //見えているうちに急に変わらないよう、見える範囲の外にいるときに変える
        if (!agreeAppeared && time >= AgreeAppearTime && Mathf.Abs(agreeButton.Transform.localPosition.x - viewport.center.x) > viewport.width * 0.5f + ButtonSize.x * 0.5f)
        {
            agreeAppeared = true;
            agreeButton.Background.color = ConsentAssets.AgreeColor;
            agreeButton.Text.color = ConsentAssets.AgreeTextColor;
            agreeButton.Text.text = ConsentUI.AgreeText;
            agreeClickable.OnClick = Succeed;
        }

        float speedUp = 1f + time * 0.08f;
        for (int row = 0; row < NumOfRows; row++) offsets[row] += speeds[row] * speedUp * Time.deltaTime;
        Arrange();

        //導入のボタンは、真ん中の段と同じ速さで流れながら消えていく
        if (carried.Count > 0)
        {
            carryTime += Time.deltaTime;
            float alpha = 1f - carryTime / CarryFadeDuration;
            foreach (var button in carried)
            {
                if (!button.GameObject) continue;
                var pos = button.Transform.localPosition;
                button.Transform.localPosition = new(pos.x + speeds[MiddleRow] * speedUp * Time.deltaTime, pos.y, pos.z);
                ConsentUI.SetAlpha(button.GameObject, Math.Max(0f, alpha));
            }
            if (alpha <= 0f)
            {
                foreach (var button in carried) if (button.GameObject) GameObject.Destroy(button.GameObject);
                carried.Clear();
            }
        }
    }
}
