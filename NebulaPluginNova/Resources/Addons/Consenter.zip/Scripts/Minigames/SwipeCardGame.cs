namespace Consenter;

/// <summary>
/// SkeldのカードをスワイプするタスクCardSlideGameの読み取り機で、同意ボタンが変形したカードをスワイプするミニゲームです。
/// 最初はStandardと同じ画面で、同意するを押すと窓が広がり、同意するボタンの背景が縦横に伸び縮みしてカードの形になりながら読み取り機へ差し込まれます。
/// 同意するの文字は、カードの右下へ寄っていきます。ボタンの絵は差し替えず、そのまま変形させて使います。
/// カードをちょうどよい速さ(バニラと同じ0.4～0.6秒)で右端までスワイプすると同意します。速すぎたり遅すぎたりしたときは、バニラと同じく何度でもやり直せます。
/// 読み取り機だけを見せ、財布と裏の背景は出しません。
/// 読み取りに3回失敗すると不同意になります。失敗の回数は、バニラの赤いランプとその左隣に足した2つの赤いランプで見せ、3つ目まで点くと不同意です。
/// </summary>
public class SwipeCardGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.4f, 3.6f);
    public override bool UsesStandardIntro => true;
    //本番の部品はこちらで出す。変形していくボタンは小さくしない
    protected override float IntroPopInStagger => -1f;
    public override float? IdleTimeout => 25f;
    public override string? InstructionKey => GeneralInstructionKey;

    //NoSが読み込んでいるSkeldの番号
    private const int SkeldMapId = 0;
    //カードを動かせる範囲と、受け付けるスワイプの時間(バニラと同じ)
    private const float XMin = -2.38f, XMax = 2.38f, CardY = 0.75f;
    private const float AcceptMin = 0.4f, AcceptMax = 0.6f;
    //同意するボタンがカードに変わるまでの時間
    private const float MorphDuration = 0.5f;
    //読み取り機の奥行きを縮める割合。手前と奥の板の間にカードが挟まるよう、奥行きの順番は残す
    private const float HolderDepthScale = 0.05f;
    //ボタンの中の奥行きを縮める割合。ボタン全体が読み取り機の板の間に収まるようにする
    private const float ButtonDepthScale = 0.01f;
    //カードの右下の文字と、カードの端との間
    private const float TextMargin = 0.1f;
    //カードの文字を、右下の位置からさらに上へずらす量
    private const float TextRaise = 0.08f;
    //不同意になるまでの失敗の回数
    private const int MaxFailures = 3;

    private static readonly Color Gray = new(0.45f, 0.45f, 0.45f);
    private static readonly Color Green = new(0f, 0.8f, 0f);

    private ConsentTitleButton? introAgree;
    private ConsentTitleButton button = null!;

    //変形の情報。座標はすべてボタンのローカル座標
    private record struct PartState(Transform Transform, Vector3 Position, Vector3 Scale);
    private readonly List<PartState> backgroundParts = [];
    private readonly List<(BoxCollider2D collider, Vector2 offset, Vector2 size)> rootColliders = [];
    private Vector2 rectCenter;
    private Vector2 finalStretch = Vector2.one;
    private Transform? textTransform;
    private Vector3 textFrom, textTo;
    private Vector3 morphFromPos;
    private float buttonScale = 1f;
    private float morphTime = 0f;
    private bool morphing = false;

    private Transform? col;
    private SpriteRenderer? redLight, greenLight;
    private TextMeshPro? statusText;
    private AudioClip? acceptSound, denySound, walletOut;
    private AudioClip[] cardMove = [];

    private bool dragging = false;
    private bool moving = false;
    private float grabOffset = 0f;
    private float dragTime = 0f;
    private bool decided = false;
    private int failures = 0;

    /// <summary>途中で閉じたときに覚えておく状態です。失敗の回数は、閉じて開き直しても戻りません。</summary>
    private class State
    {
        public int Failures;
    }

    //まだ失敗していなければ覚えておくことはないので、次は別の種類になってよい
    public override object? SaveState() => failures > 0 ? new State() { Failures = failures } : null;

    public override void RestoreState(object saved)
    {
        if (saved is State state) failures = Math.Clamp(state.Failures, 0, MaxFailures - 1);
    }
    private readonly List<SpriteRenderer> failureLamps = [];

    protected override void IntroGrow(float t, ConsentTitleButton agree, ConsentTitleButton disagree, TextMeshPro body)
    {
        //同意するボタンはカードに変えるので、そのまま残す
        if (body) body.alpha = 1f - t;
        if (disagree.GameObject) ConsentUI.SetAlpha(disagree.GameObject, 1f - t);
    }

    protected override void IntroFinish(ConsentTitleButton agree, ConsentTitleButton disagree, TextMeshPro body)
    {
        if (body) GameObject.Destroy(body.gameObject);
        if (disagree.GameObject) GameObject.Destroy(disagree.GameObject);
        introAgree = agree;
    }

    /// <summary>
    /// Skeldのタスクの中から、カードをスワイプするミニゲームを探します。
    /// </summary>
    static private CardSlideGame? FindPrefab()
    {
        var skeld = VanillaAsset.MapAsset[SkeldMapId];
        if (!skeld) return null;
        foreach (var tasks in new[] { skeld.CommonTasks, skeld.LongTasks, skeld.ShortTasks })
        {
            if (tasks == null) continue;
            foreach (var task in tasks)
            {
                var game = task?.MinigamePrefab?.TryCast<CardSlideGame>();
                if (game) return game;
            }
        }
        return null;
    }

    static private string Vanilla(StringNames name) => TranslationController.Instance.GetString(name);

    public override void Begin()
    {
        var area = ContentArea;
        var prefab = FindPrefab();
        if (prefab == null)
        {
            //見つからないときは、Standardと同じ画面で代わりにする
            if (introAgree != null && introAgree.GameObject) GameObject.Destroy(introAgree.GameObject);
            CreateStandardScreen(Succeed, Fail);
            return;
        }

        //バニラのミニゲームとして動かないよう、非表示の親の下で複製し、動きを持つ部品を外してから表示する
        var holder = ConsentUI.Object(Root, "SwipeCardHolder", new(0f, 0f, -0.3f));
        holder.SetActive(false);
        var game = GameObject.Instantiate(prefab, holder.transform);
        col = game.col ? game.col.transform : null;
        redLight = game.redLight;
        greenLight = game.greenLight;
        statusText = game.StatusText;
        acceptSound = game.AcceptSound;
        denySound = game.DenySound;
        walletOut = game.WalletOut;
        cardMove = game.CardMove?.ToArray() ?? [];

        var gameObj = game.gameObject;
        ConsentVanillaMinigame.Strip(gameObj, game);
        //読み取り機だけを見せる。裏の背景、財布、コントローラーの操作の表示は出さない
        foreach (var t in gameObj.GetComponentsInChildren<Transform>(true))
        {
            if (t == gameObj.transform) continue;
            var name = t.name;
            if (name == "Background" || name.Contains("Wallet", StringComparison.OrdinalIgnoreCase) || name.StartsWith("InputDisplayGlyph")) t.gameObject.SetActive(false);
        }
        gameObj.transform.localPosition = Vector3.zero;
        gameObj.transform.localScale = Vector3.one;
        holder.SetActive(true);

        CreateFailureLamps();

        //カードは読み取り機に差し込んだ位置から始める。バニラのカードの絵は使わない
        Bounds cardBounds = new(holder.transform.position, new(1.6f, 1f, 0f));
        if (col)
        {
            col!.localPosition = new(XMin, CardY, col.localPosition.z);
            col.localScale = Vector3.one;
            var cardRenderers = col.GetComponentsInChildren<SpriteRenderer>(true).Where(r => r.sprite).ToArray();
            if (cardRenderers.Length > 0)
            {
                cardBounds = cardRenderers[0].bounds;
                foreach (var r in cardRenderers) cardBounds.Encapsulate(r.bounds);
            }
            foreach (var r in cardRenderers) r.enabled = false;
        }

        //画面の大きさに合わせて縮め、真ん中に置く。読み取り機と、カードが動く範囲全体で大きさを測る
        var renderers = gameObj.GetComponentsInChildren<SpriteRenderer>(true)
            .Where(r => r.enabled && r.gameObject.activeInHierarchy && r.sprite && r.maskInteraction == SpriteMaskInteraction.None).ToArray();
        Bounds bounds = cardBounds;
        foreach (var r in renderers) bounds.Encapsulate(r.bounds);
        var cardAtEnd = cardBounds;
        cardAtEnd.center += holder.transform.TransformVector(new(XMax - XMin, 0f, 0f));
        bounds.Encapsulate(cardAtEnd);
        Vector2 localSize = Root.InverseTransformVector(bounds.size);
        float width = Math.Max(Mathf.Abs(localSize.x), 0.01f), height = Math.Max(Mathf.Abs(localSize.y), 0.01f);
        float scale = Math.Min(area.width / width, area.height / height);
        Vector2 localCardSize = Root.InverseTransformVector(cardBounds.size);
        holder.transform.localScale = new(scale, scale, scale * HolderDepthScale);
        Vector2 center = Root.InverseTransformPoint(bounds.center);
        var holderPos = holder.transform.localPosition;
        holder.transform.localPosition = new(holderPos.x + area.center.x - center.x, holderPos.y + area.center.y - center.y, holderPos.z);
        PopIn(holder.transform);
        Vector2 cardSize = new(Mathf.Abs(localCardSize.x) * scale, Mathf.Abs(localCardSize.y) * scale);

        //導入の同意するボタンをそのままカードにする。導入がなかったときは、同じボタンをその場に作る
        bool fromIntro = introAgree != null && introAgree.GameObject;
        button = fromIntro ? introAgree! : ConsentUI.TitleButton(Root, "AgreeCard", CardTargetPosition, StandardButtonWidth, ConsentUI.AgreeText, ConsentButtonStyle.Agree);
        introAgree = null;
        Clicks.Forget(button.Transform);
        SetUpMorph(cardSize);

        var clickable = Clicks.AddPress(button.Transform, button.LocalRect.size, () =>
        {
            if (!col) return;
            dragging = true;
            dragTime = 0f;
            grabOffset = col!.localPosition.x - MouseX;
        });
        clickable.Predicate = () => !morphing && !decided;

        if (statusText) statusText!.text = Vanilla(StringNames.SwipeCardPleaseSwipe);
        SetGreen(Green);

        morphing = true;
        morphTime = fromIntro ? 0f : MorphDuration;
        if (fromIntro && Constants.ShouldPlaySfx() && walletOut) SoundManager.Instance.PlaySound(walletOut, false);
        ApplyMorph();
    }

    /// <summary>
    /// ボタンの背景を伸び縮みさせてカードの形にするための、変形前後の状態を記録します。
    /// </summary>
    private void SetUpMorph(Vector2 cardSize)
    {
        var root = button.Transform;
        buttonScale = Mathf.Abs(root.localScale.x);
        //ボタンの中の奥行きを縮めて、ボタン全体がカードと同じ奥行きに収まるようにする
        root.localScale = new(root.localScale.x, root.localScale.y, root.localScale.z * ButtonDepthScale);
        morphFromPos = root.localPosition;

        var rect = button.LocalRect;
        rectCenter = rect.center;
        finalStretch = new(cardSize.x / Math.Max(buttonScale * rect.width, 1e-4f), cardSize.y / Math.Max(buttonScale * rect.height, 1e-4f));

        //文字を収めた部品と、隠したアイコン以外は背景の部品として伸び縮みさせる
        var text = button.Text;
        Transform? textTop = null;
        if (text)
        {
            for (var t = text!.transform; t && t != root; t = t.parent) textTop = t;
        }
        for (int i = 0; i < root.childCount; i++)
        {
            var child = root.GetChild(i);
            if (child == textTop || child.name == "Icon") continue;
            backgroundParts.Add(new(child, child.localPosition, child.localScale));
        }
        foreach (var collider in root.GetComponents<BoxCollider2D>()) rootColliders.Add((collider, collider.offset, collider.size));

        //文字は、変形後のカードの右下に寄せる
        if (text)
        {
            textTransform = text!.transform;
            textFrom = textTransform.localPosition;
            text.ForceMeshUpdate();
            var tb = text.textBounds;
            Vector2 visualCenter = root.InverseTransformPoint(textTransform.TransformPoint(tb.center));
            Vector2 extents = root.InverseTransformVector(textTransform.TransformVector(tb.extents));
            extents = new(Mathf.Abs(extents.x), Mathf.Abs(extents.y));
            Vector2 half = new(rect.width * finalStretch.x * 0.5f, rect.height * finalStretch.y * 0.5f);
            float margin = TextMargin / buttonScale;
            Vector2 target = new(rectCenter.x + half.x - margin - extents.x, rectCenter.y - half.y + margin + extents.y + TextRaise / buttonScale);
            Vector3 deltaWorld = root.TransformVector(target - visualCenter);
            textTo = textFrom + (textTransform.parent ? textTransform.parent.InverseTransformVector(deltaWorld) : deltaWorld);
        }
    }

    /// <summary>
    /// 変形の進み具合に合わせて、ボタンの背景の大きさ・文字の位置・ボタンの位置を決めます。
    /// </summary>
    private void ApplyMorph()
    {
        if (!button.GameObject) return;
        float t = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(morphTime / MorphDuration));
        var k = Vector2.Lerp(Vector2.one, finalStretch, t);

        //背景はボタンの絵の真ん中を中心に伸び縮みさせる
        foreach (var part in backgroundParts)
        {
            if (!part.Transform) continue;
            var p = part.Position;
            part.Transform.localPosition = new(rectCenter.x + (p.x - rectCenter.x) * k.x, rectCenter.y + (p.y - rectCenter.y) * k.y, p.z);
            part.Transform.localScale = new(part.Scale.x * k.x, part.Scale.y * k.y, part.Scale.z);
        }
        foreach (var (collider, offset, size) in rootColliders)
        {
            if (!collider) continue;
            collider.offset = new(rectCenter.x + (offset.x - rectCenter.x) * k.x, rectCenter.y + (offset.y - rectCenter.y) * k.y);
            collider.size = new(size.x * k.x, size.y * k.y);
        }
        if (textTransform) textTransform!.localPosition = Vector3.Lerp(textFrom, textTo, t);

        //カードの真ん中が、読み取り機のカードの位置に来るようにする。奥行きも読み取り機のカードにそろえる
        var target = CardTargetPosition - (Vector3)(rectCenter * buttonScale);
        button.Transform.localPosition = Vector3.Lerp(morphFromPos, target, t);
    }

    /// <summary>カードを動かす親の座標系での、マウスの横の位置です。</summary>
    private float MouseX => col ? col!.parent.InverseTransformPoint(Clicks.MouseWorld).x : 0f;

    /// <summary>読み取り機のカードの、窓の中身の座標系での位置です。奥行きも含みます。</summary>
    private Vector3 CardTargetPosition => col ? Root.InverseTransformPoint(col!.position) : new(0f, 0f, -0.3f);

    public override void Update()
    {
        if (morphing)
        {
            morphTime += Time.deltaTime;
            if (morphTime >= MorphDuration) morphing = false;
            ApplyMorph();
            return;
        }
        if (!col || decided) { ApplyMorph(); return; }

        var pos = col!.localPosition;
        if (dragging)
        {
            if (Clicks.MouseHeld)
            {
                float x = Mathf.Clamp(MouseX + grabOffset, XMin, XMax);
                if (x - pos.x > 0.01f)
                {
                    dragTime += Time.deltaTime;
                    SetGreen(Gray);
                    if (!moving)
                    {
                        moving = true;
                        if (Constants.ShouldPlaySfx() && cardMove.Length > 0) SoundManager.Instance.PlaySound(cardMove[RandomInt(cardMove.Length)], false);
                    }
                }
                pos.x = x;
            }
            else
            {
                dragging = false;
                moving = false;
                OnRelease(pos.x);
            }
        }
        else
        {
            //離している間は、左端へ戻っていく
            pos.x = Mathf.Lerp(pos.x, XMin, Time.deltaTime * 4f);
        }
        col.localPosition = pos;
        ApplyMorph();
    }

    /// <summary>
    /// カードを離したときに、バニラと同じく読み取れたかどうかを決めます。
    /// </summary>
    private void OnRelease(float x)
    {
        if (XMax - x < 0.05f)
        {
            if (dragTime >= AcceptMin && dragTime <= AcceptMax)
            {
                decided = true;
                if (Constants.ShouldPlaySfx() && acceptSound) SoundManager.Instance.PlaySound(acceptSound, false);
                if (statusText) statusText!.text = Vanilla(StringNames.SwipeCardAccepted);
                SetGreen(Green);
                FinishAfter(true);
                return;
            }
            Deny(dragTime > AcceptMax ? StringNames.SwipeCardTooSlow : StringNames.SwipeCardTooFast);
            return;
        }
        Deny(StringNames.SwipeCardBadRead);
    }

    private void Deny(StringNames message)
    {
        if (Constants.ShouldPlaySfx() && denySound) SoundManager.Instance.PlaySound(denySound, false);
        if (statusText) statusText!.text = Vanilla(message);
        SetGreen(Gray);

        //赤いランプを1つ増やして点ける。3つ目まで点いたら不同意
        if (failures < failureLamps.Count && failureLamps[failures]) failureLamps[failures].color = Color.red;
        failures++;
        if (failures >= MaxFailures)
        {
            decided = true;
            FinishAfter(false);
        }
    }

    /// <summary>
    /// 失敗の回数を数える赤いランプを用意します。バニラの赤いランプを1つ目とし、その左隣に複製したランプを2つ並べます。
    /// 点いていない間は灰色にし、失敗するたびに、バニラのランプから左へ順に赤く点けます。
    /// </summary>
    private void CreateFailureLamps()
    {
        if (!redLight) return;
        var parent = redLight!.transform.parent;
        var pos = redLight.transform.localPosition;
        //間隔は、バニラの赤いランプと緑のランプの間隔にそろえる
        float pitch = greenLight && greenLight!.transform.parent == parent ? Mathf.Abs(greenLight.transform.localPosition.x - pos.x) : 0.41f;
        redLight.color = Gray;
        failureLamps.Add(redLight);
        for (int i = 1; i < MaxFailures; i++)
        {
            var lamp = GameObject.Instantiate(redLight.gameObject, parent);
            lamp.name = "FailureLamp";
            lamp.transform.localPosition = new(pos.x - pitch * i, pos.y, pos.z);
            var renderer = lamp.GetComponent<SpriteRenderer>();
            renderer.color = Gray;
            failureLamps.Add(renderer);
        }
        //前回までに失敗した分は、最初から点けておく
        for (int i = 0; i < failures && i < failureLamps.Count; i++) failureLamps[i].color = Color.red;
    }

    private void SetGreen(Color green)
    {
        if (greenLight) greenLight!.color = green;
    }
}
