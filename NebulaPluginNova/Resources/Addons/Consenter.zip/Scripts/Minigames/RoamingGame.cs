using Nebula.Behavior;
using Nebula.Extensions;
using Nebula.Map;
using Nebula.Modules.ScriptComponents;
using Virial;
using Virial.Game;

namespace Consenter;

/// <summary>
/// 「同意ボタンが放たれた！」と知らせて窓を閉じ、マップ中を歩き回る同意する・同意しないのボタンを放つミニゲームです。
/// 歩き回るボタンは<see cref="RoamingConsent"/>が扱います。
/// </summary>
public class RoamingGame : ConsentGame
{
    public override Vector2 DialogSize => new(5.2f, 2.6f);
    //知らせの窓はしばらくすると勝手に閉じるので、放置の時間切れは無し
    public override float? IdleTimeout => null;

    public override void Begin()
    {
        var area = ContentArea;
        AddText(new(0f, area.center.y + 0.25f, -0.5f), new(DialogSize.x - 0.3f, 0.6f), 2.8f, Language.Translate("consenter.minigame.roaming"), new(1f, 0.9f, 0.4f));
        AddTitleButton(new(0f, area.yMin + 0.3f), 1.8f, "OK", ConsentButtonStyle.Neutral, Host.ReleaseRoamingButtons);
    }

    public override void Update()
    {
        //しばらくしたら勝手に放たれる
        if (Elapsed > 4f) Host.ReleaseRoamingButtons();
    }
}

/// <summary>
/// マップ中を歩き回る、1個の同意するボタンと8個の同意しないボタンです。
/// ボタンはマップの代表点(MapArea)のいずれかに、互いに離れて現れ、マップの経路をたどって歩き回ります。行き先は適度な間隔で変わります。
/// 影の中では見えず、画面の中央から一定の距離以内にあって影に遮られていないときだけ押せます。
/// 10秒に一度、同意するの方向を示す印付きの矢印がしばらく出ます。同意するを押すと同意できます。
/// 同意しないは、押すか、自分が触れると失敗します。
/// </summary>
public class RoamingConsent
{
    private const int NumOfDisagree = 8;
    private const float ClickableDistance = 3f;
    private const float WalkSpeed = 1.1f;
    private const float ButtonWidth = 1.8f;
    //経路を探すときに、壁を避けて通れるか調べる太さ
    private const float PathRadius = 0.05f;
    //行き先を変える間隔
    static private readonly (float min, float max) RetargetInterval = (3f, 6f);
    //矢印を出す間隔と、出しておく時間
    private const float ArrowInterval = 10f;
    private const float ArrowDuration = 3f;

    //クリックを受ける子オブジェクトを、見た目より手前に置く量
    private const float ClickAreaZ = -2f;

    private class Walker
    {
        public GameObject Root = null!;
        public Transform Body = null!;
        public Rect LocalRect;
        public Vector2 Position;
        public Vector2[]? Path;
        public int PathIndex;
        public float RetargetTimer;
        public float HopOffset;
        public bool IsAgree;
    }

    private readonly Consenter.Instance? owner;
    private readonly GameObject holder;
    private readonly List<Walker> walkers = [];
    private readonly Vector2[] mapArea;
    private readonly FunctionalLifespan lifespan;
    private float time = 0f;
    private float arrowTimer = 0f;
    private Arrow? arrow = null;
    private float arrowTime = 0f;
    public bool IsAlive => holder;

    private RoamingConsent(Consenter.Instance? owner)
    {
        this.owner = owner;
        var behaviour = UnityHelper.CreateObject<ScriptBehaviour>("RoamingConsent", null, Vector3.zero);
        holder = behaviour.gameObject;
        behaviour.UpdateHandler += Update;
        lifespan = new FunctionalLifespan(() => IsAlive);

        mapArea = MapData.GetCurrentMapData().MapArea.Select(p => (Vector2)p).ToArray();
        foreach (var (pos, i) in ChooseSpawnPositions(NumOfDisagree + 1).Select((p, i) => (p, i))) walkers.Add(CreateWalker(pos, i == 0));
    }

    /// <summary>
    /// 歩き回るボタンを放ちます。ownerがnullの場合は、デバッグ用に結果を画面の色で示すだけにします。
    /// </summary>
    static public RoamingConsent Start(Consenter.Instance? owner) => new(owner);

    private Vector2 RandomMapAreaPosition() => mapArea.Length > 0 ? mapArea[UnityEngine.Random.Range(0, mapArea.Length)] : Vector2.zero;

    //自分からこの距離以内には、どのボタンも出さない
    private const float MinSpawnDistanceFromPlayer = 5f;

    /// <summary>
    /// 自分から一定の距離以上離れた代表点の中から、互いになるべく離れたものを選びます。
    /// そうした代表点が無いマップでは、自分から遠い順に選びます。
    /// </summary>
    private List<Vector2> ChooseSpawnPositions(int count)
    {
        var player = PlayerControl.LocalPlayer ? (Vector2)PlayerControl.LocalPlayer.transform.position : Vector2.zero;
        var candidates = mapArea.Where(p => (p - player).magnitude >= MinSpawnDistanceFromPlayer).ToArray();
        if (candidates.Length == 0) candidates = mapArea.OrderByDescending(p => (p - player).magnitude).Take(Math.Max(1, mapArea.Length / 4)).ToArray();
        if (candidates.Length == 0) candidates = [player];

        List<Vector2> chosen = [];
        for (int i = 0; i < count; i++)
        {
            Vector2 best = candidates[UnityEngine.Random.Range(0, candidates.Length)];
            float bestScore = float.MinValue;
            //候補をいくつか引いて、ほかのボタンから一番遠いものを選ぶ
            for (int j = 0; j < 24; j++)
            {
                var candidate = candidates[UnityEngine.Random.Range(0, candidates.Length)];
                float score = chosen.Count == 0 ? (candidate - player).magnitude : chosen.Min(c => (c - candidate).magnitude);
                if (score > bestScore)
                {
                    best = candidate;
                    bestScore = score;
                }
            }
            chosen.Add(best);
        }
        return chosen;
    }

    private Walker CreateWalker(Vector2 pos, bool isAgree)
    {
        var root = UnityHelper.CreateObject("Walker", holder.transform, new(pos.x, pos.y, pos.y / 1000f));
        var button = ConsentUI.TitleButton(root.transform, isAgree ? "Agree" : "Disagree", Vector3.zero, ButtonWidth, isAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText, isAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree);

        //見た目は影で隠れるよう通常のレイヤーに置く。複製元のボタンと当たり判定は使わないので外す
        GameObject.Destroy(button.Button);
        foreach (var collider in button.GameObject.GetComponentsInChildren<Collider2D>(true)) GameObject.Destroy(collider);
        foreach (var t in button.GameObject.GetComponentsInChildren<Transform>(true)) t.gameObject.layer = LayerExpansion.GetDefaultLayer();
        //ボタンどうしが重なったときに、部品が入り混じって描かれないようにまとめる
        ConsentUI.ApplySortingGroup(button.GameObject);

        var walker = new Walker()
        {
            Root = root,
            Body = button.Transform,
            LocalRect = button.LocalRect,
            Position = pos,
            RetargetTimer = 0f,
            HopOffset = UnityEngine.Random.Range(0f, 10f),
            IsAgree = isAgree,
        };

        //クリックは、少し手前に置いた子オブジェクトのPassiveButtonで受ける。
        //NoSの広いカメラが有効な間、マップ上のクリックは画面全体の当たり判定がまとめて受け取り、ShortObjectsかObjectsのレイヤーにあるボタンにだけ渡すので、子オブジェクトだけShortObjectsのレイヤーに置く
        var clickArea = UnityHelper.CreateObject<BoxCollider2D>("ClickArea", button.Transform, new(button.LocalRect.center.x, button.LocalRect.center.y, ClickAreaZ), LayerExpansion.GetShortObjectsLayer());
        clickArea.size = button.LocalRect.size;
        clickArea.isTrigger = true;
        var passive = clickArea.gameObject.SetUpButton();
        passive.OnClick.AddListener((UnityEngine.Events.UnityAction)(() => TryClick(walker)));
        return walker;
    }

    public void Dispose()
    {
        if (arrow != null)
        {
            arrow.IsDisappearing = true;
            arrow = null;
        }
        if (holder) GameObject.Destroy(holder);
    }

    private void Resolve(bool agreed)
    {
        Dispose();
        if (owner != null) owner.OnRoamingResolved(agreed);
        else ConsentNotice.ShowResult(agreed);
    }

    private void Update()
    {
        //デバッグ用に放ったものは、会議が始まったら片付ける。同意者のものは同意者が片付ける
        if (owner == null && (MeetingHud.Instance || ExileController.Instance))
        {
            Dispose();
            return;
        }

        time += Time.deltaTime;
        foreach (var walker in walkers) UpdateWalker(walker);
        UpdateArrow();

        //同意しないに触れたら失敗
        if (CanTouch())
        {
            Vector2 player = PlayerControl.LocalPlayer.transform.position;
            foreach (var walker in walkers)
            {
                if (walker.IsAgree) continue;
                if (((Vector2)walker.Body.position - player).magnitude < TouchDistance)
                {
                    Resolve(false);
                    return;
                }
            }
        }

    }

    private void UpdateWalker(Walker walker)
    {
        //行き先に着いたか、しばらく経ったら行き先を変える
        walker.RetargetTimer -= Time.deltaTime;
        if (walker.Path == null || walker.PathIndex >= walker.Path.Length || walker.RetargetTimer < 0f)
        {
            var path = NavVerticesHelpers.CalcPath(walker.Position, RandomMapAreaPosition(), PathRadius);
            if (path != null && path.Path.Length > 0)
            {
                walker.Path = path.Path;
                walker.PathIndex = 0;
            }
            walker.RetargetTimer = UnityEngine.Random.Range(RetargetInterval.min, RetargetInterval.max);
        }

        //経路に沿って歩く
        float move = WalkSpeed * Time.deltaTime;
        while (walker.Path != null && move > 0f && walker.PathIndex < walker.Path.Length)
        {
            var target = walker.Path[walker.PathIndex];
            var diff = target - walker.Position;
            float distance = diff.magnitude;
            if (distance <= move)
            {
                walker.Position = target;
                move -= distance;
                walker.PathIndex++;
            }
            else
            {
                walker.Position += diff / distance * move;
                move = 0f;
            }
        }

        walker.Root.transform.position = new(walker.Position.x, walker.Position.y, walker.Position.y / 1000f);
        //ぴょこぴょこ跳ねる
        float hop = Mathf.Abs(Mathf.Sin((time + walker.HopOffset) * 6f)) * 0.06f;
        walker.Body.localPosition = new(0f, hop + 0.3f, 0f);
    }

    private void UpdateArrow()
    {
        var agree = walkers.FirstOrDefault(w => w.IsAgree);
        if (agree == null) return;

        arrowTimer += Time.deltaTime;
        if (arrow == null && arrowTimer >= ArrowInterval)
        {
            arrowTimer = 0f;
            arrowTime = 0f;
            //印は向きを変えず、その周りを小さな矢印が回って方向を示す
            arrow = new Arrow(ConsentAssets.RoamingArrowIcon.GetSprite(), false, true)
            {
                TargetPos = agree.Position,
                IsAffectedByComms = false,
                DisappearanceEffect = Arrow.DisappearanceType.Reduction,
            }.SetSmallColor(new Virial.Color(0.45f, 1f, 0.5f)).Register(lifespan);
        }

        if (arrow != null)
        {
            arrow.TargetPos = agree.Position;
            arrowTime += Time.deltaTime;
            if (arrowTime > ArrowDuration)
            {
                arrow.IsDisappearing = true;
                arrow = null;
            }
        }
    }

    //同意しないのボタンの中心と自分がこの距離まで近づくと、触れたことにする
    private const float TouchDistance = 0.55f;

    private bool CanTouch()
    {
        if (Minigame.Instance || MeetingHud.Instance || ExileController.Instance) return false;
        if (!PlayerControl.LocalPlayer || PlayerControl.LocalPlayer.inVent) return false;
        return true;
    }

    private bool CanClick()
    {
        if (Minigame.Instance || MeetingHud.Instance || ExileController.Instance) return false;
        if (!PlayerControl.LocalPlayer) return false;
        if (MapBehaviour.Instance && MapBehaviour.Instance.IsOpen) return false;
        return true;
    }

    private void TryClick(Walker walker)
    {
        if (!CanClick() || !walkers.Contains(walker)) return;
        var camera = Camera.main;
        if (!camera) return;
        Vector2 center = camera.transform.position;
        Vector2 player = PlayerControl.LocalPlayer.GetTruePosition();

        //画面の中央から遠いものや、影に隠れているものは押せない。死んだ後は影が無いので、壁の向こうのものも押せる
        if ((walker.Position - center).magnitude > ClickableDistance) return;
        var toWalker = walker.Position - player;
        if (!PlayerControl.LocalPlayer.Data.IsDead && toWalker.magnitude > 0.01f && PhysicsHelpers.AnyNonTriggersBetween(player, toWalker.normalized, toWalker.magnitude, Constants.ShadowMask)) return;

        Resolve(walker.IsAgree);
    }
}
