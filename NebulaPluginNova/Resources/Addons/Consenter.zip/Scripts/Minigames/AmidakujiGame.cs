namespace Consenter;

/// <summary>
/// あみだくじで同意するを引き当てるミニゲームです。あみだくじは縦に長く、NoSのスクロールビューでスクロールしないと全体が見えません。
/// 上の▼を押すとそこから線をたどって下へ進み、見る場所はたどる先に合わせて自動で動きます。
/// たどり着いた先が同意するなら同意でき、同意しないなら失敗します。
/// </summary>
public class AmidakujiGame : ConsentGame
{
    public override Vector2 DialogSize => new(5.8f, 4.6f);
    public override float? IdleTimeout => 15f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int Lines = 4;
    private const int Levels = 16;
    private const float LinePitch = 1.2f;
    private const float LevelPitch = 0.42f;
    private const float MarkerSpeed = 3f;

    //rungs[段, 列] = 列と列+1の間に横線がある
    private readonly bool[,] rungs = new bool[Levels, Lines - 1];
    private int agreeLine;
    private ConsentScrollView view = null!;
    //あみだくじの上端と下端(スクロールビューの中身の座標)
    private float top, bottom;
    private List<Vector2>? path = null;
    private int pathIndex = 0;
    private SpriteRenderer marker = null!;
    private Vector2 markerPos;

    private float LineX(int line) => (line - (Lines - 1) * 0.5f) * LinePitch;
    private float LevelY(int level) => top - LevelPitch * (level + 1);

    public override void Begin()
    {
        var area = ContentArea;
        float contentHeight = LevelPitch * (Levels + 1) + 1.1f;
        view = ConsentScrollView.Create(Root, new(area.center.x, area.center.y, -0.1f), area.size, contentHeight);
        ConsentUI.Box(Root, "ViewportBack", new(view.Viewport.center.x, view.Viewport.center.y, -0.05f), view.Viewport.size, new(0f, 0f, 0f, 0.25f));
        var content = view.Content;

        top = view.Top - 0.55f;
        bottom = top - LevelPitch * (Levels + 1);

        //横線を引く。同じ段で隣り合う横線は作らない。どの列の間にも1本以上は引く
        do
        {
            for (int level = 0; level < Levels; level++)
            {
                for (int gap = 0; gap < Lines - 1; gap++)
                    rungs[level, gap] = (gap == 0 || !rungs[level, gap - 1]) && Random01 < 0.4f;
            }
        } while (Enumerable.Range(0, Lines - 1).Any(gap => !Enumerable.Range(0, Levels).Any(level => rungs[level, gap])));

        var lineColor = new Color(0.9f, 0.9f, 0.9f);
        for (int line = 0; line < Lines; line++)
            ConsentUI.Line(content, "Line", new(LineX(line), top), new(LineX(line), bottom), -0.01f, 0.05f, lineColor);
        for (int level = 0; level < Levels; level++)
            for (int gap = 0; gap < Lines - 1; gap++)
                if (rungs[level, gap]) ConsentUI.Line(content, "Rung", new(LineX(gap), LevelY(level)), new(LineX(gap + 1), LevelY(level)), -0.01f, 0.05f, lineColor);

        agreeLine = RandomInt(Lines);
        for (int line = 0; line < Lines; line++)
        {
            bool isAgree = line == agreeLine;
            var style = isAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree;
            ConsentUI.SimpleButton(content, "Goal", new(LineX(line), bottom - 0.25f, -0.02f), new(1.1f, 0.36f), isAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText, style, 0.9f);

            int l = line;
            var (_, clickable) = AddSimpleButton(content, new(LineX(line), top + 0.25f, -0.02f), new(0.5f, 0.36f), "▼", ConsentButtonStyle.Neutral, () => StartTracing(l), 1.2f);
            clickable.Predicate = () => path == null && view.Contains(Clicks.MouseLocal(Root));
        }

        marker = ConsentUI.Circle(content, "Marker", new(0f, 0f, -0.04f), 0.1f, new(1f, 0.85f, 0.2f));
        marker.gameObject.SetActive(false);
        view.ApplyMask();
    }

    private void StartTracing(int line)
    {
        if (path != null) return;

        //たどる道のりの頂点を求める
        path = [new(LineX(line), top)];
        int current = line;
        for (int level = 0; level < Levels; level++)
        {
            int next = current;
            if (current < Lines - 1 && rungs[level, current]) next = current + 1;
            else if (current > 0 && rungs[level, current - 1]) next = current - 1;
            if (next != current)
            {
                path.Add(new(LineX(current), LevelY(level)));
                path.Add(new(LineX(next), LevelY(level)));
                current = next;
            }
        }
        path.Add(new(LineX(current), bottom));
        markerPos = path[0];
        pathIndex = 1;
        marker.gameObject.SetActive(true);
        //たどる間は、見る場所を自動で動かす
        view.AllowUserScroll = false;
    }

    public override void Update()
    {
        if (path == null) return;

        float move = MarkerSpeed * Time.deltaTime;
        while (move > 0f && pathIndex < path.Count)
        {
            var next = path[pathIndex];
            float dist = (next - markerPos).magnitude;
            var from = markerPos;
            if (dist <= move)
            {
                markerPos = next;
                pathIndex++;
                move -= dist;
            }
            else
            {
                markerPos += (next - markerPos).normalized * move;
                move = 0f;
            }
            //たどった跡を残す
            var trail = ConsentUI.Line(view.Content, "Trail", from, markerPos, -0.03f, 0.07f, new(1f, 0.85f, 0.2f));
            trail.maskInteraction = SpriteMaskInteraction.VisibleInsideMask;
        }
        marker.transform.localPosition = new(markerPos.x, markerPos.y, -0.04f);

        //たどる先が見える範囲の中央に来るように動かす
        view.Scroll = Mathf.Lerp(view.Scroll, view.ScrollToCenter(markerPos.y), Mathf.Clamp01(Time.deltaTime * 6f));

        //たどり着いたら、結果を確かめられる時間を取ってから閉じる
        if (pathIndex >= path.Count && !IsFinishing)
        {
            int goal = Enumerable.Range(0, Lines).OrderBy(l => Mathf.Abs(LineX(l) - markerPos.x)).First();
            FinishAfter(goal == agreeLine);
        }
    }
}
