using System.Collections;
using BepInEx.Unity.IL2CPP.Utils.Collections;

namespace Consenter;

/// <summary>
/// Windowsでエラーが連発したときのように、斜めにずらっと重なったポップアップを閉じていき、同意するを探すミニゲームです。
/// 最初はStandardと全く同じ見た目で、同意するを押すと、ポップアップが0.5秒ほどかけて次々に出てきます。ポップアップは斜めの列をいくつか作って並びます。
/// 各ポップアップの下には、水色の「閉じる」と、同意する・同意しないのどちらかのボタンが左右に並びます(左右はポップアップごとにランダム)。
/// 同意するが無いポップアップの中には、水色の「閉じる」だけのものや、緑色なのに「同意しない」のボタンを持つものも混ざります。
/// ほとんどのポップアップのボタンは同意しないで、押すと失敗します。同意するは途中の1枚にだけあります。すべてのポップアップを閉じると失敗します。
/// 一定の確率で、同意するのボタンが赤、同意しないのボタンが緑と、色が逆になります。
/// どのポップアップが残っているか、同意するが何枚目か、色が逆かは覚えておくので、途中で閉じて開き直しても同じ状態から再開します。
/// </summary>
public class PopupsGame : ConsentGame
{
    public override Vector2 DialogSize => StandardDialogSize;
    public override float? IdleTimeout => 15f;
    public override float DialogScale => 1f;

    private const int NumOfPopups = 18;
    private const int NumOfMessages = 4;
    private static readonly Vector2 PopupSize = new(3.2f, 1.9f);
    //枠が太いので、中身は内側に寄せる
    private const float FrameMargin = 0.4f;
    //1枚ごとのずれ
    private static readonly Vector2 CascadeStep = new(0.22f, -0.18f);
    //斜めの列の数と、列ごとのずれ
    private const int NumOfColumns = 3;
    private static readonly Vector2 ColumnStep = new(3f, -0.25f);
    private static int PopupsPerColumn => (NumOfPopups + NumOfColumns - 1) / NumOfColumns;
    //ポップアップの縮尺
    private const float PopupScale = 0.8f;
    //すべてのポップアップを出し終えるまでの時間
    private const float CascadeDuration = 0.5f;
    //同意する・同意しないの色が逆になる確率
    private const float InvertColorChance = 0.4f;

    /// <summary>
    /// 途中で閉じたときに覚えておく状態です。
    /// </summary>
    private class State
    {
        public int AgreeIndex;
        public bool[] Closed = new bool[NumOfPopups];
        public int[] Messages = new int[NumOfPopups];
        public bool InvertColor;
        //水色の閉じるボタンが左にあるか
        public bool[] CloseOnLeft = new bool[NumOfPopups];
        //ポップアップの種類(同意するのポップアップでは使わない)
        public PopupKind[] Kinds = new PopupKind[NumOfPopups];
    }

    /// <summary>
    /// 同意するが無いポップアップの種類です。
    /// </summary>
    private enum PopupKind
    {
        /// <summary>水色の閉じると、赤い同意しない</summary>
        Normal,
        /// <summary>水色の閉じるだけ</summary>
        CloseOnly,
        /// <summary>水色の閉じると、緑色なのに同意しない</summary>
        GreenDisagree,
    }
    private const float CloseOnlyChance = 0.3f;
    private const float GreenDisagreeChance = 0.25f;

    private State? state = null;
    private bool restored = false;
    private ConsentTitleButton agreeButton = null!;
    private ConsentTitleButton disagreeButton = null!;
    private bool started = false;

    public override object? SaveState() => started ? state : null;

    public override void RestoreState(object saved)
    {
        if (saved is not State s) return;
        state = s;
        restored = true;
    }

    public override void Begin()
    {
        (_, agreeButton, disagreeButton) = CreateStandardScreen(StartPopups);
        //再開したときは、閉じていないポップアップをすぐに出す
        if (restored) StartPopups();
    }

    private void StartPopups()
    {
        if (started) return;
        started = true;
        //元の同意画面のボタンはもう押せない
        Clicks.Disable(agreeButton.Transform);
        Clicks.Disable(disagreeButton.Transform);

        if (state == null)
        {
            //同意するは、手前から何枚か閉じた先に埋もれさせる
            state = new State() { AgreeIndex = RandomInt(2, NumOfPopups - 4), InvertColor = Random01 < InvertColorChance };
            for (int i = 0; i < NumOfPopups; i++)
            {
                state.Messages[i] = RandomInt(NumOfMessages);
                state.CloseOnLeft[i] = Random01 < 0.5f;
                float kind = Random01;
                state.Kinds[i] = kind < CloseOnlyChance ? PopupKind.CloseOnly : kind < CloseOnlyChance + GreenDisagreeChance ? PopupKind.GreenDisagree : PopupKind.Normal;
            }
        }
        Host.StartCoroutine(CoShowPopups().WrapToIl2Cpp());
    }

    /// <summary>
    /// 閉じていないポップアップを1枚ずつ、斜めにずらしながら出していきます。
    /// </summary>
    private IEnumerator CoShowPopups()
    {
        var holder = ConsentUI.Object(Root, "Popups", new(0f, 0f, -1f)).transform;
        holder.localScale = new(PopupScale, PopupScale, 1f);


        var remaining = Enumerable.Range(0, NumOfPopups).Where(i => !state!.Closed[i]).ToArray();
        float interval = CascadeDuration / NumOfPopups;
        float timer = 0f;
        int shown = 0;
        while (shown < remaining.Length)
        {
            if (!IsPlaying) yield break;
            timer += Time.deltaTime;
            //1フレームに複数枚出すこともある
            while (shown < remaining.Length && timer >= interval * shown)
            {
                int index = remaining[shown];
                CreatePopup(holder, PopupPosition(index), index);
                shown++;
            }
            yield return null;
        }
    }

    /// <summary>
    /// ポップアップの位置です。いくつかの斜めの列に分けて並べ、全体が窓の真ん中に来るようにします。
    /// </summary>
    private static Vector2 PopupPosition(int index)
    {
        int column = index / PopupsPerColumn, row = index % PopupsPerColumn;
        var spread = CascadeStep * (PopupsPerColumn - 1) + ColumnStep * (NumOfColumns - 1);
        var start = -spread * 0.5f;
        return start + ColumnStep * column + CascadeStep * row;
    }

    private void CreatePopup(Transform holder, Vector2 pos, int index)
    {
        bool isAgree = index == state!.AgreeIndex;
        var outer = PopupSize + new Vector2(FrameMargin, FrameMargin);
        var popup = ConsentUI.Panel(holder, "Popup", new(pos.x, pos.y, -index * 0.3f), outer, 0.75f);
        var popupTransform = popup.transform;

        //ポップアップの裏にあるものは押せないようにする
        Clicks.Add(popupTransform, outer, () => { });

        var inner = PopupSize - new Vector2(FrameMargin, FrameMargin);
        ConsentUI.Text(popupTransform, new(0f, 0.15f, -0.05f), new(inner.x, 0.6f), 1.2f, new(0.92f, 0.92f, 0.92f), TextAlignmentOptions.Center,
            Language.Translate("consenter.minigame.popups.message." + state.Messages[index]));

        //下に、水色の閉じるボタンと、同意する・同意しないのボタンを左右に並べる
        var buttonSize = new Vector2(1.25f, 0.36f);
        float buttonY = -inner.y * 0.5f + buttonSize.y * 0.5f;
        var kind = isAgree ? PopupKind.Normal : state.Kinds[index];
        //閉じるだけのポップアップでは、閉じるを真ん中に置く
        float closeX = kind == PopupKind.CloseOnly ? 0f : state.CloseOnLeft[index] ? -0.7f : 0.7f;
        var close = ConsentUI.SimpleButton(popupTransform, "Close", new(closeX, buttonY, -0.05f), buttonSize, Language.Translate("consenter.advertisement.close"), ConsentButtonStyle.Neutral, 1.1f);
        var closeClickable = Clicks.Add(close.Transform, close.LocalRect, () => ClosePopup(popup, index));
        closeClickable.OnHover = on => { if (close.Background) close.Background.color = on ? Color.Lerp(ConsentAssets.NeutralColor, Color.white, 0.35f) : ConsentAssets.NeutralColor; };

        if (kind == PopupKind.CloseOnly) return;

        //色が逆のときは、同意するが赤、同意しないが緑になる。緑色の同意しないのポップアップは、さらに色が逆になる。押したときの結果は文字のとおり
        bool greenLooking = isAgree != state.InvertColor;
        if (kind == PopupKind.GreenDisagree) greenLooking = !greenLooking;
        var style = greenLooking ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree;
        var button = ConsentUI.SimpleButton(popupTransform, "Button", new(-closeX, buttonY, -0.05f), buttonSize, isAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText, style, 1.1f);
        var clickable = Clicks.Add(button.Transform, button.LocalRect, isAgree ? Succeed : Fail);
        clickable.OnHover = on => { if (button.Background) button.Background.color = on ? Color.Lerp(ConsentUI.ColorOf(style), Color.white, 0.35f) : ConsentUI.ColorOf(style); };
    }

    /// <summary>
    /// ポップアップを閉じます。すべて閉じてしまったら、同意できなかったことになります。
    /// </summary>
    private void ClosePopup(GameObject popup, int index)
    {
        if (!IsPlaying) return;
        GameObject.Destroy(popup);
        state!.Closed[index] = true;
        if (state.Closed.All(c => c)) Fail();
    }
}
