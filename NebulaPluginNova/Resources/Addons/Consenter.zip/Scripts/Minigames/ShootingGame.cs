namespace Consenter;

/// <summary>
/// 同意するを押した後に始まるシューティングのミニゲームです。どちらの種類も、最初はStandardと全く同じ見た目です。
/// 同意するを押すと、そのボタンの色相が徐々に変わって「同意への迷い」になります。同時に窓がなめらかに大きな正方形に広がり、迷いも行き先へ動いていきます。
/// 自機の「同意」はカーソルに付いて動き、弾に当たると失敗します。
/// ShootingHesitationでは、迷いは画面の上へ移り、そのまま戦闘が始まります。自機は自動で弾を撃ち、迷いを倒すと同意できます。
/// ShootingEnduranceでは、迷いは場の中央へ移った後、小さくなって消えながら紫の小さな四角を4つ生み、四角は速やかに四隅へ散らばります。
/// その後、四隅の四角から飛んでくる弾を、同意の処理のゲージが溜まるまで避け続けると同意できます。
/// 弾は1つのメッシュにまとめて描き、場のマスクの内側だけに見せます。場から完全に出た弾は消します。
/// 耐久の弾には、四隅から回転しながら出る螺旋の弾(狭い2方向を7方向へ。その間は対角の隅から、左右に流れる列以外のいろいろな弾も出る)、円形に広がって一度止まってから再び加速する弾、
/// 四隅から上下へ出て減速しながら列に並び、それから左右へ動き出す弾などがあります。
/// </summary>
public class ShootingGame : ConsentGame
{
    private readonly bool endurance;
    public ShootingGame(bool endurance) { this.endurance = endurance; }

    public override Vector2 DialogSize => StandardDialogSize;
    //戦闘が始まったら、放置の時間切れは無し
    public override float? IdleTimeout => phase == Phase.Standard ? 10f : null;
    public override float DialogScale => 1f;

    //戦闘中の窓は正方形
    static private readonly Vector2 BattleDialogSize = new(5.4f, 5.4f);
    private const float BattleDialogScale = 0.8f;

    private const float EnduranceTime = 18f;
    private const int BossHp = 68;
    private const float PlayerRadius = 0.16f;
    private const float PlayerHitRadius = 0.08f;
    private const float BulletRadius = 0.07f;

    //迷いへの変化。色が変わる間に、窓が広がり、迷いも行き先へ動く
    private const float MorphDuration = 1.2f;
    //耐久で、迷いが消えて四角が四隅へ散らばるまでの時間
    private const float ScatterDuration = 0.5f;
    private const float CornerSquareSize = 0.3f;
    static private readonly Color CornerSquareColor = new(0.62f, 0.38f, 0.88f);
    private const float HesitationHue = 280f;
    static private readonly Color HesitationTextColor = new(0.28f, 0.1f, 0.42f);
    private const float BossWidth = 1.9f;

    //螺旋の弾。四隅のどこかから、狭い3方向の弾を7方向へ、射出角度を回転させながら出し続ける
    private const float SpiralDuration = 4.5f;
    private const float SpiralInterval = 0.12f;
    //射出角度の回転の速さ(度/秒)。小さめにして、螺旋に沿って避けるようにする
    private const float SpiralRotateSpeed = 30f;
    private const int SpiralArms = 7;
    //1方向あたりの2方向の開き(度)
    private const float SpiralSpread = 5f;
    //撃つ時間と休む時間。休む間に隙間ができるので、隅から来ても避ける道が断たれない
    private const float SpiralBurstTime = 1.1f;
    private const float SpiralRestTime = 0.4f;

    //円形に広がって一度止まり、また加速する弾
    private const int RingBullets = 24;
    private const float RingStartSpeed = 2.2f;
    private const float RingStopTime = 0.6f;
    private const float RingWaitTime = 0.4f;
    private const float RingAccelTime = 0.8f;
    private const float RingEndSpeed = 2.2f;

    private class Bullet
    {
        public Vector2 Position;
        public Vector2 Velocity;
        public Color Color;
        public float Radius;
        //速さが時間で変わる弾は、向きと、経過時間から速さを返す関数を持つ
        public Vector2 Direction;
        public Func<float, float>? Speed;
        //決まった道筋で動く弾は、経過時間から位置を返す関数を持つ
        public Func<float, Vector2>? Path;
        public float Age;
    }

    private enum Phase { Standard, Morph, Scatter, Battle }
    private Phase phase = Phase.Standard;
    private float phaseTime = 0f;

    private Rect field;
    private float battleTime = 0f;
    private TextMeshPro body = null!;
    private ConsentTitleButton agreeButton = null!;
    private ConsentTitleButton disagreeButton = null!;
    private SpriteRenderer player = null!;
    private Vector2 playerPos;

    //迷い(元の同意するボタン)
    private ConsentTitleButton? boss;
    private Vector3 bossBaseScale;
    private Vector2 bossPos;
    //窓の縮尺を1としたときの、迷いの最初と行き先の位置と大きさ
    private Vector3 morphFromPos, morphToPos, morphFromScale, morphToScale;
    //耐久の四隅の四角
    private readonly SpriteRenderer[] cornerSquares = new SpriteRenderer[4];
    private readonly Vector2[] corners = new Vector2[4];
    private Vector2 bossHalfSize;
    private int bossHp = BossHp;
    private bool labelChanged = false;

    private SpriteRenderer gauge = null!;
    private readonly List<Bullet> enemyBullets = [];
    private readonly List<Bullet> playerBullets = [];
    private ConsentBulletRenderer enemyRenderer = null!;
    private ConsentBulletRenderer playerRenderer = null!;
    private float fireTimer = 0f;
    private float patternTimer = 1f;
    private float patternAngle = 0f;
    private float spiralTime = 0f;
    private float spiralTimer = 0f;
    private float spiralAngle = 0f;
    private Vector2 spiralOrigin;
    private int spiralCorner;
    //螺旋の間、対角の隅から撃つ弾
    private float diagonalTimer = 0f;
    private const float DiagonalInterval = 0.9f;
    //円形に広がって一度止まる弾の色
    static private readonly Color RingColor = new(1f, 0.85f, 0.5f);
    //耐久の弾の色。色ごとにまとめて描くので、色の数は少なくしておく
    static private readonly Color[] EndurancePalette = [new(0.6f, 0.85f, 1f), new(0.55f, 1f, 0.9f), new(0.75f, 0.75f, 1f)];

    public override void Begin()
    {
        (body, agreeButton, disagreeButton) = CreateStandardScreen(OnAgree);
    }

    private void OnAgree()
    {
        if (phase != Phase.Standard) return;
        Clicks.Disable(agreeButton.Transform);
        Clicks.Disable(disagreeButton.Transform);

        //同意するのボタンが迷いに変わっていく
        boss = agreeButton;
        bossBaseScale = boss.Transform.localScale;

        //行き先は、広げた後の窓での位置。迷いを倒すときは場の上、耐久では場の中央
        var battleField = BattleField;
        //ボタンは縮尺1の窓で作ったので、Sizeはそのまま窓の中での大きさになる
        float ratio = BossWidth / boss.Size.x;
        bossHalfSize = boss.Size * ratio * 0.5f;
        bossPos = endurance ? battleField.center : new(battleField.center.x, battleField.yMax - bossHalfSize.y - 0.1f);

        //窓の縮尺が変わっていくので、縮尺1の窓での位置と大きさで補間し、毎フレームいまの縮尺に直す
        morphFromPos = boss.Transform.localPosition * DialogScale;
        morphToPos = new Vector3(bossPos.x, bossPos.y, -0.3f) * BattleDialogScale;
        morphFromScale = bossBaseScale * DialogScale;
        morphToScale = bossBaseScale * ratio * BattleDialogScale;

        phase = Phase.Morph;
        phaseTime = 0f;
    }

    /// <summary>
    /// 広げた後の窓での、戦闘の場です。
    /// </summary>
    private Rect BattleField
    {
        get
        {
            float top = BattleDialogSize.y * 0.5f - 0.88f;
            float bottom = -BattleDialogSize.y * 0.5f + 0.12f;
            return Rect.MinMaxRect(-BattleDialogSize.x * 0.5f + 0.15f, bottom + 0.3f, BattleDialogSize.x * 0.5f - 0.15f, top);
        }
    }

    /// <summary>
    /// 枠とゲージと自機を作ります。窓は広げ終えている必要があります。
    /// </summary>
    private void SetUpBattle()
    {
        var area = ContentArea;
        field = Rect.MinMaxRect(area.xMin, area.yMin + 0.3f, area.xMax, area.yMax);
        ConsentUI.Box(Root, "Field", new(field.center.x, field.center.y, -0.05f), field.size, new(0f, 0f, 0f, 0.35f));
        //弾は場のマスクの内側だけに見せる
        ConsentUI.Mask(Root, new(field.center.x, field.center.y, 0f), field.size);
        enemyRenderer = new ConsentBulletRenderer(Root, new(0f, 0f, -0.35f), true);
        playerRenderer = new ConsentBulletRenderer(Root, new(0f, 0f, -0.34f), true);
        //耐久では処理のゲージ、迷いを倒すときは迷いの体力を下に出す
        ConsentUI.Box(Root, "GaugeBack", new(0f, area.yMin + 0.12f, -0.1f), new(area.width, 0.14f), new(0.2f, 0.2f, 0.2f));
        gauge = ConsentUI.Box(Root, "Gauge", new(0f, area.yMin + 0.12f, -0.12f), new(area.width, 0.14f), endurance ? ConsentAssets.AgreeColor : new(0.75f, 0.6f, 0.95f));
        SetGauge(endurance ? 0f : 1f);

        playerPos = new(field.center.x, field.yMin + 0.5f);
        string label = Language.Translate("consenter.minigame.ball.agree");
        player = ConsentUI.Circle(Root, "Player", new(playerPos.x, playerPos.y, -0.4f), PlayerRadius, ConsentAssets.AgreeColor);
        ConsentUI.Text(player.transform, new(0f, 0f, -0.01f), new(1.2f, 0.6f), label.Length > 2 ? 2f : 2.6f, ConsentAssets.AgreeTextColor, TextAlignmentOptions.Center, label);
    }

    private void SetGauge(float rate)
    {
        var area = ContentArea;
        rate = Mathf.Clamp01(rate);
        gauge.transform.localScale = new(Math.Max(0.001f, area.width * rate) / 0.16f, 0.14f / 0.16f, 1f);
        gauge.transform.localPosition = new(area.xMin + area.width * rate * 0.5f, area.yMin + 0.12f, -0.12f);
    }

    private void Fire(List<Bullet> list, Vector2 pos, Vector2 velocity, Color color, float radius)
    {
        list.Add(new Bullet() { Position = pos, Velocity = velocity, Color = color, Radius = radius });
    }

    public override void Update()
    {
        phaseTime += Time.deltaTime;
        switch (phase)
        {
            case Phase.Morph: UpdateMorph(); return;
            case Phase.Scatter: UpdateScatter(); return;
            case Phase.Battle: break;
            default: return;
        }

        battleTime += Time.deltaTime;

        //自機はカーソルに付いていく
        var mouse = Clicks.MouseLocal(Root);
        var goal = new Vector2(Mathf.Clamp(mouse.x, field.xMin + PlayerRadius, field.xMax - PlayerRadius), Mathf.Clamp(mouse.y, field.yMin + PlayerRadius, field.yMax - PlayerRadius));
        playerPos = Vector2.MoveTowards(playerPos, goal, 6f * Time.deltaTime);
        player.transform.localPosition = new(playerPos.x, playerPos.y, -0.4f);

        if (endurance) UpdateEndurance();
        else UpdateHesitation();
        if (!IsPlaying) return;

        if (MoveBullets(enemyBullets, enemyRenderer, b => (b.Position - playerPos).magnitude < PlayerHitRadius + b.Radius))
        {
            Fail();
            return;
        }

        if (endurance)
        {
            SetGauge(battleTime / EnduranceTime);
            if (battleTime >= EnduranceTime) Succeed();
        }
        else
        {
            SetGauge((float)bossHp / BossHp);
            if (bossHp <= 0) Succeed();
        }
    }

    /// <summary>
    /// 同意するのボタンの色相を徐々に変え、途中で文字を「同意への迷い」にします。同意しないのボタンと本文は消えていきます。
    /// 同時に窓を戦闘用の大きさへ広げ、迷いを行き先へ動かします。
    /// </summary>
    private void UpdateMorph()
    {
        float t = Mathf.Clamp01(phaseTime / MorphDuration);
        float smooth = Mathf.SmoothStep(0f, 1f, t);

        boss!.SetHue(Mathf.Lerp(ConsentAssets.AgreeHue, HesitationHue, t));
        boss.SetTextColor(Color.Lerp(ConsentAssets.AgreeTextColor, HesitationTextColor, t));
        if (!labelChanged && t > 0.5f)
        {
            boss.SetLabel(Language.Translate("consenter.minigame.shooting.hesitation.enemy"));
            labelChanged = true;
        }
        if (disagreeButton.GameObject) ConsentUI.SetAlpha(disagreeButton.GameObject, 1f - t);
        if (body) body.alpha = 1f - t;

        //窓を広げる
        float scale = Mathf.Lerp(DialogScale, BattleDialogScale, smooth);
        Host.ChangeDialog(Vector2.Lerp(StandardDialogSize, BattleDialogSize, smooth), t >= 1f ? GeneralInstructionKey : null, scale);

        //迷いを行き先へ動かす。窓の縮尺で割って、いまの窓の中での位置と大きさに直す
        boss.Transform.localPosition = Vector3.Lerp(morphFromPos, morphToPos, smooth) / scale;
        boss.Transform.localScale = Vector3.Lerp(morphFromScale, morphToScale, smooth) / scale;

        if (t >= 1f)
        {
            GameObject.Destroy(disagreeButton.GameObject);
            GameObject.Destroy(body.gameObject);
            SetUpBattle();
            boss.Transform.localPosition = new(bossPos.x, bossPos.y, -0.3f);
            phase = endurance ? Phase.Scatter : Phase.Battle;
            phaseTime = 0f;
            if (endurance) StartScatter();
        }
    }

    /// <summary>
    /// 耐久で、迷いのいる場所に紫の小さな四角を4つ出します。
    /// </summary>
    private void StartScatter()
    {
        float inset = CornerSquareSize * 0.5f + 0.08f;
        corners[0] = new(field.xMin + inset, field.yMax - inset);
        corners[1] = new(field.xMax - inset, field.yMax - inset);
        corners[2] = new(field.xMin + inset, field.yMin + inset);
        corners[3] = new(field.xMax - inset, field.yMin + inset);
        for (int i = 0; i < 4; i++)
        {
            cornerSquares[i] = ConsentUI.Box(Root, "CornerSquare", new(bossPos.x, bossPos.y, -0.32f), new(CornerSquareSize, CornerSquareSize), CornerSquareColor);
            cornerSquares[i].transform.localScale = Vector3.zero;
        }
    }

    /// <summary>
    /// 迷いが小さくなって消えながら、四角が四隅へ速やかに散らばります。
    /// </summary>
    private void UpdateScatter()
    {
        float t = Mathf.Clamp01(phaseTime / ScatterDuration);
        //迷いは前半で小さくなって消える
        if (boss != null && boss.GameObject) boss.Transform.localScale = morphToScale / BattleDialogScale * Mathf.Clamp01(1f - t * 2f);

        //四角は大きくなりながら、出だしの速い動きで四隅へ
        float move = 1f - Mathf.Pow(1f - t, 3f);
        float size = Mathf.Clamp01(t * 3f) * CornerSquareSize / 0.16f;
        for (int i = 0; i < 4; i++)
        {
            var pos = Vector2.Lerp(bossPos, corners[i], move);
            cornerSquares[i].transform.localPosition = new(pos.x, pos.y, -0.32f);
            cornerSquares[i].transform.localScale = new(size, size, 1f);
            cornerSquares[i].transform.localEulerAngles = new(0f, 0f, (1f - move) * 360f);
        }

        if (t >= 1f)
        {
            if (boss != null && boss.GameObject) GameObject.Destroy(boss.GameObject);
            boss = null;
            phase = Phase.Battle;
            phaseTime = 0f;
        }
    }

    private void UpdateHesitation()
    {
        //迷いは左右に揺れながら弾を撒く
        bossPos.x = field.center.x + Mathf.Sin(battleTime * 0.9f) * (field.width * 0.5f - bossHalfSize.x - 0.1f);
        if (boss != null && boss.GameObject) boss.Transform.localPosition = new(bossPos.x, bossPos.y, -0.3f);

        patternTimer -= Time.deltaTime;
        if (patternTimer < 0f && bossHp > 0)
        {
            float progress = 1f - (float)bossHp / BossHp;
            switch (RandomInt(3))
            {
                case 0:
                    //全方位
                    int ways = 10 + (int)(progress * 8);
                    for (int i = 0; i < ways; i++)
                    {
                        float a = patternAngle + i * Mathf.PI * 2f / ways;
                        Fire(enemyBullets, bossPos, new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * 1.6f, new(0.85f, 0.7f, 1f), BulletRadius);
                    }
                    patternAngle += 0.2f;
                    break;
                case 1:
                    //自機を狙う3方向
                    var dir = (playerPos - bossPos).normalized;
                    for (int i = -1; i <= 1; i++) Fire(enemyBullets, bossPos, (Vector2)(Quaternion.Euler(0f, 0f, i * 15f) * dir) * 2.4f, new(1f, 0.75f, 0.3f), BulletRadius);
                    break;
                default:
                    //ばらまき
                    for (int i = 0; i < 6; i++) Fire(enemyBullets, bossPos, new Vector2(RandomRange(-1f, 1f), RandomRange(-1f, -0.3f)).normalized * RandomRange(1.2f, 2f), new(1f, 0.5f, 0.8f), BulletRadius);
                    break;
            }
            patternTimer = Mathf.Lerp(0.9f, 0.5f, progress);
        }

        //自機の弾
        fireTimer -= Time.deltaTime;
        if (fireTimer < 0f)
        {
            Fire(playerBullets, playerPos + new Vector2(0f, PlayerRadius), new(0f, 5f), new(0.7f, 1f, 0.7f), 0.04f);
            fireTimer = 0.12f;
        }
        MoveBullets(playerBullets, playerRenderer, b =>
        {
            if (bossHp > 0 && Mathf.Abs(b.Position.x - bossPos.x) < bossHalfSize.x && Mathf.Abs(b.Position.y - bossPos.y) < bossHalfSize.y)
            {
                bossHp--;
                if (bossHp <= 0 && boss != null && boss.GameObject) GameObject.Destroy(boss.GameObject);
                return true;
            }
            return false;
        }, true);
    }

    private void UpdateEndurance()
    {
        float progress = Mathf.Clamp01(battleTime / EnduranceTime);

        //螺旋：四隅のどこかから、射出角度をゆっくり回しながら、狭い2方向の弾を7方向へ出し続ける
        if (spiralTime > 0f)
        {
            spiralTime -= Time.deltaTime;
            spiralAngle += SpiralRotateSpeed * Time.deltaTime;
            spiralTimer -= Time.deltaTime;
            //撃つ時間と休む時間を繰り返す。射出角度は休む間も回り続ける
            bool bursting = (SpiralDuration - spiralTime) % (SpiralBurstTime + SpiralRestTime) < SpiralBurstTime;
            //対角の隅からは、いろいろな種類の弾を撃つ(左右に流れる列の弾は除く)
            diagonalTimer -= Time.deltaTime;
            if (diagonalTimer < 0f)
            {
                diagonalTimer = DiagonalInterval;
                FireFromDiagonal(corners[3 - spiralCorner]);
            }

            if (bursting && spiralTimer < 0f)
            {
                spiralTimer = SpiralInterval;
                for (int i = 0; i < SpiralArms; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        float a = (spiralAngle + i * 360f / SpiralArms + (j - 0.5f) * SpiralSpread) * Mathf.Deg2Rad;
                        Fire(enemyBullets, spiralOrigin, new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * 1.5f, new(0.75f, 0.95f, 1f), BulletRadius);
                    }
                }
            }
            return;
        }

        //四隅の四角から弾が飛んでくる。時間とともに激しくなる
        patternTimer -= Time.deltaTime;
        if (patternTimer >= 0f) return;

        var color = EndurancePalette[RandomInt(EndurancePalette.Length)];
        switch (RandomInt(5))
        {
            case 0:
                {
                    //上の2つの隅から、下の内側へ扇状にばらまく
                    int count = 4 + (int)(progress * 3);
                    for (int c = 0; c < 2; c++)
                    {
                        var corner = corners[c];
                        bool isLeft = corner.x < field.center.x;
                        for (int i = 0; i < count; i++)
                        {
                            float deg = isLeft ? RandomRange(-85f, -20f) : RandomRange(-160f, -95f);
                            float a = deg * Mathf.Deg2Rad;
                            Fire(enemyBullets, corner, new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * RandomRange(1.4f, 2.1f), color, BulletRadius);
                        }
                    }
                    break;
                }
            case 1:
                FireRow(color);
                break;
            case 2:
                {
                    //四隅の四角のどれかから自機を狙う
                    var corner = corners[RandomInt(4)];
                    var dir = (playerPos - corner).normalized;
                    for (int i = -1; i <= 1; i++) Fire(enemyBullets, corner, (Vector2)(Quaternion.Euler(0f, 0f, i * 12f) * dir) * 2.3f, color, BulletRadius);
                    break;
                }
            case 3:
                {
                    //四隅の四角のどれかから円形に広がり、一度止まってから再び加速する弾
                    var origin = corners[RandomInt(4)];
                    float offset = RandomRange(0f, Mathf.PI * 2f);
                    for (int i = 0; i < RingBullets; i++)
                    {
                        float a = offset + i * Mathf.PI * 2f / RingBullets;
                        FireCurved(origin, new(Mathf.Cos(a), Mathf.Sin(a)), RingSpeed, RingColor);
                    }
                    break;
                }
            default:
                {
                    //螺旋を始める。四隅の四角のどれかから出し、最初の向きは場の内側へ向ける
                    spiralCorner = RandomInt(4);
                    spiralOrigin = corners[spiralCorner];
                    diagonalTimer = DiagonalInterval * 0.5f;
                    var inward = field.center - spiralOrigin;
                    spiralTime = SpiralDuration;
                    spiralTimer = 0f;
                    spiralAngle = Mathf.Atan2(inward.y, inward.x) * Mathf.Rad2Deg;
                    break;
                }
        }
        patternTimer = Mathf.Lerp(0.75f, 0.4f, progress);
    }

    /// <summary>
    /// 螺旋の間に、対角の隅から撃つ弾です。自機狙い、扇状のばらまき、一度止まる円形の弾、ランダムな散弾のどれかを撃ちます。
    /// 左右に流れる列の弾は、螺旋と重なると避けようがなくなるので撃ちません。
    /// </summary>
    private void FireFromDiagonal(Vector2 corner)
    {
        //色は、同じ種類の弾がふだん使う色にそろえる
        var color = EndurancePalette[RandomInt(EndurancePalette.Length)];
        var inward = (field.center - corner).normalized;
        float inwardDeg = Mathf.Atan2(inward.y, inward.x) * Mathf.Rad2Deg;
        switch (RandomInt(4))
        {
            case 0:
                {
                    //自機を狙う狭い3方向
                    var aim = (playerPos - corner).normalized;
                    for (int i = -1; i <= 1; i++) Fire(enemyBullets, corner, (Vector2)(Quaternion.Euler(0f, 0f, i * 8f) * aim) * 2.1f, color, BulletRadius);
                    break;
                }
            case 1:
                //場の内側へ扇状にばらまく
                for (int i = 0; i < 5; i++)
                {
                    float a = (inwardDeg + RandomRange(-35f, 35f)) * Mathf.Deg2Rad;
                    Fire(enemyBullets, corner, new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * RandomRange(1.4f, 2f), color, BulletRadius);
                }
                break;
            case 2:
                {
                    //一度止まってから加速する円形の弾
                    float offset = RandomRange(0f, Mathf.PI * 2f);
                    for (int i = 0; i < RingBullets; i++)
                    {
                        float a = offset + i * Mathf.PI * 2f / RingBullets;
                        FireCurved(corner, new(Mathf.Cos(a), Mathf.Sin(a)), RingSpeed, RingColor);
                    }
                    break;
                }
            default:
                //内側へ向けた、速さのばらばらな等間隔の4方向
                for (int i = 0; i < 4; i++)
                {
                    float a = (inwardDeg + (i - 1.5f) * 18f) * Mathf.Deg2Rad;
                    Fire(enemyBullets, corner, new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * RandomRange(1.2f, 2.3f), color, BulletRadius);
                }
                break;
        }
    }

    //列になる弾の動き
    private const int RowBullets = 6;
    private const float RowPitch = 0.28f;
    private const float RowGatherTime = 0.6f;
    private const float RowWaitTime = 0.15f;
    private const float RowAccelTime = 0.4f;
    private const float RowSpeed = 2f;

    /// <summary>
    /// 左右どちらかの隅2つから上下へ弾を出し、減速しながら縦の列に並べてから、反対側へ向けて動き出させます。
    /// </summary>
    private void FireRow(Color color)
    {
        bool fromLeft = Random01 < 0.5f;
        var top = fromLeft ? corners[0] : corners[1];
        var bottom = fromLeft ? corners[2] : corners[3];
        float x = top.x;
        float centerY = RandomRange(field.yMin + 0.3f + RowPitch * RowBullets * 0.5f, field.yMax - 0.3f - RowPitch * RowBullets * 0.5f);
        float direction = fromLeft ? 1f : -1f;

        for (int i = 0; i < RowBullets; i++)
        {
            float targetY = centerY + (i - (RowBullets - 1) * 0.5f) * RowPitch;
            //上半分は上の隅から下へ、下半分は下の隅から上へ
            float startY = targetY > centerY ? top.y : bottom.y;
            Vector2 PathAt(float age)
            {
                if (age < RowGatherTime)
                {
                    //出だしが速く、並ぶ位置で止まるように減速する
                    float t = age / RowGatherTime;
                    return new(x, Mathf.Lerp(startY, targetY, 1f - (1f - t) * (1f - t)));
                }
                age -= RowGatherTime;
                if (age < RowWaitTime) return new(x, targetY);
                age -= RowWaitTime;
                //止まった状態から加速し、その後は一定の速さで進む
                float distance = age < RowAccelTime
                    ? RowSpeed * age * age / (2f * RowAccelTime)
                    : RowSpeed * RowAccelTime * 0.5f + RowSpeed * (age - RowAccelTime);
                return new(x + direction * distance, targetY);
            }
            enemyBullets.Add(new Bullet() { Position = new(x, startY), Path = PathAt, Color = color, Radius = BulletRadius });
        }
    }

    /// <summary>
    /// 円形に広がる弾の速さです。減速して止まり、少し待ってから再び加速します。
    /// </summary>
    static private float RingSpeed(float age)
    {
        if (age < RingStopTime) return Mathf.Lerp(RingStartSpeed, 0f, age / RingStopTime);
        age -= RingStopTime;
        if (age < RingWaitTime) return 0f;
        age -= RingWaitTime;
        return Mathf.Lerp(0f, RingEndSpeed, Mathf.Clamp01(age / RingAccelTime));
    }

    /// <summary>
    /// 速さが時間で変わる弾を撃ちます。
    /// </summary>
    private void FireCurved(Vector2 pos, Vector2 direction, Func<float, float> speed, Color color)
    {
        enemyBullets.Add(new Bullet() { Position = pos, Direction = direction, Speed = speed, Velocity = direction * speed(0f), Color = color, Radius = BulletRadius });
    }

    /// <summary>
    /// 弾を動かして描き直します。当たり判定がtrueになった弾があればtrueを返します。removeOnHitなら当たった弾は消します。
    /// 場から完全に出た弾は消します。場の縁はマスクで切れて見えます。
    /// </summary>
    private bool MoveBullets(List<Bullet> list, ConsentBulletRenderer renderer, Func<Bullet, bool> hit, bool removeOnHit = false)
    {
        bool anyHit = false;
        renderer.Clear();
        for (int i = list.Count - 1; i >= 0; i--)
        {
            var b = list[i];
            b.Age += Time.deltaTime;
            if (b.Path != null) b.Position = b.Path(b.Age);
            else
            {
                if (b.Speed != null) b.Velocity = b.Direction * b.Speed(b.Age);
                b.Position += b.Velocity * Time.deltaTime;
            }

            //場から完全に出たら消す
            if (b.Position.x < field.xMin - b.Radius || b.Position.x > field.xMax + b.Radius || b.Position.y < field.yMin - b.Radius || b.Position.y > field.yMax + b.Radius)
            {
                list.RemoveAt(i);
                continue;
            }
            if (hit(b))
            {
                anyHit = true;
                if (removeOnHit)
                {
                    list.RemoveAt(i);
                    continue;
                }
            }
            renderer.Add(b.Position, b.Radius, b.Color);
        }
        renderer.Apply();
        return anyHit;
    }
}
