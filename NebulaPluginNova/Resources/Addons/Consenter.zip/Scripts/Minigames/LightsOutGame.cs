namespace Consenter;

/// <summary>
/// 押すと上下左右の隣のチェックも切り替わるチェックボックスを、すべてチェックしてから同意するミニゲームです。
/// すべてチェックした状態から何回か押した盤面を出題するので、必ず解けます。
/// </summary>
public class LightsOutGame : ConsentGame
{
    public override Vector2 DialogSize => new(5.6f, 4.7f);
    //最初はStandardと同じ画面を見せ、同意するを押すと窓が広がって始まる
    public override bool UsesStandardIntro => true;
    public override float? IdleTimeout => 30f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int Size = 4;
    private const float Pitch = 0.62f;
    private readonly bool[,] checks = new bool[Size, Size];
    private readonly SpriteRenderer[,] marks = new SpriteRenderer[Size, Size];

    private bool AllChecked
    {
        get
        {
            foreach (var c in checks) if (!c) return false;
            return true;
        }
    }

    public override void Begin()
    {
        var area = ContentArea;
        var center = new Vector2(0f, area.yMin + 0.75f + (area.height - 0.75f) * 0.5f);

        for (int x = 0; x < Size; x++) for (int y = 0; y < Size; y++) checks[x, y] = true;
        //すべてチェックした状態から押していく。全部チェック済みのままにはしない
        do
        {
            int presses = RandomInt(4, 8);
            for (int i = 0; i < presses; i++) Toggle(RandomInt(Size), RandomInt(Size), false);
        } while (AllChecked);

        for (int x = 0; x < Size; x++)
        {
            for (int y = 0; y < Size; y++)
            {
                int cx = x, cy = y;
                var pos = new Vector3(center.x + (x - (Size - 1) * 0.5f) * Pitch, center.y + (y - (Size - 1) * 0.5f) * Pitch, -0.2f);
                var box = ConsentUI.Sprite(Root, "CheckBox", pos, ConsentAssets.CheckBox.GetSprite(), null, 0.85f);
                marks[x, y] = ConsentUI.Sprite(box.transform, "CheckMark", new(0f, 0f, -0.01f), ConsentAssets.CheckMark.GetSprite());
                Clicks.Add(box.transform, new Vector2(0.64f, 0.64f), () => Toggle(cx, cy, true));
            }
        }
        Refresh();

        float buttonY = area.yMin + 0.32f;
        bool agreeOnLeft = Random01 < 0.5f;
        ConsentTitleButton? agree = null;
        agree = AddAgreeButton(new(agreeOnLeft ? -1.3f : 1.3f, buttonY), 2.1f, () =>
        {
            if (AllChecked) Succeed();
            else Shake(agree!.Transform);
        });
        AddDisagreeButton(new(agreeOnLeft ? 1.3f : -1.3f, buttonY), 2.1f);
    }

    private void Toggle(int x, int y, bool refresh)
    {
        void Flip(int tx, int ty)
        {
            if (tx < 0 || ty < 0 || tx >= Size || ty >= Size) return;
            checks[tx, ty] = !checks[tx, ty];
        }
        Flip(x, y);
        Flip(x - 1, y);
        Flip(x + 1, y);
        Flip(x, y - 1);
        Flip(x, y + 1);
        if (refresh) Refresh();
    }

    private void Refresh()
    {
        for (int x = 0; x < Size; x++) for (int y = 0; y < Size; y++) if (marks[x, y]) marks[x, y].gameObject.SetActive(checks[x, y]);
    }
}
