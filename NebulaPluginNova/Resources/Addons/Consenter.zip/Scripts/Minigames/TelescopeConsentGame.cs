namespace Consenter;

/// <summary>
/// Polusの天体観測(TelescopeGame)の画面を使って、同意するボタンを探すミニゲームです。
/// 天体の代わりに、同意するボタンが1つと同意しないボタンが置かれた星空をドラッグして動かし、照準を合わせます。
/// 照準を合わせたまま3回点滅するまで待つと、同意するなら同意、同意しないなら不同意になります。
/// バニラで探す天体を示していた小さな丸と、ミニゲームの閉じるボタンは出しません。照準の丸はバニラの0.6倍です。
/// 近づくほど速くなる探知音はバニラのものを使います。
/// </summary>
public class TelescopeConsentGame : ConsentGame
{
    public override Vector2 DialogSize => new(4.9f, 5.04f);
    //最初はStandardと同じ画面を見せ、同意するを押すと窓が広がって始まる
    public override bool UsesStandardIntro => true;
    public override float? IdleTimeout => 30f;
    public override string? InstructionKey => GeneralInstructionKey;

    //NoSが読み込んでいるPolusの番号
    private const int PolusMapId = 2;
    //照準を合わせてから決まるまでの点滅の回数と間隔(バニラと同じ)
    private const int BlinkCount = 3;
    private const float BlinkOn = 0.1f, BlinkOff = 0.2f;
    //星空を動かせる範囲(バニラと同じ)
    private const float ClampX = 6f, ClampY = 7f;
    //照準の丸の大きさ(バニラに対する倍率)
    private const float ReticleScale = 0.6f;
    //星空のボタンの大きさの揺らぎ(±の割合)
    private const float SizeJitter = 0.15f;
    //天体の大きさに対する、星空のボタンの高さの割合
    private const float ButtonHeightRatio = 0.7f * 0.6f * 0.45f;
    //天体観測の画面の大きさ。以前の窓(6.4×5.6)いっぱいに広げたときに対する倍率で決める
    private const float ViewerScale = 0.48f * 0.8f;
    private static readonly Vector2 ReferenceContentSize = new(6.4f - 0.3f, 5.6f - 1.0f);

    private Transform? background;
    private SpriteRenderer? reticle;
    private Color reticleColor = Color.white;
    private ConsentSimpleButton agreeButton = null!;
    private readonly List<ConsentSimpleButton> disagreeButtons = [];
    private AudioClip? blipSound;
    private Transform? telescopeRoot;
    private float blipTimer = 0f;

    private bool dragging = false;
    private Vector3 lastMouseWorld;

    //今照準を合わせているボタンと、合わせてからの時間
    private ConsentSimpleButton? aiming = null;
    private float aimTime = 0f;
    private bool decided = false;

    /// <summary>
    /// Polusのタスクの中から、天体観測のミニゲームを探します。
    /// </summary>
    static private TelescopeGame? FindPrefab()
    {
        var polus = VanillaAsset.MapAsset[PolusMapId];
        if (!polus) return null;
        foreach (var tasks in new[] { polus.CommonTasks, polus.LongTasks, polus.ShortTasks })
        {
            if (tasks == null) continue;
            foreach (var task in tasks)
            {
                var game = task?.MinigamePrefab?.TryCast<TelescopeGame>();
                if (game) return game;
            }
        }
        return null;
    }

    public override void Begin()
    {
        var area = ContentArea;
        var prefab = FindPrefab();
        if (prefab == null)
        {
            //見つからないときは、Standardと同じ画面で代わりにする
            CreateStandardScreen(Succeed, Fail);
            return;
        }

        //バニラのミニゲームとして動かないよう、非表示の親の下で複製し、動きを持つ部品を外してから表示する
        var hidden = ConsentUI.Object(Root, "TelescopeHolder", new(0f, 0f, -0.1f));
        hidden.SetActive(false);
        var telescope = GameObject.Instantiate(prefab, hidden.transform);
        background = telescope.Background;
        reticle = telescope.ReticleImage;
        blipSound = telescope.BlipSound;
        var itemDisplay = telescope.ItemDisplay;
        var items = telescope.Items.ToArray();
        var reticleTransform = telescope.Reticle ? telescope.Reticle.transform : reticle ? reticle.transform : null;

        var telescopeObj = telescope.gameObject;
        ConsentVanillaMinigame.Strip(telescopeObj, telescope);
        telescopeObj.transform.localPosition = Vector3.zero;
        telescopeObj.transform.localScale = Vector3.one;
        hidden.SetActive(true);

        //画面の大きさに合わせて縮め、真ん中に置く。窓の背景より手前に来るように奥行きもずらす
        //丸い範囲の中だけに見える星空は外に大きくはみ出しているので、隠されない絵だけで大きさを測る
        var renderers = telescopeObj.GetComponentsInChildren<SpriteRenderer>(true).Where(r => r.gameObject.activeInHierarchy && r.sprite && r.maskInteraction == SpriteMaskInteraction.None).ToArray();
        var frame = renderers.OrderByDescending(r => r.bounds.size.x * r.bounds.size.y).FirstOrDefault();
        var bounds = frame ? frame!.bounds : new Bounds(hidden.transform.position, Vector3.one);
        Vector2 localSize = Root.InverseTransformVector(bounds.size);
        float viewerWidth = Math.Max(Mathf.Abs(localSize.x), 0.01f), viewerHeight = Math.Max(Mathf.Abs(localSize.y), 0.01f);
        float scale = Math.Min(ReferenceContentSize.x / viewerWidth, ReferenceContentSize.y / viewerHeight) * ViewerScale;
        //今の窓に収まらないときは、収まるまで縮める
        scale = Math.Min(scale, Math.Min(area.width / viewerWidth, area.height / viewerHeight));
        hidden.transform.localScale = new(scale, scale, scale * 0.01f);
        Vector2 center = Root.InverseTransformPoint(frame ? frame!.bounds.center : hidden.transform.position);
        var holderPos = hidden.transform.localPosition;
        hidden.transform.localPosition = new(holderPos.x + area.center.x - center.x, holderPos.y + area.center.y - center.y, holderPos.z);
        telescopeRoot = hidden.transform;

        //天体の代わりに、同意する・同意しないのボタンを置く。同意するは1つだけ
        if (background && items.Length > 0)
        {
            int agreeIndex = RandomInt(items.Length);
            //ボタンの大きさは天体の大きさの中央値にそろえ、ボタンごとに少しだけ揺らす
            var heights = items.Where(item => item).Select(item =>
            {
                var r = item.GetComponent<SpriteRenderer>();
                return r ? r.bounds.size.y : 0.6f;
            }).OrderBy(h => h).ToArray();
            float baseHeight = heights.Length > 0 ? heights[heights.Length / 2] : 0.6f;
            for (int i = 0; i < items.Length; i++)
            {
                var item = items[i];
                if (!item) continue;
                var itemRenderer = item.GetComponent<SpriteRenderer>();
                var worldCenter = itemRenderer ? itemRenderer.bounds.center : item.transform.position;
                float height = baseHeight * RandomRange(1f - SizeJitter, 1f + SizeJitter);
                var worldSize = new Vector2(height, height);
                item.gameObject.SetActive(false);

                bool isAgree = i == agreeIndex;
                var button = CreateSkyButton(background!, worldCenter, worldSize, isAgree);
                if (isAgree) agreeButton = button;
                else disagreeButtons.Add(button);
            }
        }

        //探す天体を示していた小さな丸は使わない。丸の枠ごと隠す
        if (itemDisplay)
        {
            var parent = itemDisplay.transform.parent;
            if (parent && parent != telescopeObj.transform && parent != background) parent.gameObject.SetActive(false);
            else itemDisplay.gameObject.SetActive(false);
        }

        //照準の丸を小さくする。照準の当たり判定も一緒に縮む
        if (reticleTransform) reticleTransform!.localScale *= ReticleScale;
        if (reticle && reticle!.transform != reticleTransform && !reticle.transform.IsChildOf(reticleTransform!)) reticle.transform.localScale *= ReticleScale;

        //最初の向きはばらばらにする
        if (background)
        {
            var pos = background!.localPosition;
            background.localPosition = new(RandomRange(-ClampX, ClampX), RandomRange(-ClampY, ClampY), pos.z);
        }

        //星空のどこを押してもドラッグできる。押し始めはPassiveButtonで受ける
        var dragArea = ConsentUI.Object(Root, "DragArea", new(area.center.x, area.center.y, -0.3f));
        Clicks.AddPress(dragArea.transform, area.size, () =>
        {
            dragging = true;
            lastMouseWorld = Clicks.MouseWorld;
        });
    }

    /// <summary>
    /// 星空の中の、与えた位置と大きさに収まるボタンを作ります。星空と一緒に動き、望遠鏡の丸い範囲の外では見えません。
    /// </summary>
    private ConsentSimpleButton CreateSkyButton(Transform parent, Vector3 worldCenter, Vector2 worldSize, bool isAgree, bool masked = true)
    {
        //文字が読めるよう、天体より横長にする
        //画面を縮めた分は打ち消し、ボタンの見た目の大きさは変えない
        float height = Math.Max(worldSize.y, 0.2f * ViewerScale) * ButtonHeightRatio / ViewerScale;
        var size = new Vector2(height * 3f, height);
        var holder = UnityHelper.CreateObject(isAgree ? "Agree" : "Disagree", parent, Vector3.zero, ConsentUI.UILayer);
        //照準や枠より前に出ないよう、ほんの少しだけ手前に置く
        holder.transform.position = new(worldCenter.x, worldCenter.y, worldCenter.z - 0.0005f);
        //親の縮尺を打ち消して、見た目の大きさをそろえる
        var lossy = parent.lossyScale;
        holder.transform.localScale = new(1f / Math.Max(Mathf.Abs(lossy.x), 1e-4f), 1f / Math.Max(Mathf.Abs(lossy.y), 1e-4f), 1f);
        var button = ConsentUI.SimpleButton(holder.transform, "Button", Vector3.zero, size,
            isAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText, isAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree, height * 3.2f);
        if (masked) ConsentUI.SetMasked(holder);
        return button;
    }

    public override void Update()
    {
        if (background == null || decided) return;

        //ドラッグで星空を動かす
        if (dragging)
        {
            if (!Clicks.MouseHeld) dragging = false;
            else
            {
                var mouse = Clicks.MouseWorld;
                Vector3 delta = background.parent.InverseTransformVector(mouse - lastMouseWorld);
                lastMouseWorld = mouse;
                var pos = background.localPosition;
                background.localPosition = new(Mathf.Clamp(pos.x + delta.x, -ClampX, ClampX), Mathf.Clamp(pos.y + delta.y, -ClampY, ClampY), pos.z);
            }
        }

        UpdateBlip();
        UpdateAim();
    }

    private Vector2 ReticleCenter => reticle ? (Vector2)reticle!.bounds.center : (Vector2)Root.position;

    /// <summary>
    /// 照準の真ん中が、ボタンの上にあるかどうかを調べます。
    /// </summary>
    private bool IsAiming(ConsentSimpleButton button)
    {
        if (!button.Background) return false;
        Vector2 local = button.Transform.InverseTransformPoint(ReticleCenter);
        return button.LocalRect.Contains(local);
    }

    private void UpdateAim()
    {
        ConsentSimpleButton? current = null;
        if (agreeButton != null && IsAiming(agreeButton)) current = agreeButton;
        else current = disagreeButtons.FirstOrDefault(IsAiming);

        if (current != aiming)
        {
            aiming = current;
            aimTime = 0f;
        }
        if (aiming == null)
        {
            SetReticleColor(Color.white);
            return;
        }

        //バニラと同じく、3回点滅してから決まる。同意するなら緑、同意しないなら赤
        bool isAgree = aiming == agreeButton;
        var color = isAgree ? Color.green : Color.red;
        aimTime += Time.deltaTime;
        float cycle = BlinkOn + BlinkOff;
        if (aimTime >= cycle * BlinkCount)
        {
            SetReticleColor(color);
            decided = true;
            if (isAgree) Succeed();
            else Fail();
            return;
        }
        SetReticleColor(aimTime % cycle < BlinkOn ? color : Color.white);
    }

    private void SetReticleColor(Color color)
    {
        if (!reticle || reticleColor == color) return;
        reticleColor = color;
        reticle!.color = color;
    }

    /// <summary>
    /// 同意するボタンに近いほど速く鳴る探知音です。バニラと同じ間隔で鳴らします。
    /// </summary>
    private void UpdateBlip()
    {
        if (!blipSound || agreeButton == null || !agreeButton.Background) return;
        blipTimer -= Time.deltaTime;
        if (blipTimer > 0f) return;
        //縮めて置いているので、バニラの大きさでの距離に直す
        float worldScale = telescopeRoot ? Math.Max(Mathf.Abs(telescopeRoot!.lossyScale.x), 1e-4f) : 1f;
        float distance = Vector2.Distance(agreeButton.Transform.position, ReticleCenter) / worldScale;
        blipTimer = Mathf.Lerp(0.01f, 1f, distance / 10f);
        if (Constants.ShouldPlaySfx()) SoundManager.Instance.PlaySoundImmediate(blipSound, false);
    }
}
