namespace Consenter;

/// <summary>
/// 同意する・同意しないのカードが伏せられてシャッフルされるので、同意するのカードを当てるミニゲームです。
/// ShuffleEasyは4枚を1列で、ShuffleHardは8枚を2列で、より多く速く入れ替えます。同意しないのカードを選ぶと失敗します。
/// カードを選ぶと、すべてのカードの表が透けて見えるようになり(選んだカードははっきりと)、それを確かめられる時間を取ってから閉じます。
/// </summary>
public class ShuffleGame : ConsentGame
{
    private readonly bool hard;
    public ShuffleGame(bool hard) { this.hard = hard; }

    public override Vector2 DialogSize => hard ? new(6.4f, 4.4f) : new(6.4f, 3.6f);
    public override float? IdleTimeout => 15f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const float Pitch = 1.45f;
    private const float RowPitch = 1.05f;
    private static readonly Vector2 CardSize = new(1.25f, 0.8f);

    private class Card
    {
        public ConsentSimpleButton Button = null!;
        public bool IsAgree;
        public int Slot;
    }

    private int NumOfCards => hard ? 8 : 4;
    private int Columns => 4;
    private Card[] cards = null!;
    private Vector2 center;
    private int remainingSwaps;
    private float swapDuration;
    //入れ替え中の2枚と、その進み具合
    private (Card a, Card b, float progress)? swapping = null;
    private float timer = 1.3f;
    private bool selectable = false;

    private Vector2 SlotPosition(int slot)
    {
        int rows = NumOfCards / Columns;
        int x = slot % Columns, y = slot / Columns;
        return center + new Vector2((x - (Columns - 1) * 0.5f) * Pitch, -(y - (rows - 1) * 0.5f) * RowPitch);
    }

    public override void Begin()
    {
        var area = ContentArea;
        center = new(0f, area.center.y + 0.05f);
        cards = new Card[NumOfCards];
        int agreeSlot = RandomInt(NumOfCards);
        remainingSwaps = hard ? RandomInt(12, 17) : RandomInt(6, 10);
        swapDuration = hard ? RandomRange(0.2f, 0.26f) : RandomRange(0.3f, 0.42f);

        for (int i = 0; i < NumOfCards; i++)
        {
            var card = new Card() { IsAgree = i == agreeSlot, Slot = i };
            var style = card.IsAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree;
            var pos = SlotPosition(i);
            card.Button = ConsentUI.SimpleButton(Root, "Card", new(pos.x, pos.y, -0.2f), CardSize, card.IsAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText, style, 1.1f);
            Clicks.Add(card.Button.Transform, card.Button.LocalRect, () => Select(card)).Predicate = () => selectable;
            cards[i] = card;
        }
    }

    private void SetFaceDown(bool faceDown)
    {
        foreach (var card in cards)
        {
            var style = card.IsAgree ? ConsentButtonStyle.Agree : ConsentButtonStyle.Disagree;
            card.Button.Background.color = faceDown ? ConsentAssets.NeutralColor : ConsentUI.ColorOf(style);
            card.Button.Text.color = faceDown ? ConsentAssets.NeutralTextColor : ConsentUI.TextColorOf(style);
            card.Button.Text.text = faceDown ? "?" : (card.IsAgree ? ConsentUI.AgreeText : ConsentUI.DisagreeText);
            card.Button.Text.fontSize = (faceDown ? 3f : 1.1f) * ConsentUI.SimpleButtonFontScale;
        }
    }

    private Card? selected = null;

    private void Select(Card card)
    {
        selectable = false;
        selected = card;
        SetFaceDown(false);
        //選ばなかったカードは透けて見せ、選んだカードは少し大きくする
        foreach (var c in cards) if (c != card) ConsentUI.SetAlpha(c.Button.GameObject, 0.4f);
        FinishAfter(card.IsAgree);
    }

    public override void Update()
    {
        if (selected != null)
        {
            selected.Button.Transform.localScale = Vector3.Lerp(selected.Button.Transform.localScale, Vector3.one * 1.15f, Time.deltaTime * 10f);
            return;
        }

        //最初は表で見せ、伏せてから入れ替える
        if (timer > 0f)
        {
            timer -= Time.deltaTime;
            if (timer <= 0f) SetFaceDown(true);
            return;
        }

        if (swapping.HasValue)
        {
            var (a, b, progress) = swapping.Value;
            progress += Time.deltaTime / swapDuration;
            float t = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(progress));
            Vector2 fromA = SlotPosition(a.Slot), fromB = SlotPosition(b.Slot);
            //2枚は互いに逆側へふくらむ弧を描いて入れ替わる
            var dir = (fromB - fromA).normalized;
            var side = new Vector2(-dir.y, dir.x) * Mathf.Sin(t * Mathf.PI) * 0.45f;
            var posA = Vector2.Lerp(fromA, fromB, t) + side;
            var posB = Vector2.Lerp(fromB, fromA, t) - side;
            a.Button.Transform.localPosition = new(posA.x, posA.y, -0.25f);
            b.Button.Transform.localPosition = new(posB.x, posB.y, -0.2f);
            if (progress >= 1f)
            {
                (a.Slot, b.Slot) = (b.Slot, a.Slot);
                swapping = null;
            }
            else swapping = (a, b, progress);
            return;
        }

        if (remainingSwaps > 0)
        {
            remainingSwaps--;
            int i = RandomInt(NumOfCards), j = RandomInt(NumOfCards - 1);
            if (j >= i) j++;
            swapping = (cards[i], cards[j], 0f);
            return;
        }

        selectable = true;
    }
}
