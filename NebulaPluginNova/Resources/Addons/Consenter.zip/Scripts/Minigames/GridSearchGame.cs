namespace Consenter;

/// <summary>
/// 広いボタンの格子の中から、同意するを探して押すミニゲームです。ドラッグかホイールで見る場所を上下左右に動かせます。
/// 上下左右に動かすので、NoSのスクロールビュー(縦だけ)ではなく、マスクと自前のドラッグで動かします。
/// 同意するは格子のどこかに6個あり、どれを押しても同意できます。「同意する」に似た文字のボタンを押すと失敗します。
/// </summary>
public class GridSearchGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.6f, 4.6f);
    //最初はStandardと同じ画面を見せ、同意するを押すと窓が広がって始まる
    public override bool UsesStandardIntro => true;
    public override float? IdleTimeout => 40f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int Columns = 14;
    private const int Rows = 16;
    private const int NumOfTargets = 6;
    private static readonly Vector2 CellSize = new(1.15f, 0.42f);
    private static readonly Vector2 Pitch = new(1.24f, 0.5f);
    private const float FontSize = 0.8f * 1.3f;

    private Rect viewport;
    private Transform holder = null!;
    private Vector2 offset;
    private Vector2 minOffset, maxOffset;
    private readonly HashSet<(int x, int y)> targets = [];
    private bool pressing = false;
    private Vector2 pressPos;
    private Vector2 lastMouse;
    private bool dragged = false;

    public override void Begin()
    {
        var area = ContentArea;
        viewport = area;
        var back = ConsentUI.Box(Root, "ViewportBack", new(viewport.center.x, viewport.center.y, -0.05f), viewport.size, new(0f, 0f, 0f, 0.25f));
        //押し始めはPassiveButtonで受ける。動かした量と離したかどうかは、押している間マウスを見て調べる
        Clicks.AddPress(back.transform, new Vector2(0.16f, 0.16f), () =>
        {
            var mouse = Clicks.MouseLocal(Root);
            pressing = true;
            dragged = false;
            pressPos = mouse;
            lastMouse = mouse;
        });
        ConsentUI.Mask(Root, new(viewport.center.x, viewport.center.y, 0f), viewport.size);

        while (targets.Count < NumOfTargets) targets.Add((RandomInt(Columns), RandomInt(Rows)));
        var decoys = Language.Translate("consenter.minigame.gridSearch.decoys").Split(',');

        holder = ConsentUI.Object(Root, "Grid", new(0f, 0f, -0.1f)).transform;
        for (int x = 0; x < Columns; x++)
        {
            for (int y = 0; y < Rows; y++)
            {
                bool isTarget = targets.Contains((x, y));
                string label = isTarget ? ConsentUI.AgreeText : decoys[RandomInt(decoys.Length)];
                ConsentUI.SimpleButton(holder, "Cell", CellPosition(x, y), CellSize, label, ConsentButtonStyle.Neutral, FontSize);
            }
        }
        ConsentUI.SetMasked(holder.gameObject);
        //文字がつぶれて見えないよう、輪郭はごく薄くする
        foreach (var text in holder.GetComponentsInChildren<TextMeshPro>(true))
        {
            text.outlineColor = new Color(0f, 0f, 0f, 0.15f);
            text.outlineWidth = 0.08f;
        }

        //格子の端が見る範囲の端に来るまで動かせる
        var gridSize = new Vector2(Columns * Pitch.x, Rows * Pitch.y);
        maxOffset = new(Math.Max(0f, (gridSize.x - viewport.width) * 0.5f + 0.1f), Math.Max(0f, (gridSize.y - viewport.height) * 0.5f + 0.1f));
        minOffset = -maxOffset;
        offset = new(RandomRange(minOffset.x, maxOffset.x), RandomRange(minOffset.y, maxOffset.y));
        ApplyOffset();
    }

    private Vector3 CellPosition(int x, int y) => new((x - (Columns - 1) * 0.5f) * Pitch.x, (y - (Rows - 1) * 0.5f) * Pitch.y, 0f);

    private void ApplyOffset()
    {
        offset = new(Mathf.Clamp(offset.x, minOffset.x, maxOffset.x), Mathf.Clamp(offset.y, minOffset.y, maxOffset.y));
        holder.localPosition = new(viewport.center.x + offset.x, viewport.center.y + offset.y, -0.1f);
    }

    public override void Update()
    {
        var mouse = Clicks.MouseLocal(Root);
        bool inViewport = viewport.Contains(mouse);

        if (inViewport && Clicks.Wheel != 0f)
        {
            offset.y -= Clicks.Wheel * 0.5f;
            ApplyOffset();
        }

        if (pressing && Clicks.MouseHeld)
        {
            offset += mouse - lastMouse;
            lastMouse = mouse;
            if ((mouse - pressPos).magnitude > 0.08f) dragged = true;
            ApplyOffset();
        }

        if (pressing && Clicks.MouseUp)
        {
            pressing = false;
            //ほとんど動かさずに離したらクリックとみなす
            if (!dragged && inViewport)
            {
                Vector2 local = holder.InverseTransformPoint(Clicks.MouseWorld);
                for (int x = 0; x < Columns; x++)
                {
                    for (int y = 0; y < Rows; y++)
                    {
                        Vector2 cell = CellPosition(x, y);
                        if (Mathf.Abs(local.x - cell.x) < CellSize.x * 0.5f && Mathf.Abs(local.y - cell.y) < CellSize.y * 0.5f)
                        {
                            if (targets.Contains((x, y))) Succeed();
                            else Fail();
                            return;
                        }
                    }
                }
            }
        }
    }
}
