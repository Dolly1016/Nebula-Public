namespace Consenter;

/// <summary>
/// 計算の答えを入力してから同意するミニゲームです(ArithmeticEasy / ArithmeticHard)。
/// ArithmeticEasyは2～3個の数の簡単な計算、ArithmeticHardは4～5個の数で、括弧や割り算も使う計算です。
/// ArithmeticHardの掛け算は左右とも1桁で、答えは必ず0以上になります。
/// 数字は酸素のサボタージュのテンキー(バニラ)で入力し、決定(✓)を押します。
/// 正しければ、同意しないボタンが同意するボタンに変わり、押すと同意できます。違えば失敗します。正しく答える前に同意しないを押しても失敗します。
/// テンキーが見つからないときは、自前のテンキーと決定ボタンで代わりにします。
/// </summary>
public class ArithmeticGame : ConsentGame
{
    private readonly bool hard;
    public ArithmeticGame(bool hard) { this.hard = hard; }

    public override Vector2 DialogSize => new(6.8f, 4.4f);
    //最初はStandardと同じ画面を見せ、同意するを押すと窓が広がって始まる
    public override bool UsesStandardIntro => true;
    public override float? IdleTimeout => hard ? 35f : 15f;
    public override string? InstructionKey => GeneralInstructionKey;

    private int answer;
    private bool solved = false;

    public override void Begin()
    {
        var area = ContentArea;
        string problem = hard ? MakeHardProblem(out answer) : MakeEasyProblem(out answer);

        //左半分にテンキー、右半分に問題と同意しないボタン
        float half = area.width * 0.5f;
        float leftX = area.xMin + half * 0.5f;
        float rightX = area.xMax - half * 0.5f;

        var problemText = AddText(new(rightX, area.center.y + 0.45f, -0.5f), new(half - 0.2f, 1.6f), 2.6f, problem + " = ?");
        problemText.enableAutoSizing = true;
        problemText.fontSizeMin = 1.2f;
        problemText.fontSizeMax = 2.6f;
        //正しく答えると、同意しないボタンが同意するボタンに変わる
        ConsentTitleButton? disagree = null;
        disagree = AddDisagreeButton(new(rightX, area.yMin + 0.35f), 2.1f, () =>
        {
            if (solved) Succeed();
            else Fail();
        });
        void OnSolved()
        {
            solved = true;
            disagree!.SetStyle(ConsentButtonStyle.Agree);
            disagree.SetLabel(ConsentUI.AgreeText);
            PopIn(disagree.Transform);
        }

        if (ConsentKeypad.IsAvailable)
        {
            ConsentKeypad? keypad = null;
            keypad = new ConsentKeypad(Root, new(leftX, area.center.y, -0.3f), area.height, half - 0.2f, () =>
            {
                if (solved) return;
                if (keypad!.Number == answer)
                {
                    OnSolved();
                    keypad.Lock();
                }
                else Fail();
            });
        }
        else
        {
            var pad = new ConsentNumberPad(Clicks, Root, new(leftX, area.center.y - 0.2f), 0.4f, 5);
            ConsentTitleButton? enter = null;
            enter = AddTitleButton(new(rightX, area.yMin + 1.05f), 2.1f, "OK", ConsentButtonStyle.Neutral, () =>
            {
                if (solved) return;
                if (pad.Number == answer)
                {
                    enter!.GameObject.SetActive(false);
                    OnSolved();
                }
                else Fail();
            });
        }
    }

    static private string MakeEasyProblem(out int answer)
    {
        switch (RandomInt(4))
        {
            case 0:
                {
                    int a = RandomInt(10, 100), b = RandomInt(10, 100);
                    answer = a + b;
                    return $"{a} + {b}";
                }
            case 1:
                {
                    int a = RandomInt(20, 100), b = RandomInt(1, a);
                    answer = a - b;
                    return $"{a} - {b}";
                }
            case 2:
                {
                    int a = RandomInt(2, 13), b = RandomInt(2, 13);
                    answer = a * b;
                    return $"{a} × {b}";
                }
            default:
                {
                    int a = RandomInt(1, 21), b = RandomInt(2, 10), c = RandomInt(2, 10);
                    answer = a + b * c;
                    return $"{a} + {b} × {c}";
                }
        }
    }

    /// <summary>
    /// 計算式の木です。葉は数、節は演算子('+', '-', '*', '/')です。
    /// </summary>
    private class Expr
    {
        public int Value;
        public char Op = '\0';
        public Expr? Left, Right;
        public bool IsLeaf => Op == '\0';
        static private int Precedence(char op) => op is '+' or '-' ? 1 : 2;

        /// <summary>
        /// 必要なところにだけ括弧を付けて文字にします。
        /// </summary>
        public string ToText()
        {
            if (IsLeaf) return Value.ToString();
            string Wrap(Expr child, bool isRight)
            {
                string text = child.ToText();
                if (child.IsLeaf) return text;
                int parent = Precedence(Op), mine = Precedence(child.Op);
                //優先順位が低い子と、引き算・割り算の右側の同じ優先順位の子には括弧が要る
                bool needs = mine < parent || (isRight && mine == parent && (Op == '-' || Op == '/'));
                return needs ? $"({text})" : text;
            }
            string symbol = Op switch { '*' => "×", '/' => "÷", _ => Op.ToString() };
            return $"{Wrap(Left!, false)} {symbol} {Wrap(Right!, true)}";
        }
    }

    /// <summary>
    /// 数がleaves個の計算式を作ります。答えが0以上の整数になるよう、引き算は大きい方から引き、割り算は割り切れるときだけ使います。
    /// 掛け算は、左右の値がどちらも1桁のときだけ使います。
    /// </summary>
    static private Expr MakeExpr(int leaves)
    {
        if (leaves <= 1) return new Expr() { Value = RandomInt(1, 21) };

        int leftLeaves = RandomInt(1, leaves);
        var left = MakeExpr(leftLeaves);
        var right = MakeExpr(leaves - leftLeaves);
        char op = "+-*/"[RandomInt(4)];

        if (op == '/' && (right.Value <= 1 || left.Value % right.Value != 0)) op = '*';
        //掛け算は左右とも1桁のときだけ。そうでなければ足し算か引き算にする
        if (op == '*' && (left.Value >= 10 || right.Value >= 10)) op = Random01 < 0.5f ? '+' : '-';
        //答えが負にならないよう、引き算は大きい方から引く
        if (op == '-' && left.Value < right.Value) (left, right) = (right, left);

        int value = op switch
        {
            '+' => left.Value + right.Value,
            '-' => left.Value - right.Value,
            '*' => left.Value * right.Value,
            _ => left.Value / right.Value,
        };
        return new Expr() { Op = op, Left = left, Right = right, Value = value };
    }

    static private string MakeHardProblem(out int answer)
    {
        //括弧を1つ以上含み、答えがテンキーに入る式になるまで作り直す
        for (int i = 0; i < 200; i++)
        {
            var expr = MakeExpr(RandomInt(4, 6));
            string text = expr.ToText();
            if (!text.Contains('(') || expr.Value > 9999) continue;
            answer = expr.Value;
            return text;
        }
        return MakeEasyProblem(out answer);
    }
}
