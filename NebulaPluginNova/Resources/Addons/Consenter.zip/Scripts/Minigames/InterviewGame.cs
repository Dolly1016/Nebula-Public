namespace Consenter;

/// <summary>
/// 面接官の質問に、同意する意思を示すように答えていくミニゲームです。
/// 最初はStandardと全く同じ見た目で、同意するを押すと面接が始まり、同意するは「はい」、同意しないは「いいえ」に変わります。
/// 質問によっては「いいえ」が同意の意思になります。はい・いいえの左右は質問ごとに入れ替わります。5問すべてに正しく答えると同意でき、誤ると失敗します。
/// </summary>
public class InterviewGame : ConsentGame
{
    public override Vector2 DialogSize => StandardDialogSize;
    public override float? IdleTimeout => 15f;
    public override float DialogScale => 1f;

    //質問ごとの、同意する意思を示す答え(trueは「はい」)
    static private readonly bool[] Answers = [true, false, false, true, true, false, true, false, true, false];
    private const int NumOfQuestions = 5;

    private int[] questions = null!;
    private int current = 0;
    private bool started = false;
    private TextMeshPro body = null!;
    private ConsentTitleButton yes = null!;
    private ConsentTitleButton no = null!;

    public override void Begin()
    {
        var order = Enumerable.Range(0, Answers.Length).ToArray();
        Shuffle(order);
        questions = order.Take(NumOfQuestions).ToArray();

        //同意するが「はい」、同意しないが「いいえ」になる
        (body, yes, no) = CreateStandardScreen(
            () => { if (started) Answer(true); else StartInterview(); },
            () => { if (started) Answer(false); else Fail(); });
    }

    private void StartInterview()
    {
        started = true;
        yes.SetLabel(Language.Translate("consenter.minigame.interview.yes"));
        no.SetLabel(Language.Translate("consenter.minigame.interview.no"));
        body.alignment = TextAlignmentOptions.Center;
        body.fontSize = 1.5f;
        ShowQuestion();
    }

    private void ShowQuestion()
    {
        int q = questions[current];
        string progress = Language.Translate("consenter.minigame.interview.progress").Replace("%NUM%", (current + 1).ToString()).Replace("%MAX%", NumOfQuestions.ToString());
        body.text = $"<size=75%><color=#FFF299>{progress}</color></size>\n{Language.Translate("consenter.minigame.interview.q." + q)}";

        bool yesOnLeft = Random01 < 0.5f;
        yes.Transform.localPosition = new(yesOnLeft ? -StandardButtonX : StandardButtonX, StandardButtonY, -0.3f);
        no.Transform.localPosition = new(yesOnLeft ? StandardButtonX : -StandardButtonX, StandardButtonY, -0.3f);
    }

    private void Answer(bool yesAnswered)
    {
        if (yesAnswered != Answers[questions[current]])
        {
            Fail();
            return;
        }
        current++;
        if (current >= NumOfQuestions) Succeed();
        else ShowQuestion();
    }
}
