namespace Consenter;

/// <summary>
/// 同意するを押すたびに、ボタンがすっと動くミニゲームです。決まった回数押すと同意できます。
/// 最初はStandardと全く同じ見た目で、窓もそのままです。ボタンはStandardの窓の中を動きます。
/// 同意するを押すと、同意しないはカーソルがあった位置へ、同意するはそこから離れた別の場所へ動きます。
/// そのため同じ場所を連打すると同意しないを押してしまい、失敗します。
/// </summary>
public class FleeingGame : ConsentGame
{
    public override Vector2 DialogSize => StandardDialogSize;
    public override float? IdleTimeout => 10f;
    public override float DialogScale => 1f;

    private const int RequiredHits = 5;
    //同意するの移動先は、押した位置から少なくともこれだけ離す
    private const float MinDistanceFromCursor = 3f;
    private const float MoveSpeed = 14f;

    private TextMeshPro body = null!;
    private ConsentTitleButton agree = null!;
    private ConsentTitleButton disagree = null!;
    private Vector2 agreeTarget, disagreeTarget;
    private int hits = 0;
    private Rect movable;

    public override void Begin()
    {
        (body, agree, disagree) = CreateStandardScreen(OnHit);
        agreeTarget = agree.Transform.localPosition;
        disagreeTarget = disagree.Transform.localPosition;

        //ボタンが動ける範囲は、Standardの窓の中
        var area = ContentArea;
        var half = agree.Size * 0.5f;
        movable = Rect.MinMaxRect(area.xMin + half.x, area.yMin + half.y, area.xMax - half.x, area.yMax - half.y);
        //同意しないは同意するより手前に重なる
        disagree.Transform.localPosition = new(disagreeTarget.x, disagreeTarget.y, -0.6f);
    }

    private Vector2 Clamp(Vector2 pos) => new(Mathf.Clamp(pos.x, movable.xMin, movable.xMax), Mathf.Clamp(pos.y, movable.yMin, movable.yMax));


    private void OnHit()
    {
        hits++;
        if (hits >= RequiredHits)
        {
            Succeed();
            return;
        }

        var cursor = Clicks.MouseLocal(Root);

        //同意しないは押した位置へ。続けて同じ場所を押すと同意しないを押すことになる
        disagreeTarget = Clamp(cursor);

        //同意するは押した位置から十分離れた場所へ。見つからなければ一番遠い候補にする
        Vector2 best = agreeTarget;
        float bestDistance = -1f;
        for (int i = 0; i < 40; i++)
        {
            var candidate = new Vector2(RandomRange(movable.xMin, movable.xMax), RandomRange(movable.yMin, movable.yMax));
            float distance = Math.Min((candidate - cursor).magnitude, (candidate - disagreeTarget).magnitude);
            if (distance >= MinDistanceFromCursor)
            {
                best = candidate;
                break;
            }
            if (distance > bestDistance)
            {
                best = candidate;
                bestDistance = distance;
            }
        }
        agreeTarget = best;
    }

    public override void Update()
    {
        Vector2 Move(Vector2 current, Vector2 target) => Vector2.Lerp(current, target, Mathf.Clamp01(Time.deltaTime * MoveSpeed));
        var a = Move(agree.Transform.localPosition, agreeTarget);
        var d = Move(disagree.Transform.localPosition, disagreeTarget);
        agree.Transform.localPosition = new(a.x, a.y, -0.3f);
        disagree.Transform.localPosition = new(d.x, d.y, -0.6f);
    }
}
