namespace Consenter;

/// <summary>
/// 規約の本文と、同意する・同意しないのボタンだけのミニゲームです(Standard / InvColor)。
/// ボタンの左右は開くたびに入れ替わります。InvColorでは、ボタンの色が必ず入れ替わります(同意するが赤、同意しないが緑)。
/// </summary>
public class StandardGame : ConsentGame
{
    private readonly bool invertColor;
    public StandardGame(bool invertColor) { this.invertColor = invertColor; }

    public override Vector2 DialogSize => StandardDialogSize;
    //この大きさは指定されたものなので縮めない
    public override float DialogScale => 1f;

    public override void Begin()
    {
        var (_, agree, disagree) = CreateStandardScreen(Succeed);
        if (invertColor)
        {
            agree.SetStyle(ConsentButtonStyle.Disagree);
            disagree.SetStyle(ConsentButtonStyle.Agree);
        }
    }
}
