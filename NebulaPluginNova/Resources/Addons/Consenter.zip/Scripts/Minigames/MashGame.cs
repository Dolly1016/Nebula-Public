namespace Consenter;

/// <summary>
/// 同意するを連打して、読み込みのゲージを満タンにするミニゲームです。ゲージは何もしないと少しずつ減っていきます。
/// ゲージが途中まで溜まると、同意すると同意しないのボタンが弧を描いて入れ替わります。同じ場所を連打していると、同意しないを押してしまい失敗します。
/// ボタンはSortingGroupでまとめてあるので、入れ替わりで重なっても部品が入り混じって描かれません。
/// 読み込みのゲージは、ダウンロードのタスク(UploadDataGame)のゲージを流用します。見つからないときは簡易なゲージで代わりにします。
/// </summary>
public class MashGame : ConsentGame
{
    public override Vector2 DialogSize => new(6.4f, 3.6f);
    public override string? InstructionKey => GeneralInstructionKey;
    public override float? IdleTimeout => 10f;

    private const float FillPerClick = 0.045f;
    private const float DecayPerSecond = 0.12f;
    //ゲージがこの量を超えたときに、ボタンが入れ替わる
    static private readonly float[] SwapThresholds = [0.35f, 0.7f];
    private const float SwapDuration = 0.35f;
    private const float ButtonX = 1.4f;
    private const float ButtonWidth = 2.1f;

    private float gauge = 0f;
    private int nextSwap = 0;
    private SpriteRenderer? gaugeFill = null;
    //ダウンロードのタスクのゲージ
    private HorizontalGauge? vanillaGauge = null;
    //NoSが読み込んでいるPolusのLongTasksのうち、ダウンロードのタスク(UploadDataGame)の位置
    private const int PolusMapId = 2;
    private const int DownloadLongTaskIndex = 0;
    private float gaugeWidth;
    private Vector2 gaugeLeft;
    private TextMeshPro loadingText = null!;
    private TextMeshPro percentText = null!;
    private ConsentTitleButton agree = null!;
    private ConsentTitleButton disagree = null!;
    private float buttonY;
    private bool agreeOnLeft;
    //入れ替わりの進み具合。入れ替わっていなければ負
    private float swapProgress = -1f;

    public override void Begin()
    {
        var area = ContentArea;
        gaugeWidth = area.width - 0.6f;
        float gaugeY = area.yMax - 0.75f;
        gaugeLeft = new(-gaugeWidth * 0.5f, gaugeY);
        vanillaGauge = CreateVanillaGauge(new(0f, gaugeY, -0.06f), gaugeWidth);
        if (vanillaGauge == null)
        {
            ConsentUI.Sliced(Root, "GaugeFrame", new(0f, gaugeY, -0.05f), ConsentAssets.RoundRect, new(gaugeWidth + 0.12f, 0.36f), new(0.4f, 0.4f, 0.45f));
            ConsentUI.Box(Root, "GaugeBack", new(0f, gaugeY, -0.06f), new(gaugeWidth, 0.24f), new(0.18f, 0.18f, 0.2f));
            gaugeFill = ConsentUI.Box(Root, "GaugeFill", new(gaugeLeft.x, gaugeY, -0.07f), new(0.001f, 0.24f), ConsentAssets.AgreeColor);
        }
        //文字の長さが変わると表示がずれるので、「Now Loading...」は固定し、割合は右寄せの別の文字にする
        loadingText = AddText(new(0f, gaugeY + 0.38f, -0.5f), new(gaugeWidth, 0.35f), 1.6f, "Now Loading...", new(0.9f, 0.9f, 0.9f), TextAlignmentOptions.Left);
        percentText = AddText(new(0f, gaugeY + 0.38f, -0.5f), new(gaugeWidth, 0.35f), 1.6f, "", new(0.9f, 0.9f, 0.9f), TextAlignmentOptions.Right);

        buttonY = area.yMin + 0.45f;
        agreeOnLeft = Random01 < 0.5f;
        agree = AddAgreeButton(new(agreeOnLeft ? -ButtonX : ButtonX, buttonY), ButtonWidth, OnMash);
        disagree = AddDisagreeButton(new(agreeOnLeft ? ButtonX : -ButtonX, buttonY), ButtonWidth);
        //入れ替わりで重なっても、ボタンの部品が入り混じらないようにまとめる
        ConsentUI.ApplySortingGroup(agree.GameObject);
        ConsentUI.ApplySortingGroup(disagree.GameObject);
        ApplyGauge();
    }

    private void OnMash()
    {
        gauge = Math.Min(1f, gauge + FillPerClick);
        ApplyGauge();
        if (gauge >= 1f) FinishAfter(true);
    }

    /// <summary>
    /// ダウンロードのタスクのゲージを複製し、幅に合わせて置きます。見つからなければnullを返します。
    /// </summary>
    private HorizontalGauge? CreateVanillaGauge(Vector3 center, float width)
    {
        var polus = VanillaAsset.MapAsset[PolusMapId];
        if (!polus || polus.LongTasks.Length <= DownloadLongTaskIndex) return null;
        var download = polus.LongTasks[DownloadLongTaskIndex].MinigamePrefab?.TryCast<UploadDataGame>();
        if (download == null || !download.Gauge) return null;

        var gauge = GameObject.Instantiate(download.Gauge, Root);
        gauge.transform.localPosition = Vector3.zero;
        gauge.transform.localScale = Vector3.one;
        gauge.transform.localRotation = Quaternion.identity;
        foreach (var t in gauge.GetComponentsInChildren<Transform>(true)) t.gameObject.layer = ConsentUI.UILayer;
        gauge.MaxValue = 1f;
        gauge.Value = 0f;

        //ゲージの絵の幅に合わせて縮め、中心を合わせる
        var renderers = gauge.GetComponentsInChildren<SpriteRenderer>(true);
        if (renderers.Length > 0)
        {
            var bounds = renderers[0].bounds;
            foreach (var r in renderers) bounds.Encapsulate(r.bounds);
            Vector3 localSize = Root.InverseTransformVector(bounds.size);
            float scale = width / Math.Max(Mathf.Abs(localSize.x), 0.01f);
            Vector3 offset = Root.InverseTransformVector(gauge.transform.position - bounds.center);
            gauge.transform.localScale = new(scale, scale, 1f);
            gauge.transform.localPosition = new(center.x + offset.x * scale, center.y + offset.y * scale, center.z);
        }
        else gauge.transform.localPosition = center;
        return gauge;
    }

    private void ApplyGauge()
    {
        if (vanillaGauge)
        {
            vanillaGauge!.Value = gauge;
            return;
        }
        if (!gaugeFill) return;
        float width = Math.Max(0.001f, gaugeWidth * gauge);
        gaugeFill!.transform.localScale = new(width / 0.16f, 0.24f / 0.16f, 1f);
        gaugeFill.transform.localPosition = new(gaugeLeft.x + width * 0.5f, gaugeLeft.y, -0.07f);
    }

    public override void Update()
    {
        percentText.text = $"{(int)(gauge * 100f)}%";

        if (IsFinishing) return;

        //何もしないと少しずつ減る
        gauge = Math.Max(0f, gauge - DecayPerSecond * Time.deltaTime);
        ApplyGauge();

        //一定まで溜まったら、ボタンを入れ替える
        if (swapProgress < 0f && nextSwap < SwapThresholds.Length && gauge >= SwapThresholds[nextSwap])
        {
            nextSwap++;
            swapProgress = 0f;
        }
        if (swapProgress >= 0f)
        {
            swapProgress += Time.deltaTime / SwapDuration;
            float t = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(swapProgress));
            float from = agreeOnLeft ? -ButtonX : ButtonX;
            float arc = Mathf.Sin(t * Mathf.PI) * 0.5f;
            //同意するは上を、同意しないは下を通って入れ替わる。同意しないを手前に描く
            agree.Transform.localPosition = new(Mathf.Lerp(from, -from, t), buttonY + arc, -0.3f);
            disagree.Transform.localPosition = new(Mathf.Lerp(-from, from, t), buttonY - arc, -0.6f);
            if (swapProgress >= 1f)
            {
                agreeOnLeft = !agreeOnLeft;
                swapProgress = -1f;
            }
        }
    }
}
