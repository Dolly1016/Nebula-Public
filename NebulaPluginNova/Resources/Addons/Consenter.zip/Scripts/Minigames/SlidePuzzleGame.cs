namespace Consenter;

/// <summary>
/// 縦長にした「同」「意」を横に並べた正方形の画像を、正方形の3×3のピースに分けたスライドパズルを解いてから同意するミニゲームです。右下のピースが抜けた状態で始まります。
/// 空いたマスの隣のピースを押すと、そのピースが空いたマスへ動きます。パズルが完成すると、抜けていたピースがはまって同意できます。
/// 同意するボタンはありません。同意しないを押すと失敗します。
/// 最初はStandardと同じ画面で、同意するを押すと、同意するボタンが盤の真ん中へ動き、ブルブルと震えてから8つのピースになって散らばります。
/// </summary>
public class SlidePuzzleGame : ConsentGame
{
    public override Vector2 DialogSize => new(4.2f, 4.9f);
    public override bool UsesStandardIntro => true;
    //震える時間
    private const float ShakeDuration = 0.7f;
    //パズルは考える時間がかかるので長めにする
    public override float? IdleTimeout => 70f;
    public override string? InstructionKey => GeneralInstructionKey;

    private const int Size = 3;
    //ピースは正方形
    private const float PieceSize = 1f;
    private const float Gap = 0.04f;
    private static readonly Vector2 Pitch = new(PieceSize + Gap, PieceSize + Gap);

    //cells[マス] = そこにあるピースの番号。空きは-1
    private readonly int[] cells = new int[Size * Size];
    private readonly Transform[] pieces = new Transform[Size * Size];
    private Vector2 center;
    private bool completed = false;
    //導入の同意するボタンの、縮尺1の窓での最初の位置と大きさ
    private Vector3 introFromPos, introFromScale;
    private bool introRecorded = false;

    /// <summary>
    /// 盤の真ん中の位置です。
    /// </summary>
    private Vector2 BoardCenter(Rect area)
    {
        float boardHeight = Pitch.y * Size + 0.06f;
        return new(0f, area.yMax - boardHeight * 0.5f - 0.02f);
    }

    protected override void IntroGrow(float t, ConsentTitleButton agree, ConsentTitleButton disagree, TextMeshPro body)
    {
        if (body) body.alpha = 1f - t;
        if (disagree.GameObject) ConsentUI.SetAlpha(disagree.GameObject, 1f - t);
        if (!introRecorded)
        {
            //窓の縮尺は1から始まるので、今の位置と大きさがそのまま縮尺1での値になる
            introRecorded = true;
            introFromPos = agree.Transform.localPosition;
            introFromScale = agree.Transform.localScale;
        }
        //同意するボタンを、本番の盤の真ん中へ動かす
        var boardCenter = BoardCenter(MainContentArea);
        PlaceInScaledRoot(agree.Transform, introFromPos, new Vector3(boardCenter.x, boardCenter.y, -0.3f) * DialogScale, introFromScale, introFromScale * DialogScale, t);
    }

    protected override bool IntroHold(float time, ConsentTitleButton agree)
    {
        //だんだん強くブルブルと震える
        var boardCenter = BoardCenter(MainContentArea);
        float amplitude = Mathf.Lerp(0.02f, 0.09f, Mathf.Clamp01(time / ShakeDuration));
        agree.Transform.localPosition = new(boardCenter.x + RandomRange(-amplitude, amplitude), boardCenter.y + RandomRange(-amplitude, amplitude), -0.3f);
        return time >= ShakeDuration;
    }

    private bool Solved
    {
        get
        {
            for (int i = 0; i < Size * Size - 1; i++) if (cells[i] != i) return false;
            return true;
        }
    }

    private Vector3 CellPosition(int cell) => new(center.x + (cell % Size - 1) * Pitch.x, center.y - (cell / Size - 1) * Pitch.y, -0.2f);

    public override void Begin()
    {
        var area = ContentArea;
        //パズルは上に寄せ、その下に同意しないボタンを置く
        center = BoardCenter(area);
        ConsentUI.Box(Root, "Board", new(center.x, center.y, -0.1f), new(Pitch.x * Size + 0.06f, Pitch.y * Size + 0.06f), new(0f, 0f, 0f, 0.35f));

        for (int i = 0; i < cells.Length; i++) cells[i] = i < cells.Length - 1 ? i : -1;

        //空きマスを何度も動かして混ぜる。直前の動きを戻すことはしない
        int blank = cells.Length - 1, previous = -1;
        do
        {
            for (int i = 0; i < 80; i++)
            {
                var neighbors = Neighbors(blank).Where(n => n != previous).ToArray();
                int next = neighbors[RandomInt(neighbors.Length)];
                cells[blank] = cells[next];
                cells[next] = -1;
                previous = blank;
                blank = next;
            }
        } while (Solved);

        for (int cell = 0; cell < cells.Length; cell++)
        {
            int piece = cells[cell];
            if (piece < 0) continue;
            var renderer = ConsentUI.Sprite(Root, "Piece", CellPosition(cell), ConsentAssets.SlidePuzzle.GetSprite(piece), null, PieceSize);
            pieces[piece] = renderer.transform;
            int p = piece;
            Clicks.Add(renderer.transform, new Vector2(1f, 1f), () => Slide(p));
        }

        //右下のピースは、解けたときにはめる
        var last = ConsentUI.Sprite(Root, "Piece", CellPosition(cells.Length - 1), ConsentAssets.SlidePuzzle.GetSprite(cells.Length - 1), null, PieceSize);
        last.gameObject.SetActive(false);
        pieces[cells.Length - 1] = last.transform;

        AddDisagreeButton(new(0f, area.yMin + 0.3f), 2.2f);

        //導入の後は、ピースを盤の真ん中から散らばらせる。ピースは毎フレーム自分のマスへ近づいていく
        if (PlayedIntro)
        {
            foreach (var piece in pieces)
                if (piece && piece.gameObject.activeSelf) piece.localPosition = new(center.x, center.y, -0.2f);
        }
    }

    private IEnumerable<int> Neighbors(int cell)
    {
        int x = cell % Size, y = cell / Size;
        if (x > 0) yield return cell - 1;
        if (x < Size - 1) yield return cell + 1;
        if (y > 0) yield return cell - Size;
        if (y < Size - 1) yield return cell + Size;
    }

    private void Slide(int piece)
    {
        if (completed) return;
        int cell = Array.IndexOf(cells, piece);
        int blank = Array.IndexOf(cells, -1);
        if (!Neighbors(cell).Contains(blank)) return;
        cells[blank] = piece;
        cells[cell] = -1;

        if (Solved)
        {
            //抜けていたピースがはまり、完成したことが分かるようにしてから同意する
            completed = true;
            var last = pieces[cells.Length - 1];
            last.gameObject.SetActive(true);
            last.localScale = Vector3.one * PieceSize * 1.6f;
            ConsentUI.SetAlpha(last.gameObject, 0f);
            FinishAfter(true);
        }
    }

    public override void Update()
    {
        if (completed)
        {
            var last = pieces[cells.Length - 1];
            last.localScale = Vector3.Lerp(last.localScale, Vector3.one * PieceSize, Time.deltaTime * 10f);
            var renderer = last.GetComponent<SpriteRenderer>();
            ConsentUI.SetAlpha(last.gameObject, Mathf.MoveTowards(renderer.color.a, 1f, Time.deltaTime * 4f));
        }

        for (int cell = 0; cell < cells.Length; cell++)
        {
            int piece = cells[cell];
            if (piece < 0 || !pieces[piece]) continue;
            pieces[piece].localPosition = Vector3.Lerp(pieces[piece].localPosition, CellPosition(cell), Time.deltaTime * 18f);
        }
    }
}
