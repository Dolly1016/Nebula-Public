using System;
using System.Collections.Generic;
using System.Linq;
using Nebula;
using Nebula.Behavior;
using Nebula.Game;
using Nebula.Modules;
using Nebula.Modules.ScriptComponents;
using Nebula.Utilities;
using UnityEngine;
using Virial;
using Virial.Assignable;
using Virial.Attributes;
using Virial.Configuration;
using Virial.Events.Game;
using Virial.Events.Game.Meeting;
using Virial.Events.Game.Minimap;
using Virial.Events.Player;
using Virial.Game;
using Virial.Media;
using GamePlayer = Virial.Game.Player;

namespace Consenter;

/// <summary>
/// 利用規約に同意し続ける限りタスクを進められるクルーメイトです。
/// マップの端末からランダムに選ばれた1つで利用規約に同意すると、タスクが1つ進みます。
/// 同意に失敗すると進捗はゼロに戻り、別の端末で同意し直すことになります。
/// ノルマを達成した後も、最大同意可能回数の分だけ追加で同意できます。追加の同意を新しく受け取れるのは生きている間だけで、死ぬ前に受け取っていた分には死んだ後も取り組めます。
/// 死んだ後も、ノルマを達成するまでは同意を続けられます。その間に同意に失敗したときも、同意する端末は選び直されます。
/// </summary>
public class Consenter : DefinedRoleTemplate, DefinedRole, IAssignableDocument
{
    private Consenter() : base("consenter", new(120, 178, 226), RoleCategory.CrewmateRole, Nebula.Roles.Crewmate.Crewmate.MyTeam,
        [NumOfTasksOption, NumOfExtraConsentsOption, TaskAdvertisementDurationOption, RandomAdvertisementDurationOption])
    {
        Advertisement.Initialize();
    }

    RuntimeRole RuntimeAssignableGenerator<RuntimeRole>.CreateInstance(GamePlayer player, int[] arguments) => new Instance(player);

    static internal readonly IntegerConfiguration NumOfTasksOption = NebulaAPI.Configurations.Configuration("options.role.consenter.numOfTasks", (1, 15), 8);
    static internal readonly IntegerConfiguration NumOfExtraConsentsOption = NebulaAPI.Configurations.Configuration("options.role.consenter.numOfExtraConsents", (0, 10), 5, decorator: num => "+" + num);
    /// <summary>同意のミニゲーム(ScrollCheck)で受けるアドバータイズメントの効果時間です。</summary>
    static internal readonly FloatConfiguration TaskAdvertisementDurationOption = NebulaAPI.Configurations.Configuration("options.role.consenter.taskAdvertisementDuration", (30f, 300f, 15f), 180f, FloatConfigurationDecorator.Second);
    /// <summary>会議の開始時とタスクフェイズの再開時に、確率で受けるアドバータイズメントの効果時間です。</summary>
    static internal readonly FloatConfiguration RandomAdvertisementDurationOption = NebulaAPI.Configurations.Configuration("options.role.consenter.randomAdvertisementDuration", (30f, 300f, 15f), 60f, FloatConfigurationDecorator.Second);

    static public readonly Consenter MyRole = new();

    IEnumerable<AssignableDocumentReplacement> IAssignableDocument.GetDocumentReplacements()
    {
        yield return new("%EXTRA%", NumOfExtraConsentsOption.GetValue().ToString());
    }

    /// <summary>
    /// 自身が同意者で生存していれば、その役職を返します。
    /// </summary>
    //死んだ後も、ノルマを達成するまでは同意を続けられる
    static public Instance? LocalConsenter => GamePlayer.LocalPlayer?.Role is Instance consenter ? consenter : null;

    /// <summary>
    /// 同意に使える端末(サボタージュの修理用を除く、絵のある端末)をすべて返します。
    /// </summary>
    static public Console[] GetConsentConsoles()
    {
        if (!ShipStatus.Instance) return [];
        return ShipStatus.Instance.AllConsoles
            .Where(c => c && c.Image && c.gameObject.activeInHierarchy && c.TaskTypes != null && c.TaskTypes.Length > 0 && !c.TaskTypes.Any(t => SabotageTaskTypes.Contains(t)))
            .ToArray();
    }

    //同意に使わない、サボタージュの修理用の端末
    static private readonly TaskTypes[] SabotageTaskTypes = [TaskTypes.ResetReactor, TaskTypes.FixLights, TaskTypes.FixComms, TaskTypes.RestoreOxy, TaskTypes.ResetSeismic, TaskTypes.StopCharles, TaskTypes.MushroomMixupSabotage];

    public class Instance : RuntimeAssignableTemplate, RuntimeRole
    {
        DefinedRole RuntimeRole.Role => MyRole;
        RoleTaskType RuntimeRole.TaskType => RoleTaskType.SpecialCrewmateTask;

        public Instance(GamePlayer player) : base(player) { }

        private int consents = 0;
        /// <summary>
        /// 失敗せずに続けて同意できた回数です。
        /// </summary>
        public int Consents => consents;
        /// <summary>
        /// タスクノルマとして同意すべき回数です。
        /// </summary>
        public int Quota => NumOfTasksOption;
        /// <summary>
        /// 答えを出さずに閉じたミニゲームの種類と状態です。次に開いたとき、同じ種類を同じ状態から再開します。
        /// </summary>
        public (ConsentMinigameType type, object state)? SuspendedGame { get; set; } = null;

        /// <summary>
        /// 次に取り組むミニゲームの種類です。進捗が変わったとき(同意できたか、失敗したとき)に決め、それまでは開き直しても変わりません。
        /// </summary>
        public ConsentMinigameType NextType { get; private set; } = ConsentMinigameType.Standard;
        private bool nextTypeDecided = false;

        /// <summary>
        /// いまの進捗に合わせて、次に取り組むミニゲームの種類を決め直します。
        /// </summary>
        //進捗が0に戻ってから選ばれた種類。進捗が0に戻るまでは、同じ種類を選ばない
        private readonly HashSet<ConsentMinigameType> usedTypes = [];

        private void DecideNextType()
        {
            NextType = ConsentMinigameTypes.ChooseType(consents, Quota > 0 ? consents * 100f / Quota : 100f, usedTypes);
            usedTypes.Add(NextType);
            nextTypeDecided = true;
        }

        /// <summary>
        /// 次に取り組むミニゲームの種類を返します。まだ決まっていなければ決めます。
        /// </summary>
        public ConsentMinigameType GetNextType()
        {
            if (!nextTypeDecided) DecideNextType();
            return NextType;
        }
        private int MaxConsents => NumOfTasksOption + NumOfExtraConsentsOption;
        private bool CanConsentMore => consents < MaxConsents;
        //新しい同意を受け取れるかどうか。追加の同意を受け取れるのは生きている間だけで、死んだ後はノルマまで
        private bool CanReceiveNewConsent => consents < (MyPlayer.IsDead ? Quota : MaxConsents);

        //同意する端末と、その端末に重ねた同意用の当たり判定
        private Console? targetConsole = null;
        private GameObject? consentPoint = null;
        //ミニマップ上で同意する端末を示すタスクマーク
        private PooledMapIcon? mapIcon = null;
        //マップ中を歩き回っている同意ボタン
        private RoamingConsent? roaming = null;
        private bool IsRoaming => roaming != null && roaming.IsAlive;
        //同意ボタンが逃げ込んだ端末を探している間
        private HideoutConsent? hideout = null;
        //歩き回るボタンや逃げ込んだボタンを放つ前の、元の同意する端末。会議で片付けたときはこの端末に戻す
        private Console? pausedConsole = null;
        private bool IsHiding => hideout != null && hideout.IsAlive;

        private void UpdateTaskProgress() => MyPlayer.Tasks.Custom(consents, Quota, true);

        void RuntimeAssignable.OnActivated()
        {
            if (!AmOwner) return;

            UpdateTaskProgress();
            AssignNewConsole();
        }

        [Local]
        void OnGameStart(GameStartEvent ev)
        {
            UpdateTaskProgress();
            if (!targetConsole) AssignNewConsole();
        }

        /// <summary>
        /// 同意する端末を、マップの端末からランダムに選び直します。直前の端末は、ほかに候補があれば選びません。
        /// </summary>
        private void AssignNewConsole()
        {
            var last = targetConsole;
            ClearConsole();
            if (!CanReceiveNewConsent || !ShipStatus.Instance) return;

            var candidates = GetConsentConsoles();
            if (candidates.Length == 0) return;
            if (candidates.Length > 1 && last) candidates = candidates.Where(c => c.GetInstanceID() != last!.GetInstanceID()).ToArray();

            AssignConsole(candidates[System.Random.Shared.Next(candidates.Length)]);
        }

        /// <summary>
        /// 指定した端末を、同意する端末にします。
        /// </summary>
        private void AssignConsole(Console target)
        {
            ClearConsole();
            if (!CanConsentMore || !target) return;
            targetConsole = target;

            //端末の絵に重ねて、自分だけが使える当たり判定を置く。輪郭は端末の絵に付ける
            var image = targetConsole.Image;
            consentPoint = UnityHelper.CreateObject("ConsentPoint", image.transform, Vector3.zero);
            var console = consentPoint.AddComponent<CustomConsole>();
            console.Renderer = image;
            console.Property = new()
            {
                CanUse = _ => LocalConsenter == this && MyPlayer.CanMove,
                Use = CustomConsoleProperty.MinigameAction<ConsentMinigame>(null!, (minigame, _) => minigame.SetUp(this)),
                OutlineColor = MyRole.UnityColor,
                UsableDistance = Math.Max(targetConsole.usableDistance, 0.8f),
            };
            UpdateMapIcon();
        }

        private void ClearConsole()
        {
            if (mapIcon) mapIcon!.gameObject.SetActive(false);
            if (consentPoint) GameObject.Destroy(consentPoint);
            if (targetConsole && targetConsole!.Image) targetConsole.Image.material.SetFloat("_Outline", 0f);
            consentPoint = null;
            targetConsole = null;
        }

        /// <summary>
        /// 利用規約に同意できたときに呼び出します。タスクが1つ進み、次の端末が選ばれます。
        /// </summary>
        public void OnConsented()
        {
            SuspendedGame = null;
            if (!CanConsentMore) return;
            consents++;
            DecideNextType();
            UpdateTaskProgress();
            //「タスク完了」の代わりに「同意」と出す
            ConsentNotice.ShowResult(true);
            AssignNewConsole();
        }

        /// <summary>
        /// 利用規約への同意に失敗したときに呼び出します。進捗はゼロに戻り、同意する端末が選び直されます。
        /// </summary>
        public void OnFailedToConsent()
        {
            SuspendedGame = null;
            consents = 0;
            usedTypes.Clear();
            DecideNextType();
            UpdateTaskProgress();
            //画面を赤く光らせ、間違えたときの音と一緒に「不同意」と出す
            ConsentNotice.ShowResult(false);
            AssignNewConsole();
        }

        /// <summary>
        /// ミニマップに、同意する端末の位置をバニラのタスクと同じマークで示します。
        /// マークはタスクの表示(MapTaskOverlay)の下に置くので、アドミンでは表示されません。
        /// </summary>
        [Local]
        void OnOpenNormalMap(MapOpenNormalEvent ev)
        {
            UpdateMapIcon();
            if (IsHiding) hideout!.UpdateMapIcons();
        }

        private void UpdateMapIcon()
        {
            if (!MapBehaviour.Instance || !ShipStatus.Instance) return;

            if (!mapIcon)
            {
                var overlay = MapBehaviour.Instance.taskOverlay;
                mapIcon = GameObject.Instantiate(overlay.icons.Prefab.GetComponent<PooledMapIcon>(), overlay.transform);
                mapIcon.name = "ConsenterTask";
                mapIcon.rend.color = UnityEngine.Color.yellow;
                mapIcon.alphaPulse.enabled = false;
                mapIcon.transform.localScale = new(mapIcon.NormalSize, mapIcon.NormalSize, mapIcon.NormalSize);
                this.BindGameObject(mapIcon.gameObject);
            }

            bool show = targetConsole;
            mapIcon!.gameObject.SetActive(show);
            if (show)
            {
                Vector3 localPos = (Vector2)targetConsole!.transform.position / ShipStatus.Instance.MapScale;
                localPos.z = -1f;
                mapIcon.transform.localPosition = localPos;
            }
        }

        /// <summary>
        /// マップ中を歩き回る同意ボタンを放ちます。押されるまで、同意する端末は無くなります。
        /// </summary>
        public void StartRoaming()
        {
            if (targetConsole) pausedConsole = targetConsole;
            ClearConsole();
            roaming?.Dispose();
            roaming = RoamingConsent.Start(this);
        }

        /// <summary>
        /// 歩き回る同意ボタンが押されたときに呼び出されます。
        /// </summary>
        public void OnRoamingResolved(bool agreed)
        {
            roaming = null;
            pausedConsole = null;
            if (agreed) OnConsented();
            else OnFailedToConsent();
        }

        /// <summary>
        /// 同意ボタンをマップのどこかの端末に逃げ込ませます。見つけるまで、同意する端末は無くなります。
        /// </summary>
        public void StartHideout()
        {
            var exclude = targetConsole;
            if (targetConsole) pausedConsole = targetConsole;
            ClearConsole();
            hideout?.Dispose();
            hideout = HideoutConsent.Start(this, exclude);
        }

        /// <summary>
        /// 逃げ込んだ同意ボタンを見つけたか、見つけられずに終わったときに呼び出されます。
        /// </summary>
        public void OnHideoutResolved(bool agreed)
        {
            hideout = null;
            pausedConsole = null;
            if (agreed) OnConsented();
            else OnFailedToConsent();
        }

        //会議が始まったら歩き回る同意ボタンや逃げ込んだ同意ボタンは片付け、元の同意する端末に戻す。端末は選び直さない
        //生きて会議に入るときと、会議の後にタスクフェイズが再開するときに、広告が表示される旨のお知らせが出る確率
        //外れるたびに次の確率が上がり、お知らせが出たら最初の確率に戻る
        private const float AdvertisementNoticeBaseChance = 0.25f;
        private const float AdvertisementNoticeChanceStep = 0.05f;
        private float advertisementNoticeChance = AdvertisementNoticeBaseChance;

        private void TryScheduleAdvertisementNotice(string translationKey)
        {
            if (MyPlayer.IsDead) return;
            if (UnityEngine.Random.value >= advertisementNoticeChance)
            {
                advertisementNoticeChance = Math.Min(1f, advertisementNoticeChance + AdvertisementNoticeChanceStep);
                return;
            }
            advertisementNoticeChance = AdvertisementNoticeBaseChance;
            Advertisement.ScheduleNotice(translationKey);
        }

        [Local]
        void OnTaskPhaseRestart(TaskPhaseRestartEvent ev) => TryScheduleAdvertisementNotice("consenter.advertisement.notice.task");

        [Local]
        void OnMeetingStart(MeetingStartEvent ev)
        {
            TryScheduleAdvertisementNotice("consenter.advertisement.notice.meeting");
            if (roaming == null && hideout == null) return;
            roaming?.Dispose();
            roaming = null;
            hideout?.Dispose();
            hideout = null;
            if (pausedConsole) AssignConsole(pausedConsole!);
            else AssignNewConsole();
            pausedConsole = null;
        }

        [Local]
        void OnUpdateTaskText(PlayerTaskTextLocalEvent ev)
        {
            var text = Language.Translate("consenter.task").Replace("%NUM%", consents.ToString()).Replace("%MAX%", Quota.ToString());
            //バニラのタスクと同じく、1つ以上同意していれば黄色、ノルマ以上同意していれば緑色にする
            if (consents >= Quota) text = "<color=#00DD00FF>" + text + "</color>";
            else if (consents > 0) text = "<color=#FFFF00FF>" + text + "</color>";
            if (IsRoaming)
                text += "\n" + Language.Translate("consenter.task.roaming");
            else if (IsHiding)
                text += "\n" + Language.Translate("consenter.task.hideout").Replace("%NUM%", hideout!.Remaining.ToString()).Replace("%MAX%", HideoutConsent.MaxAttempts.ToString());
            else if (targetConsole)
                text += "\n" + Language.Translate(consents >= Quota ? "consenter.task.extra" : "consenter.task.consent").Replace("%ROOM%", AmongUsUtil.ToDisplayString(targetConsole!.Room));
            else if (!CanReceiveNewConsent)
                text += "\n" + Language.Translate("consenter.task.done");
            ev.ReplaceBody(text);
        }

        void IGameOperator.OnReleased()
        {
            if (AmOwner)
            {
                ClearConsole();
                roaming?.Dispose();
                roaming = null;
                hideout?.Dispose();
                hideout = null;
            }
        }
    }
}
