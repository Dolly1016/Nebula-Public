using System;
using System.Linq;

namespace Consenter;

/// <summary>
/// 同意のミニゲームの種類です。
/// </summary>
public enum ConsentMinigameType
{
    /// <summary>同意するボタンが左右どちらかに出ます。色は同意するが緑、同意しないが赤で固定です。</summary>
    Standard,
    /// <summary>Standardの色を必ず入れ替えたものです。同意するが赤、同意しないが緑になります。</summary>
    InvColor,
    /// <summary>ピンに引っかかりながら落ちてくる文字を、空のボタンで受け止めて集めます。</summary>
    FallingPins,
    /// <summary>スクロールする規約の中のチェックをすべて入れないと同意できません。</summary>
    ScrollCheck,
    /// <summary>押すと隣のチェックも切り替わるチェックボックスを、すべてチェックします。</summary>
    LightsOut,
    /// <summary>斜めにずらっと並んだポップアップを閉じていき、同意するを探します。</summary>
    Popups,
    /// <summary>押すたびに同意するは別の場所へ、同意しないは押した場所へ動きます。</summary>
    Fleeing,
    /// <summary>広いボタンの格子の中から同意するを探します。</summary>
    GridSearch,
    /// <summary>影絵の中からインポスターかクルーメイトをすべて選びます。</summary>
    Silhouette,
    /// <summary>面接官の質問に答えます。</summary>
    Interview,
    /// <summary>2～3個の数の簡単な計算を解きます。</summary>
    ArithmeticEasy,
    /// <summary>4～5個の数で、括弧や割り算も使う計算を解きます。</summary>
    ArithmeticHard,
    /// <summary>横向きにループして流れるボタンの中から同意するを押します。</summary>
    Conveyor,
    /// <summary>「同意」の画像のスライドパズルを解きます。</summary>
    SlidePuzzle,
    /// <summary>スクロールしないと全体が見えないあみだくじで、同意するを引き当てます。</summary>
    Amidakuji,
    /// <summary>飛び回る同意するに、飛ぶのに時間のかかる弾を当てます。</summary>
    Raycast,
    /// <summary>4枚のカードのシャッフルから同意するを当てます。</summary>
    ShuffleEasy,
    /// <summary>8枚のカードの速いシャッフルから同意するを当てます。</summary>
    ShuffleHard,
    /// <summary>同意した後、「同意への迷い」を撃って倒します。</summary>
    ShootingHesitation,
    /// <summary>同意した後、処理のゲージが溜まるまで弾を避け続けます。</summary>
    ShootingEndurance,
    /// <summary>向きと強さを決めて同意するを撃ち出し、壁の穴に通します。</summary>
    HoleShot,
    /// <summary>同意ボタンと8個の同意しないボタンが放たれ、マップ中を歩き回ります。</summary>
    Roaming,
    /// <summary>同意ボタンがマップの16個の端末のどれかに逃げ込みます。5回以内に見つけます。</summary>
    Hideout,
    /// <summary>ボタンが偽物のカバーを被っていて、カーソルを合わせると本当の文字が現れます。</summary>
    FakeCover,
    /// <summary>スロットで、横一列に同意するを揃えます。同意しないが揃うと失敗します。</summary>
    Slot,
    /// <summary>同意するを連打して読み込みのゲージを満タンにします。途中でボタンが入れ替わります。</summary>
    Mash,
    Telescope,
    /// <summary>同意するボタンが変形したカードを、ちょうどよい速さでスワイプします。</summary>
    SwipeCard,
}

/// <summary>
/// 種類ごとの出現の重みと、中身の作り方です。
/// </summary>
static public class ConsentMinigameTypes
{
    static private float When(bool condition, float weight = 1f) => condition ? weight : 0f;

    /// <summary>
    /// 種類ごとの出現の重みです。引数は、失敗せずに続けて同意できた回数と、ノルマに対する達成率(%)です。
    /// 達成率は追加の同意では100%を上回ります。重みが0以下の種類は出現しません。
    /// </summary>
    static private readonly Func<int, float, (ConsentMinigameType type, float weight)>[] TypeWeights = [
        //最初の1回だけ
        (completed, percentage) => (ConsentMinigameType.Standard, When(completed == 0, 2f)),
        //いつでも
        (completed, percentage) => (ConsentMinigameType.InvColor, 1f),
        (completed, percentage) => (ConsentMinigameType.ScrollCheck, When(completed > 0)),
        (completed, percentage) => (ConsentMinigameType.Interview, When(completed > 0)),
        (completed, percentage) => (ConsentMinigameType.ArithmeticEasy, When(completed > 0 && percentage < 40f)),
        (completed, percentage) => (ConsentMinigameType.Popups, When(completed > 0)),
        (completed, percentage) => (ConsentMinigameType.Fleeing, When(completed > 0)),
        (completed, percentage) => (ConsentMinigameType.Conveyor, When(completed > 0)),
        (completed, percentage) => (ConsentMinigameType.ShuffleEasy, When(completed > 0 && percentage < 40f)),
        (completed, percentage) => (ConsentMinigameType.Amidakuji, When(completed > 0)),
        (completed, percentage) => (ConsentMinigameType.FakeCover, When(completed > 0)),
        (completed, percentage) => (ConsentMinigameType.Mash, When(completed > 0)),
        //ノルマの20%を超えてから。60%までは出やすい
        (completed, percentage) => (ConsentMinigameType.LightsOut, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.Slot, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.GridSearch, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.Silhouette, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.FallingPins, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.Raycast, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.ShootingHesitation, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.Telescope, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        (completed, percentage) => (ConsentMinigameType.SwipeCard, When(percentage >= 20f, percentage < 60f ? 3f : 1f)),
        //ノルマの40%を超えてから。常に出やすい
        (completed, percentage) => (ConsentMinigameType.ShuffleHard, When(percentage >= 40f, 3f)),
        (completed, percentage) => (ConsentMinigameType.ArithmeticHard, When(percentage >= 40f, 3f)),
        (completed, percentage) => (ConsentMinigameType.SlidePuzzle, When(percentage >= 40f, 3f)),
        (completed, percentage) => (ConsentMinigameType.ShootingEndurance, When(percentage >= 40f, 3f)),
        (completed, percentage) => (ConsentMinigameType.HoleShot, When(percentage >= 40f, 3f)),
        (completed, percentage) => (ConsentMinigameType.Roaming, When(percentage >= 40f, 3f)),
        (completed, percentage) => (ConsentMinigameType.Hideout, When(percentage >= 40f, 3f)),
    ];

    /// <summary>
    /// 進捗に応じて、出題しうる種類とその重みを返します。
    /// </summary>
    static public (ConsentMinigameType type, float weight)[] GetTypeCandidates(int completed, float percentage)
        => TypeWeights.Select(f => f.Invoke(completed, percentage)).Where(c => c.weight > 0f).ToArray();

    /// <summary>
    /// 進捗に応じて、出題する種類を重みで抽選します。excludedに含まれる種類は選びません。
    /// ただし、除くと候補が無くなるときは除かずに選びます。
    /// </summary>
    static public ConsentMinigameType ChooseType(int completed, float percentage, ICollection<ConsentMinigameType>? excluded = null)
    {
        var candidates = GetTypeCandidates(completed, percentage);
        if (excluded != null && excluded.Count > 0)
        {
            var filtered = candidates.Where(c => !excluded.Contains(c.type)).ToArray();
            if (filtered.Length > 0) candidates = filtered;
        }
        if (candidates.Length == 0) return ConsentMinigameType.Standard;

        float value = UnityEngine.Random.value * candidates.Sum(c => c.weight);
        foreach (var c in candidates)
        {
            value -= c.weight;
            if (value < 0f) return c.type;
        }
        return candidates[^1].type;
    }

    /// <summary>
    /// 種類に応じたミニゲームの中身を作ります。
    /// </summary>
    static public ConsentGame Create(ConsentMinigameType type) => type switch
    {
        ConsentMinigameType.Standard => new StandardGame(false),
        ConsentMinigameType.InvColor => new StandardGame(true),
        ConsentMinigameType.FallingPins => new FallingPinsGame(),
        ConsentMinigameType.ScrollCheck => new ScrollCheckGame(),
        ConsentMinigameType.LightsOut => new LightsOutGame(),
        ConsentMinigameType.Popups => new PopupsGame(),
        ConsentMinigameType.Fleeing => new FleeingGame(),
        ConsentMinigameType.GridSearch => new GridSearchGame(),
        ConsentMinigameType.Silhouette => new SilhouetteGame(),
        ConsentMinigameType.Interview => new InterviewGame(),
        ConsentMinigameType.ArithmeticEasy => new ArithmeticGame(false),
        ConsentMinigameType.ArithmeticHard => new ArithmeticGame(true),
        ConsentMinigameType.Conveyor => new ConveyorGame(),
        ConsentMinigameType.SlidePuzzle => new SlidePuzzleGame(),
        ConsentMinigameType.Amidakuji => new AmidakujiGame(),
        ConsentMinigameType.Raycast => new RaycastGame(),
        ConsentMinigameType.ShuffleEasy => new ShuffleGame(false),
        ConsentMinigameType.ShuffleHard => new ShuffleGame(true),
        ConsentMinigameType.ShootingHesitation => new ShootingGame(false),
        ConsentMinigameType.ShootingEndurance => new ShootingGame(true),
        ConsentMinigameType.HoleShot => new HoleShotGame(),
        ConsentMinigameType.Roaming => new RoamingGame(),
        ConsentMinigameType.Telescope => new TelescopeConsentGame(),
        ConsentMinigameType.SwipeCard => new SwipeCardGame(),
        ConsentMinigameType.Hideout => new HideoutGame(),
        ConsentMinigameType.FakeCover => new FakeCoverGame(),
        ConsentMinigameType.Slot => new SlotGame(),
        ConsentMinigameType.Mash => new MashGame(),
        _ => new StandardGame(false),
    };
}
