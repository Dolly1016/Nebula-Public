using System;
using System.Collections.Generic;
using Il2CppInterop.Runtime.Injection;
using Nebula;
using Nebula.Behavior;
using Nebula.Modules;
using Nebula.Utilities;
using TMPro;
using UnityEngine;
using Virial;

namespace Consenter;

/// <summary>
/// 利用規約に同意するミニゲームの窓です。枠と題名を用意し、中身は種類(<see cref="ConsentMinigameType"/>)ごとの<see cref="ConsentGame"/>が作ります。
/// 中身が成功を伝えると同意でき、失敗を伝えると同意に失敗します。閉じるボタンで閉じた場合は、どちらにもなりません。
/// </summary>
public class ConsentMinigame : Minigame
{
    static ConsentMinigame() => ClassInjector.RegisterTypeInIl2Cpp<ConsentMinigame>();
    public ConsentMinigame(IntPtr ptr) : base(ptr) { }
    public ConsentMinigame() : base(ClassInjector.DerivedConstructorPointer<ConsentMinigame>()) { ClassInjector.DerivedConstructorBody(this); }

    private Consenter.Instance? consenter = null;
    private bool answered = false;
    private ConsentGame? game = null;
    private readonly List<(Transform transform, Vector3 origin, float time)> shakes = [];

    public ConsentInput Clicks { get; } = new();
    /// <summary>
    /// 窓の中身を置く入れ物です。種類ごとの縮尺(<see cref="ConsentGame.DialogScale"/>)で縮めてあります。
    /// </summary>
    public Transform ContentRoot { get; private set; } = null!;
    public ConsentMinigameType Type { get; private set; } = ConsentMinigameType.Standard;
    /// <summary>デバッグ用に開いた場合はtrueです。結果は画面の色で示すだけで、同意者には伝えません。</summary>
    public bool IsTest => consenter == null;
    public float Elapsed { get; private set; } = 0f;
    public bool IsPlaying => !answered && amClosing == CloseState.None;

    /// <summary>
    /// 同意者が決めておいた種類で開きます。途中で閉じたミニゲームがあれば、それを同じ状態から再開します。
    /// </summary>
    public void SetUp(Consenter.Instance consenter)
    {
        this.consenter = consenter;
        //途中で閉じたミニゲームがあれば、同じ種類を同じ状態から再開する
        if (consenter.SuspendedGame is { } suspended)
        {
            Type = suspended.type;
            savedState = suspended.state;
            consenter.SuspendedGame = null;
        }
        //種類は進捗が変わったときに同意者が決めておくので、開き直しても変わらない
        else Type = consenter.GetNextType();
    }

    //再開するときの状態
    private object? savedState = null;

    /// <summary>
    /// 種類の一覧に無い中身で窓を開きます。ヒントの表示など、同意の答えを出さない窓に使います。
    /// </summary>
    public void SetUpCustom(ConsentGame game)
    {
        consenter = null;
        customGame = game;
    }

    private ConsentGame? customGame = null;

    public override void Begin(PlayerTask task)
    {
        this.BeginInternal(task);

        game = customGame ?? ConsentMinigameTypes.Create(Type);
        game.Initialize(this);
        if (savedState != null) game.RestoreState(savedState);

        //窓の中身はまとめて縮める
        ContentRoot = ConsentUI.Object(transform, "Content", Vector3.zero).transform;
        var root = ContentRoot;

        closeButton = MetaScreen.InstantiateCloseButton(root, Vector3.zero);
        ConsentUI.MakeTriggers(closeButton.gameObject);
        closeButton.OnClick.AddListener((UnityEngine.Events.UnityAction)Close);
        var panel = ConsentUI.Panel(root, "Dialog", new(0f, 0f, 0.1f), Vector2.one);
        panelRenderers = panel.GetComponentsInChildren<SpriteRenderer>();
        titleText = ConsentUI.Text(root, Vector3.zero, Vector2.one, 2.4f, Color.white, TextAlignmentOptions.Center, Language.Translate("consenter.minigame.title"));
        instructionText = ConsentUI.Text(root, Vector3.zero, Vector2.one, 1.3f, new(0.85f, 0.85f, 0.85f), TextAlignmentOptions.Center);

        if (!game.ShowDialogFrame)
        {
            panel.SetActive(false);
            titleText.gameObject.SetActive(false);
            instructionText.gameObject.SetActive(false);
        }
        //導入のある種類は、Standardと同じ窓で始める
        if (game.UsesStandardIntro)
        {
            ChangeDialog(ConsentGame.StandardDialogSize, null, 1f);
            game.BeginIntro();
        }
        else
        {
            ChangeDialog(game.DialogSize, game.InstructionKey, game.DialogScale);
            game.Begin();
        }
    }

    private PassiveButton closeButton = null!;
    private SpriteRenderer[] panelRenderers = null!;
    private TextMeshPro titleText = null!;
    private TextMeshPro instructionText = null!;

    /// <summary>今の窓の内側の大きさです。</summary>
    public Vector2 DialogSize { get; private set; }
    /// <summary>今の窓に説明が出ているかどうかです。</summary>
    public bool HasInstruction { get; private set; }

    /// <summary>
    /// 窓の大きさ、説明、縮尺を変えます。Standardと同じ見た目で始め、途中から別の画面に変わるミニゲームで使います。
    /// </summary>
    public void ChangeDialog(Vector2 size, string? instructionKey, float scale)
    {
        DialogSize = size;
        HasInstruction = instructionKey != null;
        ContentRoot.localScale = new(scale, scale, 1f);

        closeButton.transform.localPosition = new(-size.x / 2f - 0.3f, size.y / 2f + 0.2f, -8f);
        foreach (var renderer in panelRenderers) renderer.size = size + new Vector2(0.75f, 0.75f);

        titleText.transform.localPosition = new(0f, size.y / 2f - 0.3f, -0.5f);
        titleText.rectTransform.sizeDelta = new(size.x - 0.3f, 0.45f);
        instructionText.transform.localPosition = new(0f, size.y / 2f - 0.66f, -0.5f);
        instructionText.rectTransform.sizeDelta = new(size.x - 0.3f, 0.35f);
        instructionText.text = instructionKey != null ? Language.Translate(instructionKey) : "";
    }

    public void Update()
    {
        Elapsed += Time.deltaTime;
        UpdateShakes();
        UpdatePopIns();
        if (!IsPlaying || game == null) return;

        //結果を見せている間は押せない
        Clicks.Update(!finishing);
        if (IsPlaying)
        {
            if (game.InIntro) game.UpdateIntro();
            else game.Update();
        }
        if (!finishing) UpdateIdle();
        if (finishing) UpdateFinishing();
    }

    /// <summary>
    /// 窓を開いてから決まった時間が経ったら、「しばらく操作が無かったため、同意を終了しました。」と出して、同意しなかったことにします。
    /// 操作しているかどうかに関わらず、開いてからの時間で数えます。何秒で終えるかは種類ごとに決めます(<see cref="ConsentGame.IdleTimeout"/>)。
    /// </summary>
    private void UpdateIdle()
    {
        if (!IsPlaying || game == null) return;
        if (game.IdleTimeout is not float timeout || Elapsed < timeout) return;

        //窓の一番手前に知らせを出してから、同意しなかったことにする
        var size = new Vector2(Math.Min(DialogSize.x, 5.4f), 1.4f);
        var notice = ConsentUI.Panel(ContentRoot, "IdleNotice", new(0f, 0f, -30f), size + new Vector2(0.4f, 0.4f), 0.75f);
        ConsentUI.Text(notice.transform, new(0f, 0f, -0.05f), size - new Vector2(0.2f, 0.2f), 1.5f, Color.white, TextAlignmentOptions.Center, Language.Translate("consenter.minigame.timeout"));
        //裏のボタンは押せないようにする
        Clicks.Add(notice.transform, size + new Vector2(0.4f, 0.4f), () => { });
        ConsentHelpers.PopIn(notice.transform);
        FinishAfter(false, 2f);
    }

    private bool finishing = false;
    private bool finishAgreed = false;
    private float finishTimer = 0f;

    /// <summary>結果を見せている間はtrueです。この間も中身の更新は続きますが、クリックはできません。</summary>
    public bool IsFinishing => finishing;

    /// <summary>
    /// 結果の状態を確かめられるよう少し待ってから、答えを出して閉じます。
    /// </summary>
    /// <param name="delay">閉じるまでの時間です。</param>
    public void FinishAfter(bool agreed, float delay = 0.8f)
    {
        if (!IsPlaying || finishing) return;
        finishing = true;
        finishAgreed = agreed;
        finishTimer = delay;
    }

    private void UpdateFinishing()
    {
        finishTimer -= Time.deltaTime;
        if (finishTimer <= 0f)
        {
            finishing = false;
            Answer(finishAgreed);
        }
    }

    /// <summary>
    /// 答えを出して閉じます。同意できた場合はtrueを与えます。
    /// </summary>
    public void Answer(bool agreed)
    {
        //結果を見せている間は、ほかの答えで閉じない
        if (!IsPlaying || finishing) return;
        answered = true;
        if (consenter != null)
        {
            if (agreed) consenter.OnConsented();
            else consenter.OnFailedToConsent();
        }
        else
        {
            ConsentNotice.ShowResult(agreed);
        }
        Close();
    }

    /// <summary>
    /// マップ中を歩き回る同意ボタンを放ち、答えを出さずに閉じます。
    /// </summary>
    public void ReleaseRoamingButtons()
    {
        if (!IsPlaying) return;
        answered = true;
        if (consenter != null) consenter.StartRoaming();
        else RoamingConsent.Start(null);
        Close();
    }

    private readonly List<(Transform transform, Vector3 scale, float time, float duration)> popIns = [];

    /// <summary>
    /// 大きさ0から、元の大きさまでピュッと大きくして出現させます。
    /// </summary>
    public void PopIn(Transform target, float duration = 0.15f, float delay = 0f)
    {
        if (!target) return;
        //遅れの分は、時間を負から数え始めて大きさ0のまま待つ
        popIns.Add((target, target.localScale, -delay, duration));
        target.localScale = Vector3.zero;
    }

    private void UpdatePopIns()
    {
        for (int i = popIns.Count - 1; i >= 0; i--)
        {
            var (target, scale, time, duration) = popIns[i];
            if (!target) { popIns.RemoveAt(i); continue; }
            time += Time.deltaTime;
            float t = Mathf.Clamp01(time / duration);
            //少し行き過ぎてから戻る
            float s = t < 1f ? Mathf.Sin(t * Mathf.PI * 0.5f) * (1f + 0.15f * Mathf.Sin(t * Mathf.PI)) : 1f;
            target.localScale = scale * s;
            if (t >= 1f) popIns.RemoveAt(i);
            else popIns[i] = (target, scale, time, duration);
        }
    }

    /// <summary>
    /// 同意ボタンをマップのどこかの端末に逃げ込ませ、答えを出さずに閉じます。
    /// </summary>
    public void ReleaseHideout()
    {
        if (!IsPlaying) return;
        answered = true;
        if (consenter != null) consenter.StartHideout();
        else HideoutConsent.Start(null, null);
        Close();
    }

    /// <summary>
    /// ボタンを小さく揺らします。
    /// </summary>
    public void Shake(Transform target)
    {
        if (!target) return;
        foreach (var s in shakes) if (s.transform == target) return;
        shakes.Add((target, target.localPosition, 0f));
    }

    private void UpdateShakes()
    {
        for (int i = shakes.Count - 1; i >= 0; i--)
        {
            var (target, origin, time) = shakes[i];
            if (!target) { shakes.RemoveAt(i); continue; }
            time += Time.deltaTime;
            if (time > 0.3f)
            {
                target.localPosition = origin;
                shakes.RemoveAt(i);
                continue;
            }
            target.localPosition = origin + new Vector3(Mathf.Sin(time * 60f) * 0.06f * (1f - time / 0.3f), 0f, 0f);
            shakes[i] = (target, origin, time);
        }
    }

    public override void Close()
    {
        if (amClosing == CloseState.None)
        {
            game?.OnClose();
            //答えを出さずに閉じたときは、再開できるように状態を預ける
            if (!answered && customGame == null && consenter != null && game?.SaveState() is { } state)
                consenter.SuspendedGame = (Type, state);
        }
        this.CloseInternal();
    }

    /// <summary>
    /// 窓を開きます。開いているミニゲームがあれば閉じます。
    /// </summary>
    static public ConsentMinigame Open(Action<ConsentMinigame> setUp)
    {
        if (Minigame.Instance) Minigame.Instance.Close();
        var obj = UnityHelper.CreateObject("ConsentMinigame", null, Vector3.zero, ConsentUI.UILayer);
        var minigame = obj.AddComponent<ConsentMinigame>();
        minigame.transform.SetParent(Camera.main.transform, false);
        minigame.transform.localPosition = new Vector3(0f, 0f, -50f);
        setUp.Invoke(minigame);
        minigame.Begin(null!);
        return minigame;
    }
}
