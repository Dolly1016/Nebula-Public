using System;
using Nebula;
using Nebula.Extensions;
using Nebula.Modules;
using Nebula.Utilities;
using TMPro;
using UnityEngine;

namespace Consenter;

/// <summary>
/// ボタンの見た目の種類です。
/// </summary>
public enum ConsentButtonStyle
{
    Agree,
    Disagree,
    Neutral,
}

/// <summary>
/// タイトル画面のプレイボタンを複製して作ったボタンです。
/// </summary>
public class ConsentTitleButton
{
    public GameObject GameObject = null!;
    public Transform Transform => GameObject.transform;
    public PassiveButton Button = null!;
    public TextMeshPro? Text;
    /// <summary>ボタンのローカル座標での背景の範囲です。クリックの判定に使います。</summary>
    public Rect LocalRect;
    /// <summary>ボタンの大きさ(ワールド座標)です。</summary>
    public Vector2 Size;

    public void SetStyle(ConsentButtonStyle style)
    {
        SetHue(ConsentUI.HueOf(style));
        SetTextColor(ConsentUI.TextColorOf(style));
    }

    /// <summary>
    /// 背景を指定した色相にします。
    /// </summary>
    public void SetHue(float hue)
    {
        foreach (var renderer in GameObject.GetComponentsInChildren<SpriteRenderer>(true))
            if (renderer.material) renderer.material.SetFloat("_Hue", ConsentAssets.HueShiftFor(hue));
    }

    public void SetTextColor(Color color)
    {
        Button.activeTextColor = color;
        Button.inactiveTextColor = color;
        if (Text) Text!.color = color;
    }

    public void SetLabel(string text)
    {
        if (Text) Text!.text = text;
    }
}

/// <summary>
/// 角丸の四角に文字を乗せた、簡易なボタンです。たくさん並べるときに使います。
/// </summary>
public class ConsentSimpleButton
{
    public SpriteRenderer Background = null!;
    public TextMeshPro Text = null!;
    public Transform Transform => Background.transform;
    public GameObject GameObject => Background.gameObject;
    public Vector2 Size;
    public Rect LocalRect => new(-Size * 0.5f, Size);
}

/// <summary>
/// 同意のミニゲームで使う部品を作ります。
/// </summary>
static public class ConsentUI
{
    static public int UILayer => LayerExpansion.GetUILayer();

    /// <summary>
    /// 与えたオブジェクトとその子にある当たり判定を、すべてトリガーにします。複製したボタンが、移動や影の邪魔をしないようにするためです。
    /// </summary>
    static public void MakeTriggers(GameObject obj)
    {
        foreach (var collider in obj.GetComponentsInChildren<Collider2D>(true)) collider.isTrigger = true;
    }

    static public float HueOf(ConsentButtonStyle style) => style switch
    {
        ConsentButtonStyle.Agree => ConsentAssets.AgreeHue,
        ConsentButtonStyle.Disagree => ConsentAssets.DisagreeHue,
        _ => ConsentAssets.NeutralHue,
    };
    static public Color TextColorOf(ConsentButtonStyle style) => style switch
    {
        ConsentButtonStyle.Agree => ConsentAssets.AgreeTextColor,
        ConsentButtonStyle.Disagree => ConsentAssets.DisagreeTextColor,
        _ => ConsentAssets.NeutralTextColor,
    };
    static public Color ColorOf(ConsentButtonStyle style) => style switch
    {
        ConsentButtonStyle.Agree => ConsentAssets.AgreeColor,
        ConsentButtonStyle.Disagree => ConsentAssets.DisagreeColor,
        _ => ConsentAssets.NeutralColor,
    };

    static public string AgreeText => Language.Translate("consenter.minigame.agree");
    static public string DisagreeText => Language.Translate("consenter.minigame.disagree");

    static public GameObject Object(Transform parent, string name, Vector3 localPos)
        => UnityHelper.CreateObject(name, parent, localPos, UILayer);

    static public SpriteRenderer Sprite(Transform parent, string name, Vector3 localPos, Sprite? sprite, Color? color = null, float scale = 1f)
    {
        var renderer = UnityHelper.CreateObject<SpriteRenderer>(name, parent, localPos, UILayer);
        renderer.sprite = sprite;
        if (color.HasValue) renderer.color = color.Value;
        renderer.transform.localScale = new(scale, scale, 1f);
        return renderer;
    }

    /// <summary>
    /// 好きな大きさに伸ばせる画像を置きます。
    /// </summary>
    static public SpriteRenderer Sliced(Transform parent, string name, Vector3 localPos, Sprite sprite, Vector2 size, Color? color = null)
    {
        var renderer = Sprite(parent, name, localPos, sprite, color);
        renderer.drawMode = SpriteDrawMode.Sliced;
        renderer.tileMode = SpriteTileMode.Continuous;
        renderer.size = size;
        return renderer;
    }

    /// <summary>
    /// 塗りつぶした長方形を置きます。
    /// </summary>
    static public SpriteRenderer Box(Transform parent, string name, Vector3 localPos, Vector2 size, Color color)
    {
        var renderer = Sprite(parent, name, localPos, ConsentAssets.Square.GetSprite(), color);
        renderer.transform.localScale = new(size.x / 0.16f, size.y / 0.16f, 1f);
        return renderer;
    }

    /// <summary>
    /// 塗りつぶした円を置きます。
    /// </summary>
    static public SpriteRenderer Circle(Transform parent, string name, Vector3 localPos, float radius, Color color)
        => Sprite(parent, name, localPos, ConsentAssets.Circle.GetSprite(), color, radius / 0.64f);

    /// <summary>
    /// 2点を結ぶ線を置きます。
    /// </summary>
    static public SpriteRenderer Line(Transform parent, string name, Vector2 from, Vector2 to, float z, float width, Color color)
    {
        var renderer = Box(parent, name, new((from.x + to.x) * 0.5f, (from.y + to.y) * 0.5f, z), new((to - from).magnitude, width), color);
        renderer.transform.localEulerAngles = new(0f, 0f, Mathf.Atan2(to.y - from.y, to.x - from.x) * Mathf.Rad2Deg);
        return renderer;
    }

    /// <summary>
    /// MetaScreenのモダンな背景と同じ見た目の枠を置きます。
    /// </summary>
    static public GameObject Panel(Transform parent, string name, Vector3 localPos, Vector2 size, float innerBrightness = 0.55f)
    {
        var holder = Object(parent, name, localPos);
        Sliced(holder.transform, "Inner", new(0f, 0f, 0.01f), MetaScreen.BackInnerImage.GetSprite(), size, Color.white.RGBMultiplied(innerBrightness));
        Sliced(holder.transform, "Frame", new(0f, 0f, -0.01f), MetaScreen.BackFrameImage.GetSprite(), size);
        return holder;
    }

    static public TextMeshPro Text(Transform parent, Vector3 localPos, Vector2 size, float fontSize, Color color, TextAlignmentOptions alignment = TextAlignmentOptions.Center, string text = "")
    {
        var tmp = GameObject.Instantiate(VanillaAsset.StandardTextPrefab, parent);
        tmp.transform.localPosition = localPos;
        tmp.transform.localScale = Vector3.one;
        tmp.gameObject.layer = UILayer;
        tmp.rectTransform.sizeDelta = size;
        tmp.enableAutoSizing = false;
        tmp.enableWordWrapping = true;
        tmp.fontSize = fontSize;
        tmp.alignment = alignment;
        tmp.color = color;
        tmp.outlineColor = Color.clear;
        tmp.text = text;
        return tmp;
    }

    /// <summary>
    /// 角丸の四角に文字を乗せた簡易なボタンを作ります。
    /// </summary>
    /// <summary>
    /// 簡易なボタンの文字の大きさにかける倍率です。
    /// </summary>
    public const float SimpleButtonFontScale = 1.5f;

    static public ConsentSimpleButton SimpleButton(Transform parent, string name, Vector3 localPos, Vector2 size, string label, Color color, Color textColor, float fontSize = 1.4f)
    {
        var background = Sliced(parent, name, localPos, ConsentAssets.RoundRect, size, color);
        var text = Text(background.transform, new(0f, 0f, -0.01f), size, fontSize * SimpleButtonFontScale, textColor, TextAlignmentOptions.Center, label);
        return new() { Background = background, Text = text, Size = size };
    }

    static public ConsentSimpleButton SimpleButton(Transform parent, string name, Vector3 localPos, Vector2 size, string label, ConsentButtonStyle style, float fontSize = 1.4f)
        => SimpleButton(parent, name, localPos, size, label, ColorOf(style), TextColorOf(style), fontSize);

    /// <summary>
    /// 文字をボタンの中央から少し上に置く量です。
    /// </summary>
    public const float TitleButtonTextOffsetY = 0.05f;

    /// <summary>
    /// タイトル画面のプレイボタンを複製してボタンを作ります。
    /// 元のボタンは左にアイコン、右寄せの文字という作りなので、アイコンを消し、文字をボタンの中央に置き直します。
    /// </summary>
    static public ConsentTitleButton TitleButton(Transform parent, string name, Vector3 localPos, float width, string label, ConsentButtonStyle style)
    {
        var button = GameObject.Instantiate(VanillaAsset.TitleButtonPrefab, parent);
        button.gameObject.name = name;
        button.transform.localPosition = localPos;
        button.transform.localScale = Vector3.one;
        button.transform.localRotation = Quaternion.identity;
        button.gameObject.SetActive(true);
        button.OnClick = new();
        MakeTriggers(button.gameObject);
        foreach (var t in button.GetComponentsInChildren<Transform>(true))
        {
            t.gameObject.layer = UILayer;
            if (t.name == "Icon") t.gameObject.SetActive(false);
        }

        //背景の色相をずらすためにHSVシェーダを付ける
        foreach (var renderer in button.GetComponentsInChildren<SpriteRenderer>(true))
            renderer.material = new Material(NebulaAsset.HSVShader);

        //ボタンの大きさを揃える。背景は通常時の絵(inactiveSprites)で測る
        var background = (button.inactiveSprites ? button.inactiveSprites : button.gameObject).GetComponentInChildren<SpriteRenderer>();
        if (background && background.bounds.size.x > 0f)
        {
            float scale = width / background.bounds.size.x * button.transform.localScale.x;
            button.transform.localScale = new(scale, scale, 1f);
        }

        var result = new ConsentTitleButton() { GameObject = button.gameObject, Button = button };

        if (background)
        {
            var bounds = background.bounds;
            Vector2 min = button.transform.InverseTransformPoint(bounds.min);
            Vector2 max = button.transform.InverseTransformPoint(bounds.max);
            result.LocalRect = Rect.MinMaxRect(Math.Min(min.x, max.x), Math.Min(min.y, max.y), Math.Max(min.x, max.x), Math.Max(min.y, max.y));
            result.Size = bounds.size;
        }

        //文字はボタンの中央に。翻訳の自動更新は外して、自前の文言を入れる
        var text = button.buttonText;
        if (text)
        {
            foreach (var translator in button.GetComponentsInChildren<TextTranslatorTMP>(true)) GameObject.Destroy(translator);

            //文字の入れ物(FontPlacer)ごと右に寄せてあり、文字の範囲(RectTransform)も右寄りなので、中心を基準にしてから背景の中心へ動かす
            Vector3 center = background ? background.bounds.center : button.transform.position;
            for (var t = text.transform; t && t != button.transform; t = t.parent) t.localPosition = new(0f, t.localPosition.y, t.localPosition.z);
            text.rectTransform.pivot = new(0.5f, 0.5f);
            var textPos = text.transform.position;
            text.transform.position = new(center.x, textPos.y + TitleButtonTextOffsetY, textPos.z);
            if (background) text.rectTransform.sizeDelta = new(background.bounds.size.x / Math.Max(text.transform.lossyScale.x, 0.0001f) * 0.9f, text.rectTransform.sizeDelta.y);
            text.alignment = TextAlignmentOptions.Center;
            text.text = label;
            //文字色を暗くしたので縁取りは無くす
            text.outlineColor = Color.clear;
            result.Text = text;
        }

        result.SetStyle(style);
        return result;
    }

    /// <summary>
    /// ボタンなどの部品をSortingGroupで1つにまとめます。ほかのボタンと重なっても、部品が入り混じって描かれなくなります。
    /// まとめた中では奥行きで前後が決まらないので、背景の絵は0、文字は10の順番にして、文字が必ず手前に来るようにします。
    /// </summary>
    static public void ApplySortingGroup(GameObject obj, int order = 0)
    {
        var group = obj.GetComponent<UnityEngine.Rendering.SortingGroup>() ?? obj.AddComponent<UnityEngine.Rendering.SortingGroup>();
        group.sortingOrder = order;
        foreach (var renderer in obj.GetComponentsInChildren<SpriteRenderer>(true)) renderer.sortingOrder = 0;
        foreach (var text in obj.GetComponentsInChildren<TextMeshPro>(true)) text.sortingOrder = 10;
    }

    /// <summary>
    /// 範囲の内側だけを表示するマスクを作ります。
    /// </summary>
    static public SpriteMask Mask(Transform parent, Vector3 localPos, Vector2 size)
    {
        var mask = UnityHelper.CreateObject<SpriteMask>("Mask", parent, localPos, UILayer);
        mask.sprite = ConsentAssets.Square.GetSprite();
        mask.transform.localScale = new(size.x / 0.16f, size.y / 0.16f, 1f);
        return mask;
    }

    /// <summary>
    /// 配下の画像と文字を、マスクの内側だけに表示するようにします。
    /// </summary>
    static public void SetMasked(GameObject obj)
    {
        foreach (var renderer in obj.GetComponentsInChildren<SpriteRenderer>(true)) renderer.maskInteraction = SpriteMaskInteraction.VisibleInsideMask;
        foreach (var text in obj.GetComponentsInChildren<TextMeshPro>(true))
        {
            //マスク用の素材に替えると輪郭が素材のものに戻るので、元の輪郭を付け直す
            var outlineColor = text.outlineColor;
            var outlineWidth = text.outlineWidth;
            text.fontMaterial = VanillaAsset.StandardMaskedFontMaterial;
            text.outlineColor = outlineColor;
            text.outlineWidth = outlineWidth;
        }
    }

    /// <summary>
    /// 配下の画像と文字の透明度を変えます。
    /// </summary>
    static public void SetAlpha(GameObject obj, float alpha)
    {
        foreach (var renderer in obj.GetComponentsInChildren<SpriteRenderer>(true))
        {
            var color = renderer.color;
            color.a = alpha;
            renderer.color = color;
        }
        foreach (var text in obj.GetComponentsInChildren<TextMeshPro>(true)) text.alpha = alpha;
    }
}
