using Nebula.Behavior;

namespace Consenter;

/// <summary>
/// ミニゲームの窓の外でも使える、ちょっとした演出です。
/// </summary>
static public class ConsentHelpers
{
    /// <summary>
    /// 大きさ0から、元の大きさまでピュッと大きくして出現させます。少し行き過ぎてから戻ります。
    /// </summary>
    static public void PopIn(Transform target, float duration = 0.15f)
    {
        var scale = target.localScale;
        target.localScale = Vector3.zero;
        var behaviour = target.gameObject.AddComponent<ScriptBehaviour>();
        float time = 0f;
        behaviour.UpdateHandler += () =>
        {
            if (time >= duration) return;
            time += Time.deltaTime;
            float t = Mathf.Clamp01(time / duration);
            target.localScale = scale * (t < 1f ? Mathf.Sin(t * Mathf.PI * 0.5f) * (1f + 0.15f * Mathf.Sin(t * Mathf.PI)) : 1f);
        };
    }
}
