using System.Collections;
using BepInEx.Unity.IL2CPP.Utils.Collections;

namespace Consenter;

/// <summary>
/// 同意できたとき・できなかったときの知らせです。
/// バニラの「タスク完了」の表示(HudManager.TaskCompleteOverlay)を複製し、文字を「同意」「不同意」に変えて同じ動きで見せます。
/// 不同意のときは文字を赤めにし、原子炉を起動するタスク(SimonSaysGame)で間違えたときの音を鳴らします。
/// </summary>
static public class ConsentNotice
{
    static private readonly Color DisagreeTextColor = new(1f, 0.42f, 0.38f);
    static private AudioClip? failSound = null;

    //NoSが読み込んでいるSkeldのLongTasksのうち、原子炉を起動するタスク(SimonSaysGame)の位置
    private const int SkeldMapId = 0;
    private const int StartReactorLongTaskIndex = 5;

    /// <summary>
    /// 原子炉を起動するタスクで間違えたときの音を、NoSが読み込んでいるSkeldのタスクから取ります。
    /// </summary>
    static private AudioClip? FindFailSound()
    {
        if (failSound) return failSound;
        var skeld = VanillaAsset.MapAsset[SkeldMapId];
        if (!skeld || skeld.LongTasks.Length <= StartReactorLongTaskIndex) return null;
        var simon = skeld.LongTasks[StartReactorLongTaskIndex].MinigamePrefab?.TryCast<SimonSaysGame>();
        if (simon != null) failSound = simon.FailSound;
        return failSound;
    }

    /// <summary>
    /// 原子炉を起動するタスクで間違えたときの音を鳴らします。
    /// </summary>
    static public void PlayFailSound()
    {
        var clip = FindFailSound();
        if (clip && Constants.ShouldPlaySfx()) SoundManager.Instance.PlaySound(clip, false);
    }

    /// <summary>
    /// 同意できたか、できなかったかを見せます。どのミニゲームからでも、結果はこれで見せてそろえます。
    /// 不同意のときは画面を赤く光らせ、「不同意」と出します。同意のときは「同意」と出します。
    /// </summary>
    static public void ShowResult(bool agreed)
    {
        if (!agreed) AmongUsUtil.PlayQuickFlash(Color.red.AlphaMultiplied(0.5f));
        Show(agreed);
    }

    /// <summary>
    /// 「同意」または「不同意」の知らせを出します。
    /// </summary>
    static public void Show(bool agreed)
    {
        if (!HudManager.InstanceExists) return;
        var hud = HudManager.Instance;
        var original = hud.TaskCompleteOverlay;
        if (!original) return;

        //「タスク完了」の表示を複製し、文字だけ変える
        var overlay = GameObject.Instantiate(original.gameObject, original.parent).transform;
        overlay.name = agreed ? "ConsentAgreedOverlay" : "ConsentDisagreedOverlay";
        foreach (var translator in overlay.GetComponentsInChildren<TextTranslatorTMP>(true)) GameObject.Destroy(translator);
        foreach (var text in overlay.GetComponentsInChildren<TextMeshPro>(true))
        {
            text.text = Language.Translate(agreed ? "consenter.notice.agreed" : "consenter.notice.disagreed");
            if (!agreed) text.color = DisagreeTextColor;
        }

        hud.StartCoroutine(CoShow(overlay, agreed).WrapToIl2Cpp());
    }

    /// <summary>
    /// バニラの「タスク完了」と同じく、下から滑り込み、少し止まってから上へ抜けていきます。
    /// </summary>
    static private IEnumerator CoShow(Transform overlay, bool agreed)
    {
        if (agreed)
        {
            if (Constants.ShouldPlaySfx()) SoundManager.Instance.PlaySound(HudManager.Instance.TaskCompleteSound, false);
        }
        else PlayFailSound();

        overlay.gameObject.SetActive(true);
        yield return Effects.Slide2D(overlay, new Vector2(0f, -8f), Vector2.zero, 0.25f);
        for (float time = 0f; time < 0.75f; time += Time.deltaTime) yield return null;
        yield return Effects.Slide2D(overlay, Vector2.zero, new Vector2(0f, 8f), 0.25f);
        if (overlay) GameObject.Destroy(overlay.gameObject);
    }
}
