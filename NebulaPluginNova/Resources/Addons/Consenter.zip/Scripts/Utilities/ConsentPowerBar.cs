using Nebula.Extensions;

namespace Consenter;

/// <summary>
/// Airshipのシャワーを直すタスク(FixShowerMinigame)の強さのメーター(PowerBar)を流用したものです。
/// 長押ししている間、強さはバニラのタスクと同じように0と1の間を行き来します。
/// メーターが見つからないときは、簡易な棒で代わりにします。
/// </summary>
public class ConsentPowerBar
{
    private readonly PowerBar? bar;
    private readonly GameObject holder;
    private readonly SpriteRenderer? fallbackFill;
    private readonly float fallbackWidth;
    private float powerTime = 0f;

    /// <summary>今の強さ(0～1)です。</summary>
    public float Power { get; private set; } = 0f;
    public bool IsCharging { get; private set; } = false;

    static private PowerBar? FindPrefab()
    {
        IEnumerable<ShipStatus> ships = [ShipStatus.Instance, .. VanillaAsset.MapAsset];
        foreach (var ship in ships)
        {
            if (!ship) continue;
            foreach (var task in ship.CommonTasks.Concat(ship.LongTasks).Concat(ship.ShortTasks))
            {
                if (!task || !task.MinigamePrefab) continue;
                var shower = task.MinigamePrefab.TryCast<FixShowerMinigame>();
                if (shower != null && shower.powerBar) return shower.powerBar;
            }
        }
        return null;
    }

    /// <param name="center">メーターの中心です。</param>
    /// <param name="width">メーターの幅です。</param>
    public ConsentPowerBar(Transform parent, Vector3 center, float width)
    {
        holder = ConsentUI.Object(parent, "PowerBar", center);
        var prefab = FindPrefab();
        if (prefab != null)
        {
            bar = GameObject.Instantiate(prefab, holder.transform);
            bar.transform.localPosition = Vector3.zero;
            bar.transform.localRotation = Quaternion.identity;
            float scale = width / Math.Max(bar.Width, 0.01f);
            bar.transform.localScale = new(scale, scale, 1f);
            foreach (var t in bar.GetComponentsInChildren<Transform>(true)) t.gameObject.layer = LayerExpansion.GetUILayer();
            bar.SetValue(0f);
        }
        else
        {
            fallbackWidth = width;
            ConsentUI.Box(holder.transform, "Back", Vector3.zero, new(width, 0.16f), new(0.2f, 0.2f, 0.2f));
            fallbackFill = ConsentUI.Box(holder.transform, "Fill", new(0f, 0f, -0.01f), new(0.001f, 0.16f), new(1f, 0.8f, 0.3f));
        }
        holder.SetActive(false);
    }

    /// <summary>溜め始めます。</summary>
    public void BeginCharge()
    {
        IsCharging = true;
        powerTime = 0f;
        Power = 0f;
        holder.SetActive(true);
        Apply();
    }

    /// <summary>溜めている間、毎フレーム呼び出します。強さはバニラのタスクと同じように行き来します。</summary>
    public void UpdateCharge(float deltaTime)
    {
        if (!IsCharging) return;
        powerTime += deltaTime;
        Power = Mathf.Sin(powerTime * 4f - Mathf.PI * 0.5f) * 0.5f + 0.5f;
        Apply();
    }

    /// <summary>溜めるのをやめ、その時の強さを返します。</summary>
    public float Release()
    {
        IsCharging = false;
        holder.SetActive(false);
        return Power;
    }

    private void Apply()
    {
        if (bar) bar!.SetValue(Power);
        else if (fallbackFill)
        {
            float w = Math.Max(0.001f, fallbackWidth * Power);
            fallbackFill!.transform.localScale = new(w / 0.16f, 1f, 1f);
            fallbackFill.transform.localPosition = new(-fallbackWidth * 0.5f + w * 0.5f, 0f, -0.01f);
        }
    }
}
