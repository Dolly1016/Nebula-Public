namespace Consenter;

/// <summary>
/// バニラのミニゲームの画面を、見た目だけ借りるための処理です。
/// </summary>
static public class ConsentVanillaMinigame
{
    /// <summary>
    /// 複製したバニラのミニゲームから、動きを持つ部品(ミニゲーム本体、タッチパッド、ボタン)と閉じるボタンを外し、当たり判定を止めてUIのレイヤーに置きます。
    /// 必要な部品は、これを呼ぶ前にミニゲーム本体から取り出しておきます。
    /// </summary>
    static public void Strip(GameObject obj, Minigame minigame)
    {
        foreach (var touchpad in obj.GetComponentsInChildren<TouchpadBehavior>(true)) GameObject.DestroyImmediate(touchpad);
        GameObject.DestroyImmediate(minigame);
        //ミニゲームの閉じるボタン(押すとCloseを呼ぶボタン)は隠す
        foreach (var button in obj.GetComponentsInChildren<PassiveButton>(true))
        {
            var onClick = button.OnClick;
            if (onClick == null) continue;
            for (int i = 0; i < onClick.GetPersistentEventCount(); i++)
            {
                if (onClick.GetPersistentMethodName(i).Contains("Close", StringComparison.OrdinalIgnoreCase))
                {
                    button.gameObject.SetActive(false);
                    break;
                }
            }
        }
        //バニラのボタンと当たり判定は使わない。操作はこちらで扱う
        foreach (var button in obj.GetComponentsInChildren<PassiveUiElement>(true)) GameObject.DestroyImmediate(button);
        foreach (var collider in obj.GetComponentsInChildren<Collider2D>(true)) collider.enabled = false;
        foreach (var t in obj.GetComponentsInChildren<Transform>(true))
        {
            t.gameObject.layer = ConsentUI.UILayer;
            //ミニゲームの閉じるボタンの絵は使わない
            if (t.name.Contains("close", StringComparison.OrdinalIgnoreCase)) t.gameObject.SetActive(false);
        }
    }
}
