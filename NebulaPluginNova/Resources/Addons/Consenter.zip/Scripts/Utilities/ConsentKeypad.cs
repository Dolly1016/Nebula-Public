using Nebula.Extensions;

namespace Consenter;

/// <summary>
/// 酸素のサボタージュで使うバニラのテンキー(KeypadGame)を流用した数字の入力欄です。
/// 数字とクリアのボタンはバニラの処理のまま使い、決定(✓)のボタンだけを差し替えます。
/// 閉じるボタン、外側をクリックしたときに閉じる当たり判定、付箋は取り除き、入力装置の背景はそのまま見せます。
/// </summary>
/// <remarks>
/// プレハブの構成(KeyPadDisarmMinigame)
/// ・Background(z=3, admin_keypad_base) の子に OutsideCloseButton(Close)
/// ・CloseButton(ButtonBehavior)
/// ・reactorButton01～10(ClickNumber), admin_keypad_x(ClearEntry), admin_keypad_check(Enter)
/// ・StickyNote(付箋)
/// </remarks>
public class ConsentKeypad
{
    private readonly KeypadGame keypad;
    public GameObject GameObject => keypad.gameObject;

    /// <summary>入力された数です。何も入力されていなければnullです。</summary>
    public int? Number => keypad.numString.Length > 0 ? keypad.number : null;

    /// <summary>入力された数字を表示する欄です。</summary>
    public TextMeshPro Display => keypad.NumberText;

    /// <summary>
    /// これ以上入力できないようにし、表示欄を空にします。
    /// </summary>
    public void Lock()
    {
        keypad.done = true;
        keypad.NumberText.text = "";
        var check = keypad.transform.Find("admin_keypad_check");
        if (check) check.GetComponent<PassiveButton>().OnClick = new();
    }

    /// <summary>
    /// テンキーのプレハブを、今のマップか、読み込み済みのマップから探します。
    /// </summary>
    static private KeypadGame? FindPrefab()
    {
        IEnumerable<ShipStatus> ships = [ShipStatus.Instance, .. VanillaAsset.MapAsset];
        foreach (var ship in ships)
        {
            if (!ship) continue;
            foreach (var task in ship.SpecialTasks)
            {
                if (!task || !task.MinigamePrefab) continue;
                var keypad = task.MinigamePrefab.TryCast<KeypadGame>();
                if (keypad != null) return keypad;
            }
        }
        return null;
    }

    static public bool IsAvailable => FindPrefab() != null;

    /// <param name="height">入力装置の背景の高さです。この高さと幅(maxWidth)に収まるように縮めます。</param>
    /// <param name="onEnter">決定のボタンを押したときに呼び出されます。</param>
    public ConsentKeypad(Transform parent, Vector3 center, float height, float maxWidth, Action onEnter)
    {
        keypad = GameObject.Instantiate(FindPrefab()!, parent);
        ConsentUI.MakeTriggers(keypad.gameObject);
        keypad.name = "ConsentKeypad";
        keypad.transform.localPosition = Vector3.zero;
        keypad.transform.localScale = Vector3.one;
        foreach (var t in keypad.GetComponentsInChildren<Transform>(true)) t.gameObject.layer = LayerExpansion.GetUILayer();

        keypad.number = 0;
        keypad.numString = "";
        keypad.NumberText.text = "";

        //閉じるための部品と付箋は要らない
        foreach (var t in keypad.GetComponentsInChildren<Transform>(true))
        {
            if (t.name is "CloseButton" or "OutsideCloseButton" or "StickyNote") GameObject.Destroy(t.gameObject);
        }

        //決定はこちらで扱う
        var check = keypad.transform.Find("admin_keypad_check");
        var checkButton = check ? check.GetComponent<PassiveButton>() : null;
        if (checkButton)
        {
            checkButton!.OnClick = new();
            checkButton.OnClick.AddListener((UnityEngine.Events.UnityAction)(() => onEnter.Invoke()));
        }

        //背景の絵に合わせて縮め、中心を合わせる
        var background = keypad.transform.Find("Background");
        var backgroundRenderer = background ? background.GetComponent<SpriteRenderer>() : null;
        float backgroundZ = background ? background.localPosition.z : 3f;
        float scale = 1f;
        Vector3 offset = Vector3.zero;
        if (backgroundRenderer)
        {
            var bounds = backgroundRenderer!.bounds;
            //境界はワールド座標なので、親の座標系に直して測る
            Vector3 localSize = parent.InverseTransformVector(bounds.size);
            scale = Math.Min(height / Math.Max(Mathf.Abs(localSize.y), 0.01f), maxWidth / Math.Max(Mathf.Abs(localSize.x), 0.01f));
            offset = parent.InverseTransformVector(keypad.transform.position - bounds.center);
        }
        keypad.transform.localScale = new(scale, scale, 1f);
        //背景はプレハブの中で奥(z=3)にあるので、窓の背景より手前に来るようにずらす
        keypad.transform.localPosition = new(center.x + offset.x * scale, center.y + offset.y * scale, center.z - backgroundZ - 0.05f);
    }
}
