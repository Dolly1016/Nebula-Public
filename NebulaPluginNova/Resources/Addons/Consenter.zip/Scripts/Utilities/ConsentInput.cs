using System;
using System.Collections.Generic;
using Nebula.Extensions;
using Nebula.Utilities;
using UnityEngine;

namespace Consenter;

/// <summary>
/// クリックできる範囲です。範囲は、対象のTransformのローカル座標での長方形で表します。
/// クリックの判定はバニラのPassiveButtonで行います。対象のTransformに、範囲に合わせたBoxCollider2DとPassiveButtonを付けます。
/// 対象がすでにPassiveButtonを持っている(タイトル画面のボタンを複製したものなど)ときは、それをそのまま使います。
/// </summary>
public class ConsentClickable
{
    public Transform Transform;
    public Rect LocalRect;
    public Action OnClick;
    /// <summary>
    /// 追加でクリックできる条件です。スクロールの外側を除くときなどに使います。
    /// 満たさない間はPassiveButtonを無効にするので、裏にあるものの邪魔もしません。
    /// </summary>
    public Func<bool>? Predicate;
    public bool Enabled = true;
    /// <summary>
    /// カーソルが乗ったとき、離れたときに呼び出されます。
    /// </summary>
    public Action<bool>? OnHover;
    internal bool hovered = false;
    internal PassiveButton? Button;

    public ConsentClickable(Transform transform, Rect localRect, Action onClick)
    {
        Transform = transform;
        LocalRect = localRect;
        OnClick = onClick;
    }

    public bool IsAlive => Transform;

    public bool Contains(Vector3 worldPos)
    {
        //大きさが0の(ピュッと出る前などの)ものは含まない。逆変換がどこでも原点を返してしまうため
        var scale = Transform.lossyScale;
        if (Mathf.Abs(scale.x) < 1e-4f || Mathf.Abs(scale.y) < 1e-4f) return false;
        var local = Transform.InverseTransformPoint(worldPos);
        return LocalRect.Contains(new Vector2(local.x, local.y));
    }

    public bool IsActive => Enabled && Transform && Transform.gameObject.activeInHierarchy && (Predicate?.Invoke() ?? true);
}

/// <summary>
/// 同意のミニゲームのクリックをまとめて扱います。クリックの判定そのものはバニラのPassiveButtonで行います。
/// 重なっている場合は、PassiveButtonの仕組みどおり、最も手前(zが小さい)のものだけがクリックされます。
/// </summary>
public class ConsentInput
{
    private readonly List<ConsentClickable> clickables = [];
    //結果を見せている間などはfalseにして、押しても何も起こらないようにする
    private bool acceptClick = true;

    /// <summary>UIのカメラから見た、マウスのワールド座標です。</summary>
    public Vector3 MouseWorld { get; private set; }
    public bool MouseDown => Input.GetMouseButtonDown(0);
    public bool MouseHeld => Input.GetMouseButton(0);
    public bool MouseUp => Input.GetMouseButtonUp(0);
    /// <summary>マウスホイールの回転量です。上に回すと正になります。</summary>
    public float Wheel => Input.mouseScrollDelta.y;

    public ConsentClickable Add(Transform transform, Rect localRect, Action onClick)
    {
        var clickable = new ConsentClickable(transform, localRect, onClick);
        clickables.Add(clickable);
        clickable.Button = SetUpButton(clickable);
        return clickable;
    }

    /// <summary>
    /// 中心がTransformの位置にある長方形でクリックできる範囲を登録します。
    /// </summary>
    public ConsentClickable Add(Transform transform, Vector2 size, Action onClick) => Add(transform, new Rect(-size * 0.5f, size), onClick);

    /// <summary>
    /// 離したときではなく、押したときに反応する範囲を登録します。ドラッグや長押しの始まりに使います。
    /// </summary>
    public ConsentClickable AddPress(Transform transform, Vector2 size, Action onPress)
    {
        var clickable = Add(transform, size, onPress);
        if (clickable.Button)
        {
            clickable.Button!.OnDown = true;
            clickable.Button.OnUp = false;
        }
        return clickable;
    }

    /// <summary>
    /// 対象にPassiveButtonを用意し、押したときと、カーソルが乗ったとき・離れたときの処理をつなぎます。
    /// </summary>
    private PassiveButton SetUpButton(ConsentClickable clickable)
    {
        var obj = clickable.Transform.gameObject;
        var button = obj.GetComponent<PassiveButton>();
        if (!button)
        {
            //当たり判定は範囲に合わせた長方形。コライダーはボタンより先に付ける
            var collider = obj.AddComponent<BoxCollider2D>();
            collider.isTrigger = true;
            collider.offset = clickable.LocalRect.center;
            collider.size = clickable.LocalRect.size;

            button = obj.AddComponent<PassiveButton>();
            button.Colliders = new Collider2D[] { collider };
        }
        button.OnClick = new();
        button.OnMouseOver = new();
        button.OnMouseOut = new();

        button.OnClick.AddListener((UnityEngine.Events.UnityAction)(() =>
        {
            if (!acceptClick || !clickable.IsActive) return;
            clickable.OnClick.Invoke();
        }));
        button.OnMouseOver.AddListener((UnityEngine.Events.UnityAction)(() => SetHovered(clickable, true)));
        button.OnMouseOut.AddListener((UnityEngine.Events.UnityAction)(() => SetHovered(clickable, false)));
        return button;
    }

    private void SetHovered(ConsentClickable clickable, bool on)
    {
        if (clickable.hovered == on) return;
        clickable.hovered = on;
        if (on) Hovered = clickable;
        else if (Hovered == clickable) Hovered = null;
        clickable.OnHover?.Invoke(on);
    }

    public void Remove(ConsentClickable clickable)
    {
        clickables.Remove(clickable);
        if (clickable.Button) clickable.Button!.enabled = false;
    }

    /// <summary>
    /// 与えたTransformに登録したクリックできる範囲を、PassiveButtonは残したまま登録から外します。
    /// 同じボタンを、別の動作で登録し直すときに使います。
    /// </summary>
    public void Forget(Transform transform)
    {
        foreach (var c in clickables)
        {
            if (c.Transform != transform || !c.hovered) continue;
            c.hovered = false;
            if (Hovered == c) Hovered = null;
        }
        clickables.RemoveAll(c => c.Transform == transform);
    }

    /// <summary>
    /// 与えたTransformに登録したクリックできる範囲を、すべて押せなくします。
    /// </summary>
    public void Disable(Transform transform)
    {
        foreach (var c in clickables)
        {
            if (c.Transform != transform) continue;
            c.Enabled = false;
            if (c.Button) c.Button!.enabled = false;
        }
    }

    /// <summary>
    /// 与えたTransformの座標系での、マウスの位置です。
    /// </summary>
    public Vector2 MouseLocal(Transform transform) => transform.InverseTransformPoint(MouseWorld);

    /// <summary>カーソルが乗っているものです。</summary>
    public ConsentClickable? Hovered { get; private set; }

    public void Update(bool acceptClick)
    {
        this.acceptClick = acceptClick;
        MouseWorld = UnityHelper.ScreenToWorldPoint(Input.mousePosition, LayerExpansion.GetUILayer());
        clickables.RemoveAll(c => !c.IsAlive);
        if (Hovered != null && !Hovered.IsAlive) Hovered = null;

        //押せない間はボタンを無効にして、裏にあるものの邪魔をしないようにする
        foreach (var c in clickables)
        {
            if (!c.Button) continue;
            bool active = c.IsActive;
            if (c.Button!.enabled != active) c.Button.enabled = active;
            if (!active && c.hovered) SetHovered(c, false);
        }
    }
}
