using System;
using System.Collections.Generic;
using UnityEngine;

namespace Consenter;

/// <summary>
/// 簡易な物理演算で動く玉です。
/// </summary>
public class PhysicsBall
{
    public Vector2 Position;
    public Vector2 Velocity;
    public float Radius;
    /// <summary>止めておく間は動かず、ほかの玉を押し返すだけになります。</summary>
    public bool Frozen = false;
    /// <summary>直前の計算で、何かに触れていたかどうかです。</summary>
    public bool Touching { get; internal set; }
    /// <summary>直前の計算で触れたピン(円の障害物)です。</summary>
    public PhysicsPeg? TouchingPeg { get; internal set; }

    public PhysicsBall(Vector2 position, float radius)
    {
        Position = position;
        Radius = radius;
    }
}

/// <summary>
/// 動かない線分の壁です。位置は自由に動かせますが、玉を押す速さは考えません。
/// </summary>
public class PhysicsSegment
{
    public Vector2 A, B;
    public PhysicsSegment(Vector2 a, Vector2 b) { A = a; B = b; }
}

/// <summary>
/// 動かない円の障害物(ピン)です。
/// </summary>
public class PhysicsPeg
{
    public Vector2 Center;
    public float Radius;
    public PhysicsPeg(Vector2 center, float radius) { Center = center; Radius = radius; }
}

/// <summary>
/// 玉と、線分や円の障害物だけを扱う簡易な物理演算です。座標は呼び出し側が決めた座標系で扱います。
/// </summary>
public class ConsentPhysics
{
    public readonly List<PhysicsBall> Balls = [];
    public readonly List<PhysicsSegment> Segments = [];
    public readonly List<PhysicsPeg> Pegs = [];
    public Vector2 Gravity = new(0f, -6f);
    /// <summary>跳ね返りの強さです。</summary>
    public float Restitution = 0.35f;
    /// <summary>1秒あたりの速さの減衰です。</summary>
    public float Damping = 0.2f;
    public float MaxSpeed = 10f;
    public int SubSteps = 6;
    public int Iterations = 3;

    public PhysicsBall AddBall(Vector2 position, float radius)
    {
        var ball = new PhysicsBall(position, radius);
        Balls.Add(ball);
        return ball;
    }

    public PhysicsSegment AddSegment(Vector2 a, Vector2 b)
    {
        var segment = new PhysicsSegment(a, b);
        Segments.Add(segment);
        return segment;
    }

    /// <summary>
    /// 長方形の4辺を壁として追加します。
    /// </summary>
    public void AddBoxWalls(Rect rect)
    {
        AddSegment(new(rect.xMin, rect.yMin), new(rect.xMax, rect.yMin));
        AddSegment(new(rect.xMax, rect.yMin), new(rect.xMax, rect.yMax));
        AddSegment(new(rect.xMax, rect.yMax), new(rect.xMin, rect.yMax));
        AddSegment(new(rect.xMin, rect.yMax), new(rect.xMin, rect.yMin));
    }

    public PhysicsPeg AddPeg(Vector2 center, float radius)
    {
        var peg = new PhysicsPeg(center, radius);
        Pegs.Add(peg);
        return peg;
    }

    public void Step(float deltaTime)
    {
        deltaTime = Math.Min(deltaTime, 0.05f);
        float dt = deltaTime / SubSteps;
        foreach (var ball in Balls) { ball.Touching = false; ball.TouchingPeg = null; }

        for (int step = 0; step < SubSteps; step++)
        {
            float damping = Mathf.Exp(-Damping * dt);
            foreach (var ball in Balls)
            {
                if (ball.Frozen) continue;
                ball.Velocity += Gravity * dt;
                ball.Velocity *= damping;
                if (ball.Velocity.sqrMagnitude > MaxSpeed * MaxSpeed) ball.Velocity = ball.Velocity.normalized * MaxSpeed;
                ball.Position += ball.Velocity * dt;
            }

            for (int i = 0; i < Iterations; i++) SolveCollisions();
        }
    }

    private void SolveCollisions()
    {
        for (int i = 0; i < Balls.Count; i++)
        {
            var ball = Balls[i];
            if (ball.Frozen) continue;

            foreach (var segment in Segments)
            {
                var closest = ClosestPoint(segment.A, segment.B, ball.Position);
                ResolveAgainstPoint(ball, closest, 0f);
            }
            foreach (var peg in Pegs)
            {
                if (ResolveAgainstPoint(ball, peg.Center, peg.Radius)) ball.TouchingPeg = peg;
            }
        }

        for (int i = 0; i < Balls.Count; i++)
        {
            for (int j = i + 1; j < Balls.Count; j++)
            {
                var a = Balls[i];
                var b = Balls[j];
                var diff = b.Position - a.Position;
                float minDist = a.Radius + b.Radius;
                float sqr = diff.sqrMagnitude;
                if (sqr >= minDist * minDist) continue;
                float dist = Mathf.Sqrt(sqr);
                var normal = dist > 0.0001f ? diff / dist : Vector2.up;
                float overlap = minDist - dist;
                a.Touching = true;
                b.Touching = true;

                if (a.Frozen && b.Frozen) continue;
                if (a.Frozen) b.Position += normal * overlap;
                else if (b.Frozen) a.Position -= normal * overlap;
                else
                {
                    a.Position -= normal * overlap * 0.5f;
                    b.Position += normal * overlap * 0.5f;
                }

                var relative = Vector2.Dot(b.Velocity - a.Velocity, normal);
                if (relative < 0f)
                {
                    var impulse = normal * (-(1f + Restitution) * relative);
                    if (a.Frozen) b.Velocity += impulse;
                    else if (b.Frozen) a.Velocity -= impulse;
                    else
                    {
                        a.Velocity -= impulse * 0.5f;
                        b.Velocity += impulse * 0.5f;
                    }
                }
            }
        }
    }

    private bool ResolveAgainstPoint(PhysicsBall ball, Vector2 point, float pointRadius)
    {
        var diff = ball.Position - point;
        float minDist = ball.Radius + pointRadius;
        float sqr = diff.sqrMagnitude;
        if (sqr >= minDist * minDist) return false;

        float dist = Mathf.Sqrt(sqr);
        var normal = dist > 0.0001f ? diff / dist : Vector2.up;
        ball.Position += normal * (minDist - dist);
        float vn = Vector2.Dot(ball.Velocity, normal);
        if (vn < 0f)
        {
            ball.Velocity -= normal * ((1f + Restitution) * vn);
            //接している面に沿った動きを少し弱める
            var tangent = ball.Velocity - normal * Vector2.Dot(ball.Velocity, normal);
            ball.Velocity -= tangent * 0.02f;
        }
        ball.Touching = true;
        return true;
    }

    static public Vector2 ClosestPoint(Vector2 a, Vector2 b, Vector2 p)
    {
        var ab = b - a;
        float lengthSqr = ab.sqrMagnitude;
        if (lengthSqr < 0.000001f) return a;
        float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / lengthSqr);
        return a + ab * t;
    }
}
