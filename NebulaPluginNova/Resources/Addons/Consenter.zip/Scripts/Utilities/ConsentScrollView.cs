using Virial;
using Virial.Compat;
using Virial.Media;
using Vector2 = UnityEngine.Vector2;
using Vector3 = UnityEngine.Vector3;

namespace Consenter;

/// <summary>
/// NoSのスクロールビュー(GUI.ScrollView)を、ミニゲームの中で好きな部品を並べられるように使うためのものです。
/// 中身の高さだけを持つ空の部品でスクロールビューを作り、その中身の入れ物(<see cref="Content"/>)に部品を置きます。
/// スクロールやスクロールバー、マスクはNoSのスクロールビューが扱います。
/// </summary>
public class ConsentScrollView
{
    /// <summary>
    /// 部品を置く入れ物です。中心が見える範囲の左右の中央で、上端がy=<see cref="Top"/>です。下へ向かってyが小さくなります。
    /// </summary>
    public Transform Content { get; }
    public Scroller Scroller { get; }
    /// <summary>親から見た、見える範囲(スクロールバーを除く)です。</summary>
    public Rect Viewport { get; }
    /// <summary>中身の上端の、<see cref="Content"/>の中でのyです。</summary>
    public float Top { get; }
    /// <summary>中身を置ける幅です。</summary>
    public float Width => Viewport.width;
    /// <summary>見える範囲の高さです。</summary>
    public float Height => Viewport.height;

    private ConsentScrollView(Transform content, Scroller scroller, Rect viewport, float top)
    {
        Content = content;
        Scroller = scroller;
        Viewport = viewport;
        Top = top;
    }

    /// <summary>
    /// スクロール量です。0で一番上が見え、<see cref="MaxScroll"/>で一番下が見えます。
    /// </summary>
    public float Scroll
    {
        get => Content.localPosition.y - Scroller.GetYBounds().min;
        set
        {
            var bounds = Scroller.GetYBounds();
            var pos = Content.localPosition;
            Content.localPosition = new(pos.x, Mathf.Clamp(bounds.min + value, bounds.min, bounds.max), pos.z);
            Scroller.UpdateScrollBars();
        }
    }

    public float MaxScroll => Scroller.GetYBounds().max - Scroller.GetYBounds().min;

    /// <summary>
    /// 中身の高さを変えます。中身を並べ終えてから高さが決まる場合に使います。
    /// </summary>
    public void SetContentHeight(float height)
    {
        Scroller.SetBounds(new FloatRange(0f, Math.Max(0f, height - Height)), null);
        Scroll = Scroll;
    }

    /// <summary>
    /// <see cref="Content"/>の中でのyが見える範囲の中央に来るときのスクロール量です。
    /// </summary>
    public float ScrollToCenter(float contentY) => -contentY - Scroller.GetYBounds().min;

    /// <summary>プレイヤーがスクロールできるかどうかです。</summary>
    public bool AllowUserScroll { get => Scroller.allowY; set => Scroller.allowY = value; }

    /// <summary>
    /// スクロールビューを作ります。
    /// </summary>
    /// <param name="center">親から見た、スクロールビュー(スクロールバーを含む)の中心です。</param>
    /// <param name="size">スクロールバーを含む大きさです。スクロールバーの分として、右の0.4は中身に使えません。</param>
    /// <param name="contentHeight">中身の高さです。</param>
    static public ConsentScrollView Create(Transform parent, Vector3 center, Vector2 size, float contentHeight)
    {
        var widget = NebulaAPI.GUI.ScrollView(GUIAlignment.Center, new Size(size.x, size.y), null, NebulaAPI.GUI.VerticalMargin(contentHeight), out _);
        var view = widget.Instantiate(new Size(size.x, size.y), out _)!;
        view.transform.SetParent(parent, false);
        view.transform.localPosition = center;

        var scroller = view.GetComponentInChildren<Scroller>();
        //GUIのスクロールビューは、中身の入れ物をスクロールバーの分だけ左に寄せている
        var viewport = new Rect(center.x - size.x * 0.5f, center.y - size.y * 0.5f, size.x - 0.4f, size.y);
        return new(scroller.Inner, scroller, viewport, size.y * 0.5f);
    }

    /// <summary>
    /// 中身の部品を、マスクの内側だけに表示するようにします。部品を置いた後に呼び出します。
    /// </summary>
    public void ApplyMask() => ConsentUI.SetMasked(Content.gameObject);

    /// <summary>
    /// 親から見た位置が、見える範囲の中にあるかどうかです。
    /// </summary>
    public bool Contains(Vector2 localPos) => Viewport.Contains(localPos);
}
