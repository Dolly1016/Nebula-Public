using System;
using TMPro;
using UnityEngine;

namespace Consenter;

/// <summary>
/// 数字を入力するテンキーです。算数やカウントのミニゲームで使います。
/// </summary>
public class ConsentNumberPad
{
    private readonly TextMeshPro display;
    private string value = "";
    private readonly int maxDigits;

    public string Value => value;
    public int? Number => int.TryParse(value, out var num) ? num : null;

    /// <param name="center">テンキーの中心です。入力欄はその上に出ます。</param>
    public ConsentNumberPad(ConsentInput clicks, Transform parent, Vector2 center, float keySize = 0.42f, int maxDigits = 4)
    {
        this.maxDigits = maxDigits;

        float pitch = keySize + 0.06f;
        float top = center.y + pitch * 1.5f;

        ConsentUI.Sliced(parent, "Display", new(center.x, top + pitch * 0.95f, -0.1f), ConsentAssets.RoundRect, new(pitch * 3f - 0.06f, keySize), new(0.15f, 0.15f, 0.18f));
        display = ConsentUI.Text(parent, new(center.x, top + pitch * 0.95f, -0.2f), new(pitch * 3f - 0.2f, keySize), 2.2f, Color.white, TextAlignmentOptions.Right);

        string[] labels = ["7", "8", "9", "4", "5", "6", "1", "2", "3", "C", "0", "←"];
        for (int i = 0; i < labels.Length; i++)
        {
            string label = labels[i];
            var pos = new Vector3(center.x + (i % 3 - 1) * pitch, top - (i / 3) * pitch, -0.1f);
            var button = ConsentUI.SimpleButton(parent, "Key" + label, pos, new(keySize, keySize), label, ConsentButtonStyle.Neutral, 2f);
            var clickable = clicks.Add(button.Transform, button.LocalRect, () => Press(label));
            clickable.OnHover = on => { if (button.Background) button.Background.color = on ? Color.Lerp(ConsentAssets.NeutralColor, Color.white, 0.4f) : ConsentAssets.NeutralColor; };
        }
        Refresh();
    }

    private void Press(string label)
    {
        if (label == "C") value = "";
        else if (label == "←") { if (value.Length > 0) value = value[..^1]; }
        else if (value.Length < maxDigits) value += label;
        Refresh();
    }

    private void Refresh() => display.text = value;
}
