using System;
using TMPro;
using UnityEngine;

namespace Consenter;

/// <summary>
/// 同意のミニゲーム1種類の中身です。ミニゲームの窓(<see cref="ConsentMinigame"/>)が枠と題名を用意し、その内側をこれが作ります。
/// </summary>
public abstract class ConsentGame
{
    public ConsentMinigame Host { get; private set; } = null!;
    /// <summary>ミニゲームの窓の中身の入れ物です。部品はこの下に作ります。</summary>
    public Transform Root => Host.ContentRoot;
    public ConsentInput Clicks => Host.Clicks;

    /// <summary>窓の内側の大きさです。部品の座標もこの大きさを基準にします。</summary>
    public virtual Vector2 DialogSize => new(6.6f, 4.2f);
    /// <summary>窓全体を画面に表示するときの縮尺です。</summary>
    public virtual float DialogScale => 0.8f;
    /// <summary>窓の背景と題名を出すかどうかです。出さない場合も、閉じるボタンは窓の左上に出ます。</summary>
    public virtual bool ShowDialogFrame => true;
    /// <summary>
    /// 窓を開いてからこの秒数が経つと、同意しなかったことになります。nullなら時間切れはありません。
    /// 種類ごとに、遊ぶのにかかる時間に合わせて決めます。
    /// </summary>
    public virtual float? IdleTimeout => 10f;
    /// <summary>
    /// どのミニゲームでも使う説明の翻訳キーです。説明にはやることを書かず、単に同意を促します。
    /// </summary>
    public const string GeneralInstructionKey = "consenter.minigame.instruction";
    /// <summary>題名の下に出す説明の翻訳キーです。</summary>
    public virtual string? InstructionKey => null;
    /// <summary>題名と説明の分を除いた、ゲームに使える範囲です。</summary>
    public Rect ContentArea
    {
        get
        {
            //窓の大きさは途中で変わることがあるので、今の窓から求める
            var size = Host.DialogSize;
            float top = size.y * 0.5f - (Host.HasInstruction ? 0.88f : 0.6f);
            float bottom = -size.y * 0.5f + 0.12f;
            return Rect.MinMaxRect(-size.x * 0.5f + 0.15f, bottom, size.x * 0.5f - 0.15f, top);
        }
    }

    /// <summary>
    /// trueなら、最初はStandardと同じ画面を見せ、同意するを押すと窓が本番の大きさに広がってから本番(Begin)が始まります。
    /// 広げる間の動き(<see cref="IntroGrow"/>)、広げた後の溜め(<see cref="IntroHold"/>)、片付け(<see cref="IntroFinish"/>)は種類ごとに変えられます。
    /// 本番の部品は、標準では少しずつずらしてピュッと出します(<see cref="IntroPopInStagger"/>)。
    /// </summary>
    public virtual bool UsesStandardIntro => false;
    /// <summary>導入の画面を見せている間はtrueです。</summary>
    public bool InIntro { get; private set; } = false;
    /// <summary>窓が本番の大きさに広がるまでの時間です。</summary>
    protected virtual float IntroGrowDuration => 0.5f;
    /// <summary>本番の部品をピュッと出すときの、部品ごとのずれです。負なら出さずにそのまま見せます。</summary>
    protected virtual float IntroPopInStagger => 0.02f;
    /// <summary>導入を見せたかどうかです。本番(Begin)の中で、出し方を変えるのに使います。</summary>
    protected bool PlayedIntro { get; private set; } = false;

    private TextMeshPro introBody = null!;
    private ConsentTitleButton introAgree = null!, introDisagree = null!;
    private int introPhase = 0;
    private float introTime = 0f;

    internal void BeginIntro()
    {
        InIntro = true;
        PlayedIntro = true;
        (introBody, introAgree, introDisagree) = CreateStandardScreen(() =>
        {
            if (introPhase != 0) return;
            introPhase = 1;
            introTime = 0f;
            Clicks.Disable(introAgree.Transform);
            Clicks.Disable(introDisagree.Transform);
        });
    }

    internal void UpdateIntro()
    {
        if (introPhase == 0) return;
        introTime += Time.deltaTime;

        if (introPhase == 1)
        {
            //窓を本番の大きさへ広げる
            float t = Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(introTime / IntroGrowDuration));
            Host.ChangeDialog(Vector2.Lerp(StandardDialogSize, DialogSize, t), t >= 1f ? InstructionKey : null, Mathf.Lerp(1f, DialogScale, t));
            IntroGrow(t, introAgree, introDisagree, introBody);
            if (introTime >= IntroGrowDuration)
            {
                introPhase = 2;
                introTime = 0f;
            }
            return;
        }

        if (!IntroHold(introTime, introAgree)) return;

        IntroFinish(introAgree, introDisagree, introBody);
        int before = Root.childCount;
        InIntro = false;
        Begin();
        //本番の部品を、少しずつずらしてピュッと出す
        if (IntroPopInStagger >= 0f)
        {
            int n = 0;
            for (int i = before; i < Root.childCount; i++) Host.PopIn(Root.GetChild(i), 0.15f, n++ * IntroPopInStagger);
        }
    }

    /// <summary>
    /// 窓を広げている間の、導入の画面の動きです。tは0から1まで進みます。標準では本文とボタンを消していきます。
    /// </summary>
    protected virtual void IntroGrow(float t, ConsentTitleButton agree, ConsentTitleButton disagree, TextMeshPro body)
    {
        if (body) body.alpha = 1f - t;
        if (agree.GameObject) ConsentUI.SetAlpha(agree.GameObject, 1f - t);
        if (disagree.GameObject) ConsentUI.SetAlpha(disagree.GameObject, 1f - t);
    }

    /// <summary>
    /// 窓を広げた後、本番を始めるまでの溜めです。trueを返すと本番を始めます。標準では溜めはありません。
    /// </summary>
    protected virtual bool IntroHold(float time, ConsentTitleButton agree) => true;

    /// <summary>
    /// 本番を始める直前に、導入の画面を片付けます。標準では本文とボタンを消します。
    /// </summary>
    protected virtual void IntroFinish(ConsentTitleButton agree, ConsentTitleButton disagree, TextMeshPro body)
    {
        if (body) GameObject.Destroy(body.gameObject);
        if (agree.GameObject) GameObject.Destroy(agree.GameObject);
        if (disagree.GameObject) GameObject.Destroy(disagree.GameObject);
    }

    /// <summary>
    /// 本番の窓(DialogSizeと説明)での、ゲームに使える範囲です。導入の間に、本番での位置を求めるのに使います。
    /// </summary>
    protected Rect MainContentArea
    {
        get
        {
            float top = DialogSize.y * 0.5f - (InstructionKey != null ? 0.88f : 0.6f);
            float bottom = -DialogSize.y * 0.5f + 0.12f;
            return Rect.MinMaxRect(-DialogSize.x * 0.5f + 0.15f, bottom, DialogSize.x * 0.5f - 0.15f, top);
        }
    }

    /// <summary>
    /// 窓の縮尺が変わっていく間も、縮尺1の窓での位置と大きさの補間どおりに部品を動かします。
    /// from・toは、窓の縮尺を掛けた(画面上の)位置と大きさです。
    /// </summary>
    protected void PlaceInScaledRoot(Transform target, Vector3 fromPos, Vector3 toPos, Vector3 fromScale, Vector3 toScale, float t)
    {
        float scale = Root.localScale.x;
        target.localPosition = Vector3.Lerp(fromPos, toPos, t) / scale;
        target.localScale = Vector3.Lerp(fromScale, toScale, t) / scale;
    }

    /// <summary>まだ答えを出していない間はtrueです。</summary>
    public bool IsPlaying => Host.IsPlaying;
    /// <summary>ミニゲームを開いてからの時間です。</summary>
    public float Elapsed => Host.Elapsed;

    internal void Initialize(ConsentMinigame host) => Host = host;

    /// <summary>部品を作ります。</summary>
    public abstract void Begin();
    /// <summary>毎フレーム呼び出されます。答えを出した後は呼び出されません。</summary>
    public virtual void Update() { }
    /// <summary>窓が閉じるときに呼び出されます。</summary>
    public virtual void OnClose() { }

    /// <summary>
    /// 答えを出さずに閉じたときに、次に開いたとき同じ状態から再開するための状態を返します。再開しない場合はnullです。
    /// 状態を返すと、次に開くミニゲームは同じ種類になります。
    /// </summary>
    public virtual object? SaveState() => null;

    /// <summary>
    /// 預けておいた状態から再開します。Beginより前に呼び出されます。
    /// </summary>
    public virtual void RestoreState(object state) { }

    /// <summary>Standardの窓の大きさです。</summary>
    static public readonly Vector2 StandardDialogSize = new(7.25f * 0.85f, 5.25f * 0.5f);
    public const float StandardButtonY = -0.78f;
    public const float StandardButtonX = 1.4f;
    public const float StandardButtonWidth = 2.3f;

    /// <summary>
    /// Standardと同じ画面(規約の本文と、同意する・同意しないのボタン)を作ります。窓の大きさはStandardDialogSizeにしておく必要があります。
    /// Standardと見分けがつかない見た目で始め、途中から別の画面に変わるミニゲームで使います。
    /// </summary>
    /// <param name="onAgree">同意するを押したときの動作です。</param>
    /// <param name="onDisagree">同意しないを押したときの動作です。省略すると失敗します。</param>
    protected (TextMeshPro body, ConsentTitleButton agree, ConsentTitleButton disagree) CreateStandardScreen(Action onAgree, Action? onDisagree = null)
    {
        var body = AddText(new(0f, 0.22f, -0.5f), new(StandardDialogSize.x - 0.3f, 1.05f), 1.15f, Language.Translate("consenter.minigame.body"), new(0.9f, 0.9f, 0.9f), TextAlignmentOptions.TopLeft);
        bool agreeOnLeft = Random01 < 0.5f;
        var agree = AddAgreeButton(new(agreeOnLeft ? -StandardButtonX : StandardButtonX, StandardButtonY), StandardButtonWidth, onAgree);
        var disagree = AddDisagreeButton(new(agreeOnLeft ? StandardButtonX : -StandardButtonX, StandardButtonY), StandardButtonWidth, onDisagree);
        return (body, agree, disagree);
    }

    protected void Succeed() => Host.Answer(true);
    /// <summary>
    /// 結果の状態を確かめられるよう少し待ってから閉じます。その間もUpdateは呼び出されますが、クリックはできません。
    /// </summary>
    protected void FinishAfter(bool agreed, float delay = 0.8f) => Host.FinishAfter(agreed, delay);
    /// <summary>結果を見せている間はtrueです。</summary>
    protected bool IsFinishing => Host.IsFinishing;
    protected void Fail() => Host.Answer(false);

    /// <summary>
    /// タイトル画面のボタンを置き、クリックできるようにします。
    /// </summary>
    protected ConsentTitleButton AddTitleButton(Vector2 pos, float width, string label, ConsentButtonStyle style, Action onClick, Transform? parent = null, float z = -0.3f)
    {
        var button = ConsentUI.TitleButton(parent ?? Root, label, new(pos.x, pos.y, z), width, label, style);
        Clicks.Add(button.Transform, button.LocalRect, onClick);
        return button;
    }

    /// <summary>
    /// 同意する・同意しないのボタンを置きます。同意するで成功、同意しないで失敗します。
    /// </summary>
    protected ConsentTitleButton AddAgreeButton(Vector2 pos, float width = 2.2f, Action? onClick = null)
        => AddTitleButton(pos, width, ConsentUI.AgreeText, ConsentButtonStyle.Agree, onClick ?? Succeed);
    protected ConsentTitleButton AddDisagreeButton(Vector2 pos, float width = 2.2f, Action? onClick = null)
        => AddTitleButton(pos, width, ConsentUI.DisagreeText, ConsentButtonStyle.Disagree, onClick ?? Fail);

    /// <summary>
    /// 簡易なボタンを置き、クリックできるようにします。
    /// </summary>
    protected (ConsentSimpleButton button, ConsentClickable clickable) AddSimpleButton(Transform parent, Vector3 pos, Vector2 size, string label, ConsentButtonStyle style, Action onClick, float fontSize = 1.4f)
    {
        var button = ConsentUI.SimpleButton(parent, label, pos, size, label, style, fontSize);
        var clickable = Clicks.Add(button.Transform, button.LocalRect, onClick);
        clickable.OnHover = on => { if (button.Background) button.Background.color = on ? Color.Lerp(ConsentUI.ColorOf(style), Color.white, 0.35f) : ConsentUI.ColorOf(style); };
        return (button, clickable);
    }

    protected TextMeshPro AddText(Vector3 pos, Vector2 size, float fontSize, string text, Color? color = null, TextAlignmentOptions alignment = TextAlignmentOptions.Center)
        => ConsentUI.Text(Root, pos, size, fontSize, color ?? Color.white, alignment, text);

    /// <summary>
    /// 押せない状態のボタンを押されたときに、ボタンを小さく揺らします。
    /// </summary>
    protected void Shake(Transform transform) => Host.Shake(transform);

    /// <summary>
    /// 大きさ0から、元の大きさまでピュッと大きくして出現させます。
    /// </summary>
    protected void PopIn(Transform transform, float duration = 0.15f, float delay = 0f) => Host.PopIn(transform, duration, delay);

    static protected float Random01 => UnityEngine.Random.value;
    static protected int RandomInt(int maxExclusive) => UnityEngine.Random.Range(0, maxExclusive);
    static protected int RandomInt(int min, int maxExclusive) => UnityEngine.Random.Range(min, maxExclusive);
    static protected float RandomRange(float min, float max) => UnityEngine.Random.Range(min, max);

    /// <summary>
    /// 配列を混ぜます。
    /// </summary>
    static protected void Shuffle<T>(T[] array)
    {
        for (int i = array.Length - 1; i > 0; i--)
        {
            int j = UnityEngine.Random.Range(0, i + 1);
            (array[i], array[j]) = (array[j], array[i]);
        }
    }
}
