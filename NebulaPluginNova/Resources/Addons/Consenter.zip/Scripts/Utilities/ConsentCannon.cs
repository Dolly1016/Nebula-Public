namespace Consenter;

/// <summary>
/// 土台と、軸を中心に回る砲身でできた砲台です。RaycastとHoleShotで使います。
/// 位置は砲身の軸の位置で、角度は右向きを0とした度数で指定します。
/// </summary>
public class ConsentCannon
{
    //画像の中での、土台の中心から軸までのずれと、軸から砲身の中心・砲口までの距離(縮尺1のとき)
    private const float BaseOffsetY = 0.11f;
    private const float BarrelCenter = 0.58f;
    private const float MuzzleDistance = 1.16f;

    public Transform Root { get; }
    private readonly Transform pivot;
    private readonly float scale;

    /// <param name="axlePos">砲身の軸の位置です。</param>
    /// <param name="scale">砲台の大きさの倍率です。</param>
    public ConsentCannon(Transform parent, Vector3 axlePos, float scale)
    {
        this.scale = scale;
        Root = ConsentUI.Object(parent, "Cannon", axlePos).transform;
        Root.localScale = new(scale, scale, 1f);
        pivot = ConsentUI.Object(Root, "Pivot", new(0f, 0f, 0f)).transform;
        ConsentUI.Sprite(pivot, "Barrel", new(BarrelCenter, 0f, 0f), ConsentAssets.CannonBarrel.GetSprite());
        //土台は砲身の根元より手前に描く
        ConsentUI.Sprite(Root, "Base", new(0f, BaseOffsetY, -0.01f), ConsentAssets.CannonBase.GetSprite());
    }

    /// <summary>砲身の角度(度)です。</summary>
    public float Angle
    {
        get => pivot.localEulerAngles.z;
        set => pivot.localEulerAngles = new(0f, 0f, value);
    }

    /// <summary>軸から砲口までの距離です。</summary>
    public float MuzzleLength => MuzzleDistance * scale;

    /// <summary>親から見た、砲口の位置です。</summary>
    public Vector2 Muzzle
    {
        get
        {
            float a = Angle * Mathf.Deg2Rad;
            return (Vector2)Root.localPosition + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * MuzzleLength;
        }
    }
}
