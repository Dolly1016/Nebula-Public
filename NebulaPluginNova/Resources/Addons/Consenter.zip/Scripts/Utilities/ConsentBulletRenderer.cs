namespace Consenter;

/// <summary>
/// たくさんの弾を、色ごとに1つのメッシュにまとめて描きます。弾ごとにGameObjectを作らないので軽く済みます。
/// NoSのメッシュ用シェーダーは頂点の色を使わないので、色は色ごとのメッシュの素材の色で付けます。
/// マスク対応のシェーダーを使えば、スプライトのマスクの内側だけに描くこともできます。
/// </summary>
public class ConsentBulletRenderer
{
    /// <summary>
    /// 同じ色の弾をまとめて描くメッシュです。
    /// </summary>
    private class Batch
    {
        public Mesh Mesh = null!;
        public readonly List<Vector3> Vertices = [];
        public readonly List<Vector2> Uvs = [];
        public readonly List<int> Indices = [];
    }

    private readonly bool masked;
    private readonly Dictionary<Color32, Batch> batches = [];

    public GameObject GameObject { get; }

    /// <param name="masked">trueなら、スプライトのマスクの内側だけに描きます。</param>
    public ConsentBulletRenderer(Transform parent, Vector3 localPos, bool masked)
    {
        this.masked = masked;
        GameObject = ConsentUI.Object(parent, "Bullets", localPos);
    }

    private Batch GetBatch(Color color)
    {
        Color32 key = color;
        if (batches.TryGetValue(key, out var batch)) return batch;

        var obj = ConsentUI.Object(GameObject.transform, "Batch", Vector3.zero);
        var filter = obj.AddComponent<MeshFilter>();
        var renderer = obj.AddComponent<MeshRenderer>();
        renderer.material = masked ? UnityHelper.GetMeshRendererMaskedMaterial() : UnityHelper.GetMeshRendererMaterial();
        renderer.material.mainTexture = ConsentAssets.Circle.GetSprite().texture;
        renderer.material.color = color;
        batch = new Batch() { Mesh = new Mesh() };
        batch.Mesh.MarkDynamic();
        filter.mesh = batch.Mesh;
        batches[key] = batch;
        return batch;
    }

    /// <summary>
    /// 描く弾を空にします。毎フレーム、弾を追加する前に呼び出します。
    /// </summary>
    public void Clear()
    {
        foreach (var batch in batches.Values)
        {
            batch.Vertices.Clear();
            batch.Uvs.Clear();
            batch.Indices.Clear();
        }
    }

    /// <summary>
    /// 弾を1つ追加します。
    /// </summary>
    public void Add(Vector2 pos, float radius, Color color)
    {
        var batch = GetBatch(color);
        int start = batch.Vertices.Count;
        batch.Vertices.Add(new(pos.x - radius, pos.y - radius, 0f));
        batch.Vertices.Add(new(pos.x - radius, pos.y + radius, 0f));
        batch.Vertices.Add(new(pos.x + radius, pos.y + radius, 0f));
        batch.Vertices.Add(new(pos.x + radius, pos.y - radius, 0f));
        batch.Uvs.Add(new(0f, 0f));
        batch.Uvs.Add(new(0f, 1f));
        batch.Uvs.Add(new(1f, 1f));
        batch.Uvs.Add(new(1f, 0f));
        batch.Indices.Add(start);
        batch.Indices.Add(start + 1);
        batch.Indices.Add(start + 2);
        batch.Indices.Add(start);
        batch.Indices.Add(start + 2);
        batch.Indices.Add(start + 3);
    }

    /// <summary>
    /// 追加した弾でメッシュを作り直します。毎フレーム、弾を追加し終えたら呼び出します。
    /// </summary>
    public void Apply()
    {
        foreach (var batch in batches.Values)
        {
            batch.Mesh.Clear();
            if (batch.Vertices.Count == 0) continue;
            batch.Mesh.SetVertices(batch.Vertices.ToArray());
            batch.Mesh.SetUVs(0, batch.Uvs.ToArray());
            batch.Mesh.SetIndices(batch.Indices.ToArray(), MeshTopology.Triangles, 0);
        }
    }
}
