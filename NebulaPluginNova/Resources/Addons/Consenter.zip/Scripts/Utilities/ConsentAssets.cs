using Nebula;
using UnityEngine;
using Virial;
using Virial.Media;

namespace Consenter;

/// <summary>
/// 同意のミニゲームで使う画像と色です。
/// </summary>
static public class ConsentAssets
{
    static private Image Load(string name) => NebulaAPI.AddonAsset.GetResource(name)!.AsImage(100f)!;

    /// <summary>白い円です。直径は1.28です。</summary>
    static public readonly Image Circle = Load("Circle.png");
    /// <summary>白い正方形です。一辺は0.16です。</summary>
    static public readonly Image Square = Load("Square.png");
    static public readonly Image CheckBox = Load("CheckBox.png");
    static public readonly Image CheckMark = Load("CheckMark.png");
    /// <summary>キル演出とタイトル画面のプレイヤーパーティクルの画像から作った、白黒のクルーメイトの影絵です。</summary>
    static public readonly Image[] Crewmates = Enumerable.Range(0, 29).Select(i => Load($"SilhouetteCrewmate{i}.png")).ToArray();
    /// <summary>キル演出の画像から作った、白黒のインポスターの影絵です。</summary>
    static public readonly Image[] Impostors = Enumerable.Range(0, 13).Select(i => Load($"SilhouetteImpostor{i}.png")).ToArray();
    /// <summary>タイトル画面のプレイヤーパーティクル(馬モード)の画像から作った、白黒のウマの影絵です。</summary>
    static public readonly Image[] Horses = Enumerable.Range(0, 4).Select(i => Load($"SilhouetteHorse{i}.png")).ToArray();
    /// <summary>縦長にした「同」「意」を横に並べた正方形の画像を3×3に分けた、スライドパズルのピースです。左上から右へ、行ごとに並びます。1枚は1×1です。</summary>
    static public readonly MultiImage SlidePuzzle = NebulaAPI.AddonAsset.GetResource("SlidePuzzle.png")!.AsMultiImage(3, 3, 100f)!;
    static private readonly Image RoundRectImage = Load("RoundRect.png");
    /// <summary>砲台の土台と砲身です。</summary>
    static public readonly Image CannonBase = Load("CannonBase.png");
    static public readonly Image CannonBarrel = Load("CannonBarrel.png");
    /// <summary>右向きの太い矢印です。白なので、色を乗せて使います。</summary>
    static public readonly Image HideoutArrow = Load("HideoutArrow.png");
    /// <summary>歩き回る同意ボタンの方向を示す矢印に乗せる印です。</summary>
    static public readonly Image RoamingArrowIcon = NebulaAPI.AddonAsset.GetResource("RoamingArrowIcon.png")!.AsImage(200f)!;

    static private Sprite? roundRect = null;
    /// <summary>
    /// 角丸の四角です。スライスして好きな大きさに伸ばせます。
    /// </summary>
    static public Sprite RoundRect
    {
        get
        {
            if (roundRect == null || !roundRect)
            {
                var source = RoundRectImage.GetSprite();
                roundRect = Sprite.Create(source.texture, source.rect, new(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(14f, 14f, 14f, 14f));
                roundRect.hideFlags = HideFlags.HideAndDontSave;
            }
            return roundRect;
        }
    }

    //ボタンはタイトル画面のプレイボタンを使う。元の色は水色なので、HSVシェーダで色相をずらして塗り分ける
    //シェーダの_Hueは色相を引く向きに回すので、目標の色相にするには (元の色相 - 目標の色相) を与える
    public const float ButtonBaseHue = 190f;
    public const float AgreeHue = 120f;
    //0°を狙うとピンクに寄って見えるので、橙側に寄せて赤に見せる
    public const float DisagreeHue = 20f;
    public const float NeutralHue = 190f;

    //文字色はボタンと同じ色相の暗い色
    static public readonly Color AgreeTextColor = Color.HSVToRGB(120f / 360f, 0.85f, 0.3f);
    static public readonly Color DisagreeTextColor = Color.HSVToRGB(0f / 360f, 0.85f, 0.35f);
    static public readonly Color NeutralTextColor = Color.HSVToRGB(195f / 360f, 0.85f, 0.3f);

    //簡易なボタンや玉の色
    static public readonly Color AgreeColor = new(0.55f, 0.88f, 0.55f);
    static public readonly Color DisagreeColor = new(0.95f, 0.55f, 0.5f);
    static public readonly Color NeutralColor = new(0.75f, 0.88f, 0.95f);

    static public float HueShiftFor(float hue) => ((ButtonBaseHue - hue) % 360f + 360f) % 360f;
}
