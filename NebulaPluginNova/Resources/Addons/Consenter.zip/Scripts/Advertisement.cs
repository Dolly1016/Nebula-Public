using BepInEx.Unity.IL2CPP.Utils.Collections;
using Nebula.Behavior;
using Nebula.Extensions;
using Nebula.Modules;
using Nebula.Player;
using Virial;
using Virial.Game;
using GamePlayer = Virial.Game.Player;

namespace Consenter;

/// <summary>
/// 規約のチェック(ScrollCheck)で、チェックしなくてもいい項目(メールマガジンの購読など)にチェックを入れて同意すると受ける効果「アドバータイズメント」です。
/// 効果時間は同意者のオプションで決まり(同意のミニゲームで受けたときと、確率で出るお知らせで受けたときで別)、その間、タスクフェイズか会議中(話し合いと投票の間)に、画面のランダムな位置へ広告のポップアップが出ます。
/// ポップアップは、左上の閉じるマークだけのもの、水色の「閉じる」だけのもの、水色の「閉じる」と「同意しない」があるもの、
/// 左上の閉じるマークと水色の「同意しない」があるもの、左上の閉じるマークの位置に「同意しない」があって下に水色の「閉じる」があるものの5種類です。
/// 背後には押しても何も起こらない大きなクリックガードがあります。最前面のポップアップの背後にだけ、MetaScreenの窓と同じ暗い背景を出します。
/// 「同意しない」があるポップアップでは、
/// 「同意しない」を押すと、そのボタンが0.4秒かけて赤くなってから、通常の同意しないと同じ処理(同意の失敗)が走ります。
/// 同意者が生きて会議に入るときと、会議の後にタスクフェイズが再開するときにも、確率で広告が表示される旨のお知らせが出ます。
/// お知らせを閉じると、アドバータイズメントの効果を受けます。
/// </summary>
static public class Advertisement
{
    static private readonly (float min, float max) PopupInterval = (5f, 12f);
    private const float DisagreeColorDuration = 0.4f;
    //文言の数。閉じるだけの種類と、同意しないがある種類で別の文言を使う
    private const int NumOfCloseMessages = 14;
    private const int NumOfDisagreeMessages = 10;
    static private readonly Vector2 PopupSize = new(3.2f, 1.8f);
    //枠が太いので、中身は内側に寄せる
    private const float FrameMargin = 0.4f;

    /// <summary>
    /// アドバータイズメントの属性です。属性のIDは作った順に振られるので、アドオンを読み込んだときに作っておきます。
    /// </summary>
    static public readonly IPlayerAttribute Attribute = new PlayerAttributeImpl(
        NebulaAPI.AddonAsset.GetResource("AdvertisementIcon.png")!.AsImage(100f)!, "consenterAdvertisement", "advertisement")
    { Valence = PlayerAttributeValence.Negative };

    /// <summary>
    /// 属性を作っておきます。アドオンを読み込んだときに呼び出します。
    /// </summary>
    static public void Initialize() => _ = Attribute;

    static private GameObject? runner = null;
    //出すのを待っているお知らせの翻訳キー。ポップアップを出せるようになったら出す
    static private string? pendingNotice = null;
    static private float endTime = 0f;
    static private float popupTimer = 0f;
    static private int popupCount = 0;
    //出ているポップアップと、その暗い背景。暗い背景は最前面のポップアップにだけ出す
    static private readonly List<(GameObject popup, SpriteRenderer dark)> openPopups = [];
    //同意しないが赤くなっていく途中のボタン
    static private readonly List<(ConsentSimpleButton button, GameObject popup, float time)> disagreeing = [];

    /// <summary>
    /// 自分にアドバータイズメントの効果を与え、ポップアップを出し始めます。
    /// </summary>
    static public void Apply(float duration)
    {
        var player = GamePlayer.LocalPlayer;
        if (player == null) return;
        //効果中に短い効果を受けたときは、残りの時間を縮めない
        duration = Math.Max(duration, endTime - Time.time);
        player.GainAttribute(Attribute, duration, true, 0, "consenter.advertisement");
        bool wasActive = Time.time <= endTime;
        endTime = Time.time + duration;
        if (!wasActive) popupTimer = RandomRange(PopupInterval);
        EnsureRunner();
    }

    /// <summary>
    /// 広告が表示される旨のお知らせを、ポップアップを出せるようになったら出します。閉じるとアドバータイズメントの効果を受けます。
    /// </summary>
    static public void ScheduleNotice(string translationKey)
    {
        pendingNotice = translationKey;
        EnsureRunner();
    }

    static private void EnsureRunner()
    {
        if (runner) return;
        var behaviour = UnityHelper.CreateObject<ScriptBehaviour>("ConsenterAdvertisement", null, Vector3.zero);
        behaviour.UpdateHandler += Update;
        runner = behaviour.gameObject;
    }

    static private float RandomRange((float min, float max) range) => UnityEngine.Random.Range(range.min, range.max);

    /// <summary>
    /// ポップアップを出してよいとき(タスクフェイズか、会議の話し合いと投票の間)はtrueです。
    /// </summary>
    static private bool CanShowPopup
    {
        get
        {
            if (!HudManager.InstanceExists || ExileController.Instance) return false;
            //会議の状態(VoteStates)は Animating=0, Discussion=1, NotVoted=2, Voted=3, Results=4, Proceeding=5
            if (MeetingHud.Instance) return (int)MeetingHud.Instance.state is >= 1 and <= 3;
            return true;
        }
    }

    static private void Update()
    {
        UpdateDisagreeing();
        UpdateDarkBackgrounds();

        var player = GamePlayer.LocalPlayer;
        bool alive = player != null && !player.IsDead;
        if (!alive) pendingNotice = null;
        if (pendingNotice != null && CanShowPopup)
        {
            ShowNotice(pendingNotice);
            pendingNotice = null;
        }

        if (!alive || Time.time > endTime)
        {
            //効果が切れても、出ているポップアップが閉じられるまでは暗い背景の付け替えを続ける
            if (pendingNotice == null && disagreeing.Count == 0 && openPopups.Count == 0 && runner) GameObject.Destroy(runner);
            return;
        }

        popupTimer -= Time.deltaTime;
        if (popupTimer > 0f || !CanShowPopup) return;
        popupTimer = RandomRange(PopupInterval);
        ShowPopup();
    }

    /// <summary>
    /// 広告が表示される旨のお知らせを、画面の真ん中に出します。水色の「閉じる」で閉じると、アドバータイズメントの効果を受けます。
    /// </summary>
    static private void ShowNotice(string translationKey)
    {
        var outer = PopupSize + new Vector2(FrameMargin, FrameMargin);
        var popup = CreatePopup(new(0f, 0f, -150f - (popupCount++ % 50)), outer);
        var inner = PopupSize - new Vector2(FrameMargin, FrameMargin);
        var text = ConsentUI.Text(popup.transform, new(0f, 0.15f, -0.05f), new(inner.x, 0.75f), 1.3f, new(0.95f, 0.95f, 0.95f), TextAlignmentOptions.Center, Language.Translate(translationKey));
        text.enableAutoSizing = true;
        text.fontSizeMin = 0.8f;
        text.fontSizeMax = 1.3f;

        var buttonSize = new Vector2(1.25f, 0.36f);
        bool closed = false;
        AddButton(popup, new(0f, -inner.y * 0.5f + buttonSize.y * 0.5f, -0.05f), buttonSize, Language.Translate("consenter.advertisement.close"), _ =>
        {
            if (closed) return;
            closed = true;
            ClosePopupLater(popup);
            Apply(Consenter.RandomAdvertisementDurationOption.GetValue());
        });
        PopUp(popup);
    }

    /// <summary>
    /// ポップアップの窓を作ります。背後に、押しても何も起こらないクリックガードと、最前面のときだけ出る暗い背景を置きます。
    /// </summary>
    static private GameObject CreatePopup(Vector3 pos, Vector2 outer)
    {
        var popup = ConsentUI.Panel(HudManager.Instance.transform, "AdvertisementPopup", pos, outer, 0.75f);

        //背後に、押しても何も起こらない100×100のクリックガードを置く
        var guard = UnityHelper.CreateObject<BoxCollider2D>("ClickGuard", popup.transform, new(0f, 0f, 0.05f));
        guard.gameObject.layer = ConsentUI.UILayer;
        guard.size = new(100f, 100f);
        guard.isTrigger = true;
        guard.gameObject.SetUpButton(false);

        //MetaScreenの窓と同じ暗い背景を置き、どれが最前面のポップアップか分かるようにする
        var dark = ConsentUI.Sprite(popup.transform, "BlackScreen", new(0f, 0f, 0.2f), VanillaAsset.FullScreenSprite, new Color(0f, 0f, 0f, 0.4226f));
        openPopups.Add((popup, dark));
        UpdateDarkBackgrounds();
        dark.transform.localScale = new(100f, 100f, 1f);
        return popup;
    }

    static private void ShowPopup()
    {
        var outer = PopupSize + new Vector2(FrameMargin, FrameMargin);

        //画面の中のある程度ランダムな位置に出す
        var camera = Camera.main;
        float halfHeight = camera ? camera.orthographicSize : 3f;
        float halfWidth = halfHeight * Screen.width / Math.Max(1f, Screen.height);
        var pos = new Vector3(
            UnityEngine.Random.Range(-halfWidth + outer.x * 0.5f, halfWidth - outer.x * 0.5f) * 0.85f,
            UnityEngine.Random.Range(-halfHeight + outer.y * 0.5f, halfHeight - outer.y * 0.5f) * 0.85f,
            -150f - (popupCount++ % 50));
        var popup = CreatePopup(pos, outer);

        //ポップアップは6種類
        //・左上の閉じるマークだけ
        //・水色の「閉じる」だけ
        //・水色の「閉じる」と「同意しない」
        //・左上の閉じるマークと、水色の「同意しない」
        //・左上の閉じるマークの位置に「同意しない」、下に水色の「閉じる」
        //・左上の閉じるマークの位置に水色の「閉じる」、下に「同意しない」(1つ前と位置が入れ替わったもの)
        int pattern = UnityEngine.Random.Range(0, 6);
        bool withCloseMark = pattern is 0 or 3;
        bool withCloseButton = pattern is 1 or 2 or 4;
        bool withDisagreeButton = pattern is 2 or 3 or 5;
        bool withCornerDisagree = pattern is 4;
        bool withCornerClose = pattern is 5;
        bool withButtons = withCloseButton || withDisagreeButton;

        var inner = PopupSize - new Vector2(FrameMargin, FrameMargin);
        string message = withDisagreeButton || withCornerDisagree
            ? Language.Translate("consenter.advertisement.message.disagree." + UnityEngine.Random.Range(0, NumOfDisagreeMessages))
            : Language.Translate("consenter.advertisement.message.close." + UnityEngine.Random.Range(0, NumOfCloseMessages));
        var text = ConsentUI.Text(popup.transform, new(0f, withButtons ? 0.15f : 0f, -0.05f), new(inner.x, withButtons ? 0.75f : 1f), 1.3f, new(0.95f, 0.95f, 0.95f), TextAlignmentOptions.Center, message);
        //長い文言は縮めて収める
        text.enableAutoSizing = true;
        text.fontSizeMin = 0.8f;
        text.fontSizeMax = 1.3f;

        if (withCloseMark)
        {
            //閉じるマークは、窓の閉じるボタンと同じく左上の角に置く
            var closeMark = MetaScreen.InstantiateCloseButton(popup.transform, new(-outer.x * 0.5f + 0.075f, outer.y * 0.5f - 0.175f, -0.06f));
            ConsentUI.MakeTriggers(closeMark.gameObject);
            closeMark.OnClick.AddListener((UnityEngine.Events.UnityAction)(() => ClosePopupLater(popup)));
        }

        //下のボタンはどちらも水色。2つあるときの左右はランダム
        var buttonSize = new Vector2(1.25f, 0.36f);
        float y = -inner.y * 0.5f + buttonSize.y * 0.5f;
        bool closeOnLeft = UnityEngine.Random.value < 0.5f;
        float closeX = withDisagreeButton ? (closeOnLeft ? -0.7f : 0.7f) : 0f;
        float disagreeX = withCloseButton ? -closeX : 0f;
        if (withCloseButton)
            AddButton(popup, new(closeX, y, -0.05f), buttonSize, Language.Translate("consenter.advertisement.close"), _ => ClosePopupLater(popup));
        void OnDisagree(ConsentSimpleButton button)
        {
            if (disagreeing.Any(d => d.popup == popup)) return;
            disagreeing.Add((button, popup, 0f));
        }
        if (withDisagreeButton) AddButton(popup, new(disagreeX, y, -0.05f), buttonSize, ConsentUI.DisagreeText, OnDisagree);
        //閉じるマークがあるはずの左上の角に、小さな水色のボタンを置く
        //角丸の画像は上下の縁の分より高さがないと崩れるので、ほかのボタンと同じ高さにする
        var cornerSize = new Vector2(1.15f, 0.36f);
        var cornerPos = new Vector3(-outer.x * 0.5f + cornerSize.x * 0.5f - 0.05f, outer.y * 0.5f - 0.175f, -0.06f);
        if (withCornerDisagree) AddButton(popup, cornerPos, cornerSize, ConsentUI.DisagreeText, OnDisagree, 0.9f);
        if (withCornerClose) AddButton(popup, cornerPos, cornerSize, Language.Translate("consenter.advertisement.close"), _ => ClosePopupLater(popup), 0.9f);

        PopUp(popup);
    }

    /// <summary>
    /// ポップアップを大きさ0からピュッと出します。
    /// </summary>
    static private void PopUp(GameObject popup)
    {
        popup.transform.localScale = Vector3.zero;
        var behaviour = popup.AddComponent<ScriptBehaviour>();
        float time = 0f;
        behaviour.UpdateHandler += () =>
        {
            if (time >= 0.15f) return;
            time += Time.deltaTime;
            float t = Mathf.Clamp01(time / 0.15f);
            popup.transform.localScale = Vector3.one * (t < 1f ? Mathf.Sin(t * Mathf.PI * 0.5f) * (1f + 0.15f * Mathf.Sin(t * Mathf.PI)) : 1f);
        };
    }

    /// <summary>
    /// クリックの1ティック後にポップアップを閉じます。同じクリックが、閉じた後に裏のボタンへ届かないようにするためです。
    /// </summary>
    static private void ClosePopupLater(GameObject popup)
    {
        NebulaManager.Instance.StartCoroutine(ManagedEffects.DelayedAction(() =>
        {
            if (popup) GameObject.Destroy(popup);
        }).WrapToIl2Cpp());
    }

    static private void AddButton(GameObject popup, Vector3 pos, Vector2 size, string label, Action<ConsentSimpleButton> onClick, float fontSize = 1.1f)
    {
        var button = ConsentUI.SimpleButton(popup.transform, label, pos, size, label, ConsentButtonStyle.Neutral, fontSize);
        var collider = button.GameObject.AddComponent<BoxCollider2D>();
        collider.size = size;
        collider.isTrigger = true;
        var passive = button.GameObject.SetUpButton(true);
        passive.OnClick.AddListener((UnityEngine.Events.UnityAction)(() => onClick.Invoke(button)));
    }

    /// <summary>
    /// 暗い背景は最前面(一番新しい)のポップアップにだけ出し、重なって暗くなりすぎないようにします。
    /// </summary>
    static private void UpdateDarkBackgrounds()
    {
        openPopups.RemoveAll(p => !p.popup);
        for (int i = 0; i < openPopups.Count; i++)
        {
            var dark = openPopups[i].dark;
            bool front = i == openPopups.Count - 1;
            if (dark && dark.gameObject.activeSelf != front) dark.gameObject.SetActive(front);
        }
    }

    /// <summary>
    /// 押された同意しないを赤くしていき、赤くなりきったら同意の失敗として扱います。
    /// </summary>
    static private void UpdateDisagreeing()
    {
        for (int i = disagreeing.Count - 1; i >= 0; i--)
        {
            var (button, popup, time) = disagreeing[i];
            if (!popup)
            {
                disagreeing.RemoveAt(i);
                continue;
            }
            time += Time.deltaTime;
            float t = Mathf.Clamp01(time / DisagreeColorDuration);
            button.Background.color = Color.Lerp(ConsentAssets.NeutralColor, ConsentAssets.DisagreeColor, t);
            button.Text.color = Color.Lerp(ConsentAssets.NeutralTextColor, ConsentAssets.DisagreeTextColor, t);
            if (t >= 1f)
            {
                disagreeing.RemoveAt(i);
                GameObject.Destroy(popup);
                var consenter = Consenter.LocalConsenter;
                if (consenter != null) consenter.OnFailedToConsent();
                else ConsentNotice.ShowResult(false);
            }
            else disagreeing[i] = (button, popup, time);
        }
    }
}
