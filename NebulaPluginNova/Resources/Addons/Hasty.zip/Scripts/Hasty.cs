using System.Collections;
using System.Collections.Generic;
using Nebula;
using BepInEx.Unity.IL2CPP.Utils.Collections;
using Nebula.Game;
using Nebula.Modules;
using Nebula.Roles;
using Nebula.Utilities;
using UnityEngine;
using Virial;
using Virial.Assignable;
using Virial.Attributes;
using Virial.Configuration;
using Virial.Media;
using Virial.Events.Game.Meeting;
using Virial.Events.Player;
using GamePlayer = Virial.Game.Player;

namespace Hasty;

/// <summary>
/// 1回のタスクフェイズ中に指定人数が死亡すると、自身の位置から手が現れ、道なりに会議室の緊急ボタンまで移動して押しに行くモディファイアです。
/// </summary>
public class Hasty : DefinedAllocatableModifierTemplate, DefinedAllocatableModifier, IAssignableDocument
{
    IEnumerable<AssignableDocumentReplacement> IAssignableDocument.GetDocumentReplacements()
    {
        yield return new("%NUM%", NumOfDeathsOption.GetValue().ToString());
    }

    private Hasty() : base("hasty", "HST", new(214, 168, 120), [NumOfDeathsOption, HandSpeedOption, CancelOnDeathOption, FirstDayActivationOption]) { }

    static internal readonly IntegerConfiguration NumOfDeathsOption = NebulaAPI.Configurations.Configuration("options.role.hasty.numOfDeaths", (2, 8), 2);
    static internal readonly FloatConfiguration HandSpeedOption = NebulaAPI.Configurations.Configuration("options.role.hasty.handSpeed", (1f, 8f, 0.5f), 3f);
    static internal readonly BoolConfiguration CancelOnDeathOption = NebulaAPI.Configurations.Configuration("options.role.hasty.cancelOnDeath", true);
    //オフのとき、最初の会議を挟むまでは能力が発動しない
    static internal readonly BoolConfiguration FirstDayActivationOption = NebulaAPI.Configurations.Configuration("options.role.hasty.firstDayActivation", false);

    static public readonly Hasty MyRole = new();

    RuntimeModifier RuntimeAssignableGenerator<RuntimeModifier>.CreateInstance(GamePlayer player, int[] arguments) => new Instance(player);

    public class Instance : RuntimeAssignableTemplate, RuntimeModifier
    {
        DefinedModifier RuntimeModifier.Modifier => MyRole;

        //本人は割り当てられていることを自覚できない
        bool RuntimeAssignable.CanBeAwareAssignment => NebulaGameManager.Instance?.CanSeeAllInfo ?? false;

        public Instance(GamePlayer player) : base(player) { }

        void RuntimeAssignable.OnActivated() { }

        void RuntimeAssignable.DecorateNameConstantly(ref string name, bool canSeeAllInfo, bool inEndScene)
        {
            if (canSeeAllInfo || inEndScene) name += MyRole.GetRoleIconTagSmall();
        }

        private int deathsInTaskPhase = 0;
        //手を呼べるのは1ゲームに1度だけ。会議を挟んでも戻さない
        private bool called = false;
        //一度でも会議を挟んだかどうか
        private bool meetingPassed = false;

        private static bool IsTaskPhase => !MeetingHud.Instance && !ExileController.Instance;

        [Local]
        void OnMeetingStart(MeetingStartEvent ev)
        {
            deathsInTaskPhase = 0;
            meetingPassed = true;
        }

        [Local]
        void OnPlayerDead(PlayerDieEvent ev)
        {
            if (!IsTaskPhase || ev.Player == MyPlayer) return;

            deathsInTaskPhase++;
            if (called || MyPlayer.IsDead || deathsInTaskPhase < NumOfDeathsOption) return;
            //初ターンは発動しない設定なら、使用済みにはせず2ターン目以降に持ち越す
            if (!FirstDayActivationOption && !meetingPassed) return;

            called = true;
            HastySystem.SummonHand(MyPlayer);
        }
    }
}

[NebulaRPCHolder]
internal static class HastySystem
{
    private const int IgnoreObstaclesRangeAtButton = 2; //ボタンは机の上にあって通路から外れているので、この範囲のノードには障害物を無視してつなぐ

    //手の画像(4x3)。0-2:出現 3:押す 4-6:移動 8:上向きのこぶし 9:右向きのこぶし。7,10,11は未使用。指先がセルの下端(下から4px)にそろえてある
    static private readonly MultiImage HandSprites = NebulaAPI.AddonAsset.GetResource("Hand.png")!.AsMultiImage(4, 3, 250f)!;
    private const float CellHalfHeight = 64f / 250f;
    private const float CellBottomMargin = 4f / 250f;
    static private readonly int[] AppearFrames = [0, 1, 2];
    static private readonly int[] CrawlFrames = [4, 5, 6]; //移動中はこの3枚をこの順に繰り返す
    private const int PressFrame = 3;
    private const int FistUpFrame = 8;
    private const int FistRightFrame = 9;

    private const float AppearFrameDuration = 0.08f;
    private const float CrawlFps = 10f;
    private const float PressDepth = 0.1f; //押し込むときに下へずらす量
    private const float PressedDuration = 0.3f; //押し込んでから会議を要求するまでの時間

    //閉じた扉の手前で、扉を3回立て続けに殴ってこじ開ける
    private const float DoorDetectDistance = 0.35f; //この距離だけ先の経路上に閉じた扉があれば立ち止まる
    private const int NumOfPunches = 3;
    private const float PunchWindUpDuration = 0.09f; //拳を引く時間
    private const float PunchHitDuration = 0.04f; //拳を打ち付ける時間
    private const float PunchRecoverDuration = 0.05f; //打ち付けたあと止まる時間
    private const float PunchWindUpDistance = 0.1f;
    private const float PunchHitDistance = 0.1f;
    private const float AfterOpenDuration = 0.1f; //扉を開けてから再び這い始めるまでの時間
    private const float UpwardStopOffset = 0.45f; //下から上に向かう扉の前では、本来の停止位置からさらにこの距離だけ進んでから止まる

    /// <summary>
    /// 持ち主の視点で経路を求め、全員に手の出現を伝えます。
    /// </summary>
    static public void SummonHand(GamePlayer owner)
    {
        if (!ShipStatus.Instance || !ShipStatus.Instance.EmergencyButton) return;

        Vector2 from = owner.VanillaPlayer.GetTruePosition();
        Vector2 to = ShipStatus.Instance.EmergencyButton.transform.position;
        var navPath = NavVerticesHelpers.CalcPath(from, to, 0.15f, null, IgnoreObstaclesRangeAtButton);
        Vector2[] path = navPath != null && navPath.Path.Length > 0 ? navPath.Path : [from, to];

        //経路の終端は必ずボタンの位置にする
        if (path[^1] != to) path = [.. path, to];

        RpcSummonHand.Invoke((owner, path));
    }

    static private readonly RemoteProcess<(GamePlayer owner, Vector2[] path)> RpcSummonHand = new("Hasty.Summon", (message, _) =>
    {
        NebulaManager.Instance.StartCoroutine(CoHand(message.owner, message.path).WrapToIl2Cpp());
    });

    static private bool IsInterrupted() => MeetingHud.Instance || ExileController.Instance;

    /// <summary>
    /// 持ち主の死亡で手を消す設定のとき、持ち主が死亡しているかどうか。
    /// </summary>
    static private bool IsCanceledByDeath(GamePlayer owner) => Hasty.CancelOnDeathOption && owner.IsDead;

    static private bool ShouldStop(GamePlayer owner, Transform holder) => IsInterrupted() || !holder || IsCanceledByDeath(owner);

    /// <summary>
    /// バニラのファントムが消えるときのエフェクトを、手の位置で再生します。色は手のマテリアルから写します。
    /// </summary>
    static private void PlayVanishEffect(GamePlayer owner, SpriteRenderer hand)
    {
        if (!RoleManager.Instance || !RoleManager.Instance.vanish_PoofAnim) return;

        var poof = GameObject.Instantiate(RoleManager.Instance.vanish_PoofAnim);
        var handPos = hand.transform.position;
        poof.transform.position = new Vector3(handPos.x, handPos.y, handPos.z - 0.001f);

        var source = hand.sharedMaterial;
        var material = poof.Renderer.material;
        foreach (var property in new[] { "_BackColor", "_BodyColor", "_VisorColor" })
        {
            if (source && source.HasProperty(property)) material.SetColor(property, source.GetColor(property));
        }

        poof.Play(owner.VanillaPlayer, (Il2CppSystem.Action)(() => { }), false, RoleEffectAnimation.SoundType.Local, 0f, false, 0f);
    }

    /// <summary>
    /// 手を生成します。マテリアルとレイヤーはPetの手と同じものを使います。
    /// 親の位置が指先の位置になり、親の左右反転で手の向きを変えられます。
    /// </summary>
    static private (Transform holder, SpriteRenderer renderer) SpawnHand(GamePlayer owner)
    {
        var petHand = owner.VanillaPlayer.cosmetics.PettingHand.HandSprite;
        int layer = petHand.gameObject.layer;

        var holder = new GameObject("HastyHand").transform;
        holder.gameObject.layer = layer;

        var renderer = new GameObject("Hand").AddComponent<SpriteRenderer>();
        renderer.transform.SetParent(holder, false);
        renderer.transform.localPosition = new Vector3(0f, CellHalfHeight - CellBottomMargin, 0f);
        renderer.gameObject.layer = layer;
        renderer.sharedMaterial = petHand.sharedMaterial; //持ち主の色が設定されたPetの手のマテリアルを共有する
        renderer.sprite = HandSprites.GetSprite(AppearFrames[0]);
        return (holder, renderer);
    }

    static private void SetHandPosition(Transform holder, Vector2 pos, float height, float scale, bool facingRight, bool flipY = false)
    {
        holder.position = new Vector3(pos.x, pos.y + height, pos.y / 1000f - 0.01f);
        holder.localScale = new Vector3(facingRight ? scale : -scale, flipY ? -scale : scale, 1f);
    }

    /// <summary>
    /// 現在地から経路に沿って一定距離先までの間に、閉じているサボタージュ扉があるか調べます。
    /// </summary>
    static private bool TryFindClosedDoorAhead(Vector2[] path, int next, Vector2 current, HashSet<int> ignoredDoors, out OpenableDoor door, out Vector2 direction)
    {
        door = null!;
        direction = Vector2.right;
        if (!ShipStatus.Instance) return false;

        var closedDoors = new List<(OpenableDoor door, Collider2D[] colliders)>();
        foreach (var d in ShipStatus.Instance.AllDoors)
        {
            if (!d || d.IsOpen || ignoredDoors.Contains(d.Id)) continue;
            var colliders = d.GetComponentsInChildren<Collider2D>();
            var blocking = new List<Collider2D>();
            foreach (var c in colliders) if (c.enabled && !c.isTrigger) blocking.Add(c);
            if (blocking.Count > 0) closedDoors.Add((d, blocking.ToArray()));
        }
        if (closedDoors.Count == 0) return false;

        //経路に沿って少しずつ先を調べる
        const float Step = 0.05f;
        Vector2 probe = current;
        float rest = DoorDetectDistance;
        int index = next;
        while (rest > 0f && index < path.Length)
        {
            var diff = path[index] - probe;
            float distance = diff.magnitude;
            if (distance < 0.0001f) { index++; continue; }
            var dir = diff / distance;
            float move = Mathf.Min(Step, distance, rest);
            probe += dir * move;
            rest -= move;
            if (move >= distance) index++;

            foreach (var (d, colliders) in closedDoors)
            {
                foreach (var c in colliders)
                {
                    if (c.OverlapPoint(probe))
                    {
                        door = d;
                        direction = dir;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /// <summary>
    /// 扉を開けます。各クライアントで手が殴り終えたときに開け、ホストは扉の状態を同期させます。
    /// </summary>
    static private void OpenDoor(OpenableDoor door)
    {
        if (!door || door.IsOpen) return;
        door.SetDoorway(true);

        if (!AmongUsClient.Instance.AmHost || !ShipStatus.Instance.Systems.ContainsKey(SystemTypes.Doors)) return;
        var system = ShipStatus.Instance.Systems[SystemTypes.Doors];
        var autoDoors = system.TryCast<AutoDoorsSystemType>();
        var autoDoor = door.TryCast<AutoOpenDoor>();
        if (autoDoors != null && autoDoor != null) autoDoors.SetDoor(autoDoor, true);
        var doors = system.TryCast<DoorsSystemType>();
        if (doors != null) doors.IsDirty = true;
    }

    /// <summary>
    /// 扉を3回立て続けに殴ってこじ開けます。
    /// </summary>
    static private IEnumerator CoBreakDoor(GamePlayer owner, Transform holder, SpriteRenderer renderer, Vector2 position, Vector2 direction, OpenableDoor door)
    {
        //進む方向に合わせて拳の向きを決める。上下は上向きの拳を、左右は右向きの拳を反転して使う
        bool vertical = Mathf.Abs(direction.y) > Mathf.Abs(direction.x);
        renderer.sprite = HandSprites.GetSprite(vertical ? FistUpFrame : FistRightFrame);
        bool facingRight = vertical || direction.x > 0f;
        bool flipY = vertical && direction.y < 0f;
        Vector2 axis = vertical ? new(0f, Mathf.Sign(direction.y)) : new(Mathf.Sign(direction.x), 0f);

        void SetFist(float offset) => SetHandPosition(holder, position + axis * offset, 0f, 1f, facingRight, flipY);

        for (int i = 0; i < NumOfPunches; i++)
        {
            //拳を引いて
            for (float t = 0f; t < PunchWindUpDuration; t += Time.deltaTime)
            {
                if (ShouldStop(owner, holder)) yield break;
                SetFist(-PunchWindUpDistance * Mathf.Sin(t / PunchWindUpDuration * Mathf.PI * 0.5f));
                yield return null;
            }
            //扉に打ち付ける
            for (float t = 0f; t < PunchHitDuration; t += Time.deltaTime)
            {
                if (ShouldStop(owner, holder)) yield break;
                SetFist(Mathf.Lerp(-PunchWindUpDistance, PunchHitDistance, t / PunchHitDuration));
                yield return null;
            }
            SetFist(PunchHitDistance);
            for (float t = 0f; t < PunchRecoverDuration; t += Time.deltaTime)
            {
                if (ShouldStop(owner, holder)) yield break;
                yield return null;
            }
        }

        //扉をこじ開ける
        OpenDoor(door);
        for (float t = 0f; t < AfterOpenDuration; t += Time.deltaTime)
        {
            if (ShouldStop(owner, holder)) yield break;
            yield return null;
        }
    }

    static private IEnumerator CoHand(GamePlayer owner, Vector2[] path)
    {
        if (path.Length == 0) yield break;

        var (holder, renderer) = SpawnHand(owner);
        //本人の画面でだけ、役職色の半透明の早いフラッシュを再生する
        if (owner.AmOwner) AmongUsUtil.PlayQuickFlash(Hasty.MyRole.Color.AlphaMultiplied(0.5f));
        Vector2 current = path[0];
        bool facingRight = path.Length < 2 || path[1].x >= path[0].x;

        try
        {
            //自身の足元から、手が開きながら現れる
            float appearDuration = AppearFrames.Length * AppearFrameDuration;
            for (float t = 0f; t < appearDuration; t += Time.deltaTime)
            {
                if (ShouldStop(owner, holder)) yield break;
                renderer.sprite = HandSprites.GetSprite(AppearFrames[Mathf.Min((int)(t / AppearFrameDuration), AppearFrames.Length - 1)]);
                SetHandPosition(holder, current, 0f, Mathf.SmoothStep(0.3f, 1f, t / appearDuration), facingRight);
                yield return null;
            }

            //床を這って、道なりにボタンまで移動する
            float crawlTime = 0f;
            int next = 1;
            var brokenDoors = new HashSet<int>();
            //下から上に向かう扉の手前では、止まる前にさらに進む。その間の扉と残りの距離
            OpenableDoor? approachingDoor = null;
            Vector2 approachingDirection = Vector2.up;
            float approachRest = 0f;
            while (next < path.Length)
            {
                if (ShouldStop(owner, holder)) yield break;

                //閉じた扉の手前に来たら、殴ってこじ開けてから進む
                OpenableDoor? doorToBreak = null;
                Vector2 doorDirection = Vector2.right;
                if (approachingDoor != null)
                {
                    if (approachRest <= 0f || approachingDoor.IsOpen)
                    {
                        if (!approachingDoor.IsOpen) { doorToBreak = approachingDoor; doorDirection = approachingDirection; }
                        approachingDoor = null;
                    }
                }
                else if (TryFindClosedDoorAhead(path, next, current, brokenDoors, out var door, out var direction))
                {
                    bool upward = Mathf.Abs(direction.y) > Mathf.Abs(direction.x) && direction.y > 0f;
                    if (upward)
                    {
                        brokenDoors.Add(door.Id);
                        approachingDoor = door;
                        approachingDirection = direction;
                        approachRest = UpwardStopOffset;
                    }
                    else
                    {
                        doorToBreak = door;
                        doorDirection = direction;
                    }
                }

                if (doorToBreak != null)
                {
                    brokenDoors.Add(doorToBreak.Id); //開けられなかった場合に殴り続けないよう、同じ扉は一度だけ殴る
                    var breakDoor = CoBreakDoor(owner, holder, renderer, current, doorDirection, doorToBreak);
                    while (breakDoor.MoveNext()) yield return breakDoor.Current;
                    if (ShouldStop(owner, holder)) yield break;
                    continue;
                }

                float move = HandSpeed * Time.deltaTime;
                if (approachingDoor != null)
                {
                    //停止位置を通り過ぎないようにする
                    move = Mathf.Min(move, approachRest);
                    approachRest -= move;
                }
                while (move > 0f && next < path.Length)
                {
                    var diff = path[next] - current;
                    float distance = diff.magnitude;
                    if (Mathf.Abs(diff.x) > 0.01f) facingRight = diff.x > 0f;
                    if (distance <= move)
                    {
                        current = path[next];
                        move -= distance;
                        next++;
                    }
                    else
                    {
                        current += diff / distance * move;
                        move = 0f;
                    }
                }

                crawlTime += Time.deltaTime;
                renderer.sprite = HandSprites.GetSprite(CrawlFrames[(int)(crawlTime * CrawlFps) % CrawlFrames.Length]);
                SetHandPosition(holder, current, 0f, 1f, facingRight);
                yield return null;
            }

            //ボタンに着いたら押す手になり、次のコマで少し下にずらして押し込む
            Vector2 button = path[^1];
            renderer.sprite = HandSprites.GetSprite(PressFrame);
            SetHandPosition(holder, button, 0f, 1f, facingRight);
            for (float t = 0f; t < 1f / CrawlFps; t += Time.deltaTime)
            {
                if (ShouldStop(owner, holder)) yield break;
                yield return null;
            }

            SetHandPosition(holder, button, -PressDepth, 1f, facingRight);
            for (float t = 0f; t < PressedDuration; t += Time.deltaTime)
            {
                if (ShouldStop(owner, holder)) yield break;
                yield return null;
            }

            //持ち主が会議を要求する。サボタージュ中でも開き、会議回数・緊急ボタンの使用回数は消費しない。カットインは手だけにする
            //死亡時にキャンセルしない設定なら、持ち主の生死を問わず会議を開く
            if (owner.AmOwner && !IsCanceledByDeath(owner) && !IsInterrupted()) owner.RequestEmergencyMeeting(true, false, false, true);
        }
        finally
        {
            //持ち主の死亡で中断したときは、ファントムが消えるように手を消す
            if (holder && IsCanceledByDeath(owner) && !IsInterrupted()) PlayVanishEffect(owner, renderer);
            if (holder) GameObject.Destroy(holder.gameObject);
        }
    }

    static private float HandSpeed => Hasty.HandSpeedOption;
}
